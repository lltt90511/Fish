local mConf=require("battle.conf")
local mRandom = require("battle.random")
module("battle.lottery",package.seeall)

function getBattleLottery(first)
	local ret = {
		superFlag = true,
		normal = {},
		super = {}
	}
	if first then
		ret.normal[1] = first
	else
		for i =1,1  do
			local random = mRandom.getRandom(1,100)
			for ii=1,5 do
				if mConf.NORMAL.percent[ii] >= random then
					ret.normal[i] = ii
					break 
				end
			end
		end
	end

	for i=2,3 do
		local random = mRandom.getRandom(1,100)
		if random < mConf.NORMAL.same[ ret.normal[1]] then
			ret.normal[i] = ret.normal[1]
		else
			random = mRandom.getRandom(1,100)
			ret.normal[i] = nil
			for ii=1,5 do
				if ii ~= ret.normal[1] and mConf.NORMAL.percent[ii] >= random then
					ret.normal[i] = ii
					break 
				end
			end	
			if ret.normal[i] == nil then
				for ii=1,5 do
					if ii ~= ret.normal[1] then
						ret.normal[i] = ii
						break 
					end
				end	
			end
		end
	end
	--ret.normal = {5,5,5}
	if ret.normal[1] == ret.normal[2] and ret.normal[1] ==mConf.NORMAL.id.crystal then
		local cnt = 3
		if ret.normal[2] == ret.normal[3] then
			ret.five = true
			cnt = 5
		else
			ret.five = false
		end	
		for i =1 ,1 do
			local random = mRandom.getRandom(1,100)
			for ii=1,2 do
				if mConf.SUPER.percent[ii] >= random then
					ret.super[i] = ii
					break 
				end
			end
		end
		for i=2,cnt do
			local random = mRandom.getRandom(1,100)
			if random < mConf.SUPER.same[ ret.super[1]] then
				ret.super[i] = ret.super[1]
			else
				if ret.super[1] == 1 then
					ret.super[i]  = 2
				else
					ret.super[i]  = 1
				end
			end
		end
	else
		ret.superFlag = false
	end
--[[
	ret = {
		normal	 = {mConf.NORMAL.id.crystal,mConf.NORMAL.id.crystal,mConf.NORMAL.id.crystal},
		super = {2,2,2,2,2},
		five = true,
		superFlag = true,
	}

]]

	return ret
end
function getPVELottery(boss,bossId,first)
	local lottery = {superFlag = false,sameCnt=1,normal = {}}
	if boss == true then
		lottery.normal = {mConf.PVE_RES.SOWARD,mConf.PVE_RES.SOWARD,mConf.PVE_RES.SOWARD}
        lottery.noReLottery = true
        lottery.boss = true
        lottery.bossid = bossId
        lottery.sameCnt = 3
	else
        if first then
            lottery.normal[1] = first
        else
            local ran = mRandom.getRandom(1,100)
            lottery.normal[1] = 1
            for i=1,4 do
                if ran <=mConf.PVE_PRECENT[i] then
                    lottery.normal[1]=i
                    break
                end
            end
        end
        for i=2,3 do
            local ran = mRandom.getRandom(1,100)
            if ran <= mConf.PVE_SAME[lottery.normal[1]] then
                lottery.normal[i] = lottery.normal[1] 
            else
                ran = mRandom.getRandom(1,100)
                lottery.normal[i] = nil
                for ii=1,4 do
                    if ii ~= lottery.normal[1] and mConf.PVE_PRECENT[ii] >= ran then
                        lottery.normal[i] = ii
                        break 
                    end
                end 
                if lottery.normal[i] == nil then
                    for ii=1,5 do
                        if ii ~= lottery.normal[1] then
                            lottery.normal[i] = ii
                            break 
                        end
                    end 
                end
            end

            --lottery.normal[i]= math.ceil(mRandom.getRandom(1,4))
        end
        if lottery.normal[1] == lottery.normal[2] then
            lottery.sameCnt = 2
            if lottery.normal[2]== lottery.normal[3] then
                lottery.sameCnt = 3
            end
        end
    end
    --lottery.normal = {4,4,4}
    --lottery.boss = false  
    --lottery.bossid = 1
    --lottery.noReLottery = true
    return lottery
end
