local math,table,tonumber,pairs,print,printTable,splitWithTrim=math,table,tonumber,pairs,print,printTable,splitWithTrim
local __G__TRACKBACK__ = __G__TRACKBACK__
local isClient = isClient
local C_CLOCK = C_CLOCK
local coroutine,L_onError,xpcall,string,debug = coroutine,L_onError,xpcall,string,debug
local mGameData = require ("template.gamedata")
local mConf=require("battle.conf")
local mSkill=require("battle.skill")
local mRole=require("battle.role")
local mView=require("battle.view")
local mSelect=require("battle.select")
local mRandom=require("battle.random")
local mAction = require ("battle.action")
local mLottery = require("battle.lottery")
local mBuff = require("battle.buff")
local mNum = require("battle.numerial")
local AnimSpeed = mConf.AnimSpeed
--local mServer=require("battle.server")
module("battle.battle")
local gamedata = mGameData.data
-- Round 1 Call
-- 做一些初始化工作
--userAction = {}
roundNum = 0

function selectRole(bf,id)
	if bf.team1.attackTarget == id then
		unSelectRole(bf)
	else
		if bf.team2.roleMap[id] then
			local v = bf.team2.roleMap[id]
			bf.team1.attackTarget = id
			return true,mView.redeceHpCmd(bf,v.id,0,mNum.getHpPercent(bf,v),mNum.getHpPercent(bf,v),bf.time,0,v.factions,true,1,0)
		end
	end
	return false
end
function unSelectRole(bf)
	bf.team1.attackTarget = nil
end


function normalHurt(bf,type,attacker,hurter,hp,isBack)
	--print ("normalHurt")
	local hasDodgeSkill=-1
	local hurtTime = hurter.hurtTime
	if not mSkill.canDodge(bf,type,attacker,hurter) then
		-- 减伤
		hp = mNum.getHurtAfterParry(bf,type,hurter,attacker,hp)
		hurter.status = mConf.ROLE_STATUS.HURT
		mAction.reduceHpCmd(bf,hurter,attacker,hp)
		
		----printTable(attacker.atkeft)
		mView.beHurtCmd(bf,hurter.id,attacker.hurtAnim,bf.time,hurter.hurtTime)	
		mNum.Vampire(bf,type,attacker,hp)	
		--反击判定
		--local back  =false
		--local backPercent,backSkilId
		return hp,false,hurtTime
	end
	return hp,false,0
end





function doPhyAttack(bf,role,target,isBack)
	-- 对方扣血
	--print ("doPhyAttack")
	--mAction.changeSp(bf,role,10)
	local reduceHp=1
	--print("#######################",mNum.getBattleAtk(bf,role,0),mNum.getBattleDef(bf,target),mNum.getHpMax(bf,target),mNum.getBattleHp(bf,target))
	if mNum.getBattleAtk(bf,role,0)>mNum.getBattleDef(bf,target) then
		reduceHp=mNum.getBattleAtk(bf,role,0)-mNum.getBattleDef(bf,target) 			
	end
	if target.factions==mConf.ADD[role.factions]  then
		reduceHp = math.ceil(reduceHp * 1.5)
	end
	if role.factions==mConf.ADD[target.factions]   then
		reduceHp = math.ceil(reduceHp * 0.5)
	end

	local currectHurt,back,hurtTime = normalHurt(bf,mConf.ATTACK_TYPE.normal, role,target,reduceHp,false,1)
	if role.type == mConf.ROLE_TYPE.pve then
		mAction.changeSp(bf,role,30)
	else
		mAction.changeSp(bf,role,5)
	end
	-- 从对方的伤害列表移除自己
	local hurt =  false
	--print ("mAction.removeFromHurtList")

	--print ("#doPhyAttack")
	return hurtTime,reduceHp

end
function getTime(bf)
	return C_CLOCK() - bf.startTime
end
function phyAttack(bf,role)
	local target = nil
	-- 跑动
	local run = true
	target = mSelect.getAttackTarget(bf,role,-1)
	if target == nil and role.status ~= mConf.ROLE_STATUS.DEAD then
		-- 死光了？
		mAction.moveTo(bf,role,role,true)
		role.status = mConf.ROLE_STATUS.STAND
		role.resumeTime = mConf.timeMax
		coroutine.yield()
		return	
	end

	mAction.addTarget(bf,role,target)
	mAction.moveTo(bf,role,target,true)

	
	mView.addLog(bf,"【"..role.name.."】普通攻击 【"..target.name.."】 ")
	mView.preAttackCmd(bf,role.id,bf.time,role.preAtkTime/AnimSpeed,AnimSpeed)
	role.resumeTime = bf.time + role.preAtkTime/AnimSpeed
	role.hurtList = {}
	
	coroutine.yield()	
	-- 攻击后摇及扣血
	--mView.addLog(bf,"【"..role.name.."】endAttack ")
	mView.endAttackCmd(bf,role.id,bf.time,role.endAtkTime/AnimSpeed)
	role.resumeTime = bf.time + role.endAtkTime/AnimSpeed
	local ti,hp = doPhyAttack(bf,role,target)
	
	mAction.removeAllTarget(bf,role)
	coroutine.yield()
	if role.status ~= mConf.ROLE_STATUS.DEAD then
		role.status = mConf.ROLE_STATUS.STAND
	end
	--mView.addLog(bf,"【"..role.name.."】Back ")
	mAction.moveTo(bf,role,role,false)

end
function beforeSkillStart(bf,role,skillName)
	mView.skillStartEffect(bf,role.id,skillName)
	if bf.afterSkillActionRole ~= nil then
		bf.afterSkillActionRole.afterSkillAction = nil
	end
	bf.afterSkillActionRole = role
	role.afterSkillAction = true
end
function roleMainThread(bf,role)

	while true do
		if mBuff.hasStopBuff(bf,role) then
			role.status = mConf.ROLE_STATUS.STAND
			role.resumeTime = mConf.timeMax
			coroutine.yield()
		end
		if role.status == mConf.ROLE_STATUS.SKILL then
			role.lotteryAdd = false
			if role.userControl and role.userControl > 0 then
				mSkill.skillAttack(bf,role,role.userControl)
				role.userControl = nil
				--role.status = mConf.ROLE_STATUS.STAND
			else
				if role.status ~= mConf.ROLE_STATUS.DEAD then
					role.status = mConf.ROLE_STATUS.STAND
				end
				coroutine.yield()
			end

		elseif role.status == mConf.ROLE_STATUS.CAN_ACTION then
			if role.lotteryAdd == true then
				role.lotteryAdd = false
				mSkill.skillAttack(bf,role,role.lotterySkill)
			else
				if role.type ==mConf.ROLE_TYPE.pve then
					if role.power >= 100 and #role.skill > 0  then
						local random = mRandom.getRandom(1,#role.skill+1)
						if random > #role.skill then
							random = #role.skill
						end
						mAction.changeSp(bf,role,-100)
						mSkill.skillAttack(bf,role,role.skill[random])
					else
						phyAttack(bf,role)
					end
				elseif bf.autoFlag == true or role.autoFlag == true then
					local skillId,power = checkCanSkill(bf,role)
					if skillId > 0 then
						mView.playEffect(bf,"effect_12")
						mAction.changeSp(bf,role,-power)
						beforeSkillStart(bf,role,gamedata['skill'][skillId].name)
						mSkill.skillAttack(bf,role,skillId)
					else
						phyAttack(bf,role)
					end
				else
					phyAttack(bf,role)
				end
			end
		else
			role.resumeTime = mConf.timeMax
			coroutine.yield()
		end
	end
end
function errorHandler(msg,bf)
	bf.error = true
	__G__TRACKBACK__(msg)
end
function createCo(bf,role)
	if role.afterSkillAction == true then
		role.afterSkillAction  = nil
		mView.stopUserSkill(bf)
	end
    role.co = coroutine.create(function ()
    	if isClient then
			xpcall(
				function ()
					roleMainThread(bf,role)
				end
			 ,errorHandler,bf)
     	else
     		roleMainThread(bf,role)
     	end
    end)
end
function startNewRound(bf)
	bf.roundNum = bf.roundNum + 1
	mView.roundChange(bf,bf.roundNum-1)
	bf.roundStatus = "Lottery"
	bf.lotteryRefCnt = mConf.ReLotteryCnt
	for i,v in pairs(bf.team1.roleMap) do
		if mNum.getBattleHp(bf,v) <= 0  and
			v.status ~= mConf.ROLE_STATUS.DEAD then
		--	print (v.name,v.id)
			printTable(v.hurtList)
			if nil > 1 then
			end
		end
	end
	for i,v in pairs(bf.team2.roleMap) do
		if mNum.getBattleHp(bf,v) <= 0  and
			v.status ~= mConf.ROLE_STATUS.DEAD then
			--print (v.name,v.id)
			printTable(v.hurtList)
			if nil > 1 then
			end
		end
	end
end
--获取一次老虎机
function getPvpLottory(bf)
	local lottery= mLottery.getBattleLottery()
	bf.lotteryRefCnt = mConf.ReLotteryCnt
	bf.canSkill = false
	lottery.lotteryRefCnt = bf.lotteryRefCnt 
	mView.playLottery(bf,lottery)
	mView.waitForLottery(bf)
	mView.getNextAction(bf)
	bf.lottery = lottery
	bf.lotteryStatus = true
	return lottery
end
function getLotteryRandom(bf,first)
	--print ("getLotteryRandom")
	-- 如果上一轮已经进入要老虎机阶段则roundNum + 1
	local nowRound = false
	if checkBfEnd(bf) then
		return
	end
		if bf.canLottery then
			--按下老虎机转动的那一瞬间开始下一回合
			if bf.firstLottery  then
				bf.firstLottery  = false
				mView.endRound(bf)
				startNewRound(bf)
				nowRound = true
			end
		else
			return
		end
	local lottery= mLottery.getBattleLottery(first)
	bf.lotteryRefCnt = bf.lotteryRefCnt * 2
	lottery.first = nowRound	
	bf.canSkill = false
	lottery.lotteryRefCnt = bf.lotteryRefCnt 
	mView.playLottery(bf,lottery)
	mView.waitForLottery(bf)
	mView.getNextAction(bf)
	bf.lottery = lottery
	bf.lotteryStatus = true
	return lottery
end 





function checkBfEnd(bf)
	if bf.status ~= "running" then
		return true
	else
		return false
	end
end
function dealLotteryResult(bf,effectTeam)
	local lottery = bf.lottery
	-- 分析老虎机结果及加成
	bf.canLottery = false
	print ("摇到了老虎机："..
        mConf.laohujiIconPvp[lottery.normal[1]].name..":"..
        mConf.laohujiIconPvp[lottery.normal[2]].name..":"..
        mConf.laohujiIconPvp[lottery.normal[3]].name)
	mView.addLog(bf,"摇到了老虎机："..
        mConf.laohujiIconPvp[lottery.normal[1]].name..":"..
        mConf.laohujiIconPvp[lottery.normal[2]].name..":"..
        mConf.laohujiIconPvp[lottery.normal[3]].name,2)
	bf.superFactions = nil
	for i,v in pairs(bf.t1.roleMap) do
		v.hit = 0 
	end
	for i,v in pairs(bf.t2.roleMap) do
		v.hit = 0 
	end
	if lottery.superFlag == false then
		local sameCnt = 1
		if lottery.normal[1] == lottery.normal[2] then
			if lottery.normal[2] == lottery.normal[3] then
				sameCnt = 3
			else
				sameCnt = 2
			end
		end
		if lottery.normal[1] == mConf.NORMAL.id.heart then
			local pl = {0.1,0.2,0.4}
			local precent = pl[sameCnt]
			local effectList = {}
			for i,v in pairs(effectTeam.roleMap) do
				if v.status ~= mConf.ROLE_STATUS.DEAD then
					table.insert(effectList,v.id)
				end
			end
			mView.LotteryEndEffect(bf,lottery.superFlag, lottery.normal[1],sameCnt,lottery.five,effectList)
			mView.playEffect(bf,"effect_01")
			for i,v in pairs(effectTeam.roleMap) do
				if v.status ~= mConf.ROLE_STATUS.DEAD then
					local hp = mNum.getHpMax(bf,v) *precent
					mAction.reduceHpCmd(bf,v,nil,-hp)
				end
			end
			
		else
			local sl = {1,2,3}
			local skillid = sl[sameCnt]
			local effectList = {}
			bf.superFactions  = lottery.normal[1]
			for i,v in pairs(effectTeam.roleMap) do
				if v.status ~= mConf.ROLE_STATUS.DEAD then
					if v.factions == lottery.normal[1] then
						v.lotteryAdd = true
						v.lotterySkill = skillid
						table.insert(effectList,v.id)
					end
				end
			end
			mView.LotteryEndEffect(bf,lottery.superFlag,lottery.normal[1],sameCnt,lottery.five,effectList,true)
		end
	else
		local cnt = 1
		for i=2,5 do
			if lottery.super[i] == lottery.super[i-1] then
				cnt = cnt +1
			else
				break
			end
		end
		----print ("#####################################################################")
		----printTable(lottery)
		if lottery.super[1] == mConf.SUPER.id.fist then
			local skill = {4,5,6,7,8}
			local skillId = skill[cnt]
			local effectList = {}
			for i,v in pairs(effectTeam.roleMap) do
				if v.status ~= mConf.ROLE_STATUS.DEAD then
					v.lotteryAdd = true
					v.lotterySkill = skillId
					table.insert(effectList,v.id)
				end
			end
			mView.LotteryEndEffect(bf,lottery.superFlag,lottery.super[1],cnt,lottery.five,effectList,true)
		else
			local skill = {45,46,47,48,49}
			local skillid = skill[cnt]
			local tpl = gamedata['skill'][skillid]
			local hp = (tpl.propNum/100 + 1 )* effectTeam.fans + 4000
			local selfTeam = effectTeam
			local oppoTeam = nil
			local selfTeamList = {}
			local oppoTeamList = {}

			for i,v in pairs(selfTeam.roleMap) do
				if oppoTeam == nil then
					oppoTeam = mSelect.oppositeTeam(bf,v)
				end
				if v.status ~= mConf.ROLE_STATUS.DEAD then
					table.insert(selfTeamList,v.id)
				end
			end
			for i,v in pairs(oppoTeam.roleMap) do
				if v.status ~= mConf.ROLE_STATUS.DEAD then
					table.insert(oppoTeamList,v.id)
				end
			end	

			mView.preSuperAttack(bf,cnt,selfTeamList,oppoTeamList)
			local flag = true
			local hit = 0
			for i,v in pairs(oppoTeam.roleMap) do
				if v.status ~= mConf.ROLE_STATUS.DEAD then
					hit = hit + 10
				end
			end
			for i,v in pairs(oppoTeam.roleMap) do
				if v.status ~= mConf.ROLE_STATUS.DEAD then
					mView.beHurtCmd(bf,v.id,nil,bf.time,v.hurtTime)	
					if flag == true then

						mAction.reduceHpCmd(bf,v,nil,hp/10,false,10,true,hit)
						flag =false
					else

						mAction.reduceHpCmd(bf,v,nil,hp/10,false,10,true)
					end
					-- 判定死亡
					if v.status == mConf.ROLE_STATUS.PREDEAD then
						mAction.dead(bf,v)
					end
				end
			end			
			mView.endSuperAttack(bf,cnt,selfTeamList,oppoTeamList)
			mView.collectGold(bf)

			return  1
			--mView.LotteryEndEffect(bf,lottery.superFlag,lottery.super[1],cnt,lottery.five,effectList)
		end
	end
	--mView.getNextAction(bf)
end
function checkCanSkill(bf,role)
	if mBuff.hasStopBuff(bf,role) then
		
		return -1
	end
	if mBuff.checkHasBuff (bf,role,"skillSeal") >0  then
		return -1
	end
	if role.power <100 then
		----print ("sp?")
		return -1
	end
	local skillid = math.floor( role.power/100)
	if role.skill[skillid] == nil then
		return -1
	else
		return role.skill[skillid],100*skillid
	end
end
--玩家主动技能触发
function skillAction(bf,roleid,now)
	local role = nil
	if bf.canSkill == false then
		return -2
	end
	for i,v in pairs(bf.team1.roleMap) do
		if v.id == roleid and v.status ~= mConf.ROLE_STATUS.DEAD then
			local skillId,power = checkCanSkill(bf,v)
			if skillId <= 0 then
				return -1
			end
			print ("skillid:"..skillId)
			mView.playEffect(bf,"effect_12")
			mAction.changeSp(bf,v,-power)
			v.status = mConf.ROLE_STATUS.SKILL
			v.userControl = skillId
			--新建一个例程序
			--需要先删除所有的准备攻击状态标记~ 
			mAction.removeAllTarget(bf,v)
			createCo(bf,v)
			v.status =  mConf.ROLE_STATUS.SKILL
			beforeSkillStart(bf,v,gamedata['skill'][skillId].name)
			bf.canLottery = false
			bf.firstLottery = false
			if v.resumeTime >=mConf.timeMax then
				v.resumeTime = bf.time
				-- 立刻恢复
				startResume(bf)
				return 1
			end
			
			return 0
		end
	end
	return -3
end
function getMinResumeTime (bf)
	local minTime = mConf.timeMax + 1
	for i,v in pairs(bf.team1.roleMap) do
		--print (v.resumeTime , bf.time)
		if v.status ~= mConf.ROLE_STATUS.DEAD  and v.resumeTime < minTime then
			minTime = v.resumeTime
		end
	end
	for i,v in pairs(bf.team2.roleMap) do
		if v.status ~= mConf.ROLE_STATUS.DEAD  and v.resumeTime < minTime then
			minTime = v.resumeTime
		end
	end
	if minTime > mConf.timeMax then
		minTime = mConf.timeMax
	end
	return minTime
end
function startResume(bf)
	--print ("startResume")
	local remuseFlag = true
	local userAction = false
	local battleid = #bf.playList[bf.roundNum] + 1 
	--print ("#start of startResume")
	while remuseFlag do
		remuseFlag = false
		for i,v in pairs(bf.team1.roleMap) do
			--print (i,v.resumeTime ,  bf.time ,math.abs(v.resumeTime -  bf.time),coroutine.status(v.co))
			if (v.resumeTime< bf.time or  math.abs(v.resumeTime -  bf.time) < 0.00001 ) and coroutine.status(v.co) ~="dead" then
				--print ("resume team1 ",i)
				coroutine.resume(v.co)
				remuseFlag = 	true
			end
			
			if checkBfEnd(bf) then
				break 
			end
		end
		for i,v in pairs(bf.team2.roleMap) do
			--print (v.resumeTime,bf.time)
			--print (v.resumeTime ,  bf.time)
			if (v.resumeTime< bf.time or  math.abs(v.resumeTime -  bf.time) <0.00001 )  and coroutine.status(v.co) ~="dead" then
				--print ("resume team2 ",i)
				coroutine.resume(v.co)
				remuseFlag = true
			end
			if checkBfEnd(bf) then
				break 
			end
		end
		if remuseFlag == true then
			userAction = true
		end
		if bf.error then
			break
		end
	end
	--print ("#end of startResume")
	local minTime = getMinResumeTime(bf)
	if checkBfEnd(bf) then
		mView.battleEnd(bf)
	else
		if minTime >= mConf.timeMax then
			mView.nextActionDelay(bf,0)
		else
			mView.nextActionDelay(bf,minTime-bf.time)
		end
		mView.getNextAction(bf)
		--bf.playList[bf.roundNum][#bf.playList[bf.roundNum]].next = maxNeed
	end
end
function onSkillStart(bf)
	----print ("onSkillStart")
	--local minTime = mConf.timeMax + 1
	if checkBfEnd(bf) then
		return 
	end
	local minTime = getMinResumeTime(bf)
	if minTime >= bf.time then
		bf.time = minTime 
	end

	startResume(bf)
end
-- 消除一些引用
function clearRef(bf,role)
	role.hurtList ={}
	role.backList = {}
end
function reborn(bf)
	-- 复活 需要注意的事情
	-- 1.角色的sprite不能被删除
	-- 2.注意角色目前的位置
	-- 3.一些战报需要添加
	-- 4.记得自己调用onActionEndCallBack
	bf.checkBattleEnd = false
	mView.nextActionDelay(bf,0.5)
	for i,v in pairs(bf.team1.roleMap) do
		v.status = mConf.ROLE_STATUS.STAND 
		local max = mNum.getHpMax(bf,v)
		mView.ReviveCmd(bf,v.id)
		mAction.reduceHpCmd(bf,v,nil,-max)
		v.pos = v.id
		v.resumeTime = mConf.timeMax
		mSkill.initPassive(bf,v)
		clearRef(bf,v)
		createCo(bf,v)
		mAction.changeSp(bf,v,1000)
	end
	for i,v in pairs(bf.team2.roleMap) do
		if v.status ~= mConf.ROLE_STATUS.DEAD then
			--print (v.pos,v.id)
			v.status = mConf.ROLE_STATUS.STAND 
			v.resumeTime = mConf.timeMax
			if v.pos ~= v.id then
				mView.runCmd(bf,v.id,v.id,bf.time,true,v.runTime)
				v.pos = v.id
			end
			clearRef(bf,v)
			createCo(bf,v)
		end
	end
	bf.status = "running"
	onActionEndCallBack(bf)
end
local diffTime = 1
function T1RoundStart(bf)
	print ("#Team1 Round Start")
	bf.roundStatus = "Team1" 
	local start = bf.time
	for i,v in pairs(bf.t1.roleMap) do
		if v.status ~= mConf.ROLE_STATUS.DEAD and v.factions == bf.superFactions then

		 	v.resumeTime = start
		 	start = start + diffTime
			v.status = mConf.ROLE_STATUS.CAN_ACTION
		end
	end
	for i,v in pairs(bf.t1.roleMap) do
		if v.status ~= mConf.ROLE_STATUS.DEAD and v.factions ~= bf.superFactions then
		 	v.resumeTime = start
		 	start = start + diffTime
			v.status = mConf.ROLE_STATUS.CAN_ACTION
		end
	end
	for i,v in pairs(bf.t1.roleMap) do
		if v.status ~= mConf.ROLE_STATUS.DEAD then
			mBuff.checkBuff(bf,v)
		end
	end
	mView.getNextAction(bf)
end
function T2RoundStart(bf)
	print ("#Team2 Round Start")
	bf.roundStatus = "Team2" 
	local start = bf.time
	for i,v in pairs(bf.t2.roleMap) do
		if v.status ~= mConf.ROLE_STATUS.DEAD and v.factions == bf.superFactions then
		 	v.resumeTime = start
		 	start = start + diffTime
			v.status = mConf.ROLE_STATUS.CAN_ACTION
		end
	end
	for i,v in pairs(bf.t2.roleMap) do
		if v.status ~= mConf.ROLE_STATUS.DEAD and v.factions ~= bf.superFactions then
		 	v.resumeTime = start
		 	start = start + diffTime
			v.status = mConf.ROLE_STATUS.CAN_ACTION
		end
	end
	for i,v in pairs(bf.t2.roleMap) do
		--v.hit = 0 
		if v.status ~= mConf.ROLE_STATUS.DEAD then
			mBuff.checkBuff(bf,v)
		end
	end
	mView.getNextAction(bf)
end


function findGuideRole(bf,id)
	for i,v in pairs(bf.team1.roleMap) do
		if v.id == id then
			return v
		end
	end
	for i,v in pairs(bf.team2.roleMap) do
		if v.id == id then
			return v
		end
	end
end
function newGuideHandler(bf,roundName)
	local guide = bf.newGuideRoundSetp[roundName  + 1]
	if guide == nil then
		return
	end
	if guide.action == "pointAnim" then
		mView.pointAnim(bf,guide.id)
		mView.getNextAction(bf)
	elseif guide.action == "chechkAndStop" then
		bf.lottery = guide.lottery
		mView.checkAndStopLottery(bf,guide.lottery)
		dealLotteryResult(bf,bf.team1)
		mView.getNextAction(bf)

	elseif guide.action == "Team1" then
		T1RoundStart(bf)
		if guide.target then
			bf.team1.attackTarget = guide.target
		end
	elseif guide.action == "Team2" then
		T2RoundStart(bf)
		if guide.target then
			bf.team1.attackTarget = guide.target
		end
	elseif guide.action == "talk" then
		local role =findGuideRole(bf,guide.id)
		mView.nextActionDelay(bf,0.5)
		mView.userTalk(bf,guide.id,role.name,guide.text)
		mView.getNextAction(bf)
	elseif guide.action == "spMaxManual" then
		bf.canSkill = true
		local role =findGuideRole(bf,guide.id)
		mAction.changeSp(bf,role,100,true)
		mView.spMaxManual(bf,guide.id)
		mView.getNextAction(bf)
	elseif guide.action == "spMaxAuto" then
		local role =findGuideRole(bf,guide.id)
		mAction.changeSp(bf,role,100,true)
		role.resumeTime = bf.time
		role.status = mConf.ROLE_STATUS.CAN_ACTION
		role.preSkillTime = 1.5
		-- 释放技能
		--T2RoundStart(bf)
		mView.getNextAction(bf)
	elseif guide.action == "battleEnd" then
		--mAction.battleEnad(bf)
		mView.collectItem(bf)
		mView.collectExp(bf)
		mView.collectGold(bf)
		mView.nextActionDelay(bf,0.5)
		mView.VictoryEffect(bf)
		mView.nextActionDelay(bf,0.5)
		--mView.battleEnd(bf)
		mView.getNextAction(bf)
	elseif guide.action == "startPreLottery" then
		mView.startPreLottery(bf)
		mView.getNextAction(bf)
	elseif guide.action == "leaveScene" then
		mView.leaveScene(bf,guide.id)
	elseif guide.action == "runToScene" then
		mView.runToScene(bf)
		mView.getNextAction(bf)
	end
	bf.roundStatus  = roundName + 1


end

function pvpEndRoundHandler(bf,roundName)
	print ("#pvpEndRoundHandler ",roundName)
	if bf.checkBattleEnd then
		mAction.battleEnad(bf)
		mView.battleEnd(bf)
		return 
	end
	if roundName == "Lottery" then
		--#end of Lottery round
		if bf.lotteryStatus then
			print ("test Super")
			bf.lotteryStatus = false
			local super = dealLotteryResult(bf,bf.t1)
			if super and super >0 then
				print ("Super!!!!!!")
				bf.roundStatus = "super"
				mView.changeLottery(bf,mConf.LotteryType.Battle)
				mView.startPreLottery(bf)
				mView.getNextAction(bf)
			else
				mView.startPreLottery(bf)
				T1RoundStart(bf)
			end
		else
			mView.startPreLottery(bf)
			T1RoundStart(bf)
		end
	elseif roundName == "Team1" or roundName == "super" then
		--#end of Team1 round

		bf.roundStatus = "Lottery2"
		mView.collectGold(bf)
		getPvpLottory(bf)		
	elseif roundName == "Lottery2" then
		if bf.lotteryStatus then
			bf.lotteryStatus = false
			local super = dealLotteryResult(bf,bf.t2)
			if super and super >0 then
				bf.roundStatus = "super2"
				mView.changeLottery(bf,mConf.LotteryType.Battle)
				mView.startPreLottery(bf)
				mView.getNextAction(bf)
			else
				mView.startPreLottery(bf)
				T2RoundStart(bf)
			end
		else
			mView.startPreLottery(bf)
			T2RoundStart(bf)
		end
	elseif roundName == "Team2" or roundName == "super2" then
		--mView.collectGold(bf)
		if bf.roundNum >= 21 then
			--	(1).存活人数较多的一方
			--(2).剩余HP总量较多的一方
			--(3).给予总伤害值较多的一方
			local team1Cnt = 0
			local team1Hp = 0
			local team2Cnt = 0
			local team2Hp = 0
			for i,v in pairs(bf.team1.roleMap) do
				if v.status ~= mConf.ROLE_STATUS.DEAD then
					team1Cnt = team1Cnt + 1
					team1Hp = team1Hp + mNum.getBattleHp(bf,v)
				end
			end
			for i,v in pairs(bf.team2.roleMap) do
				if v.status ~= mConf.ROLE_STATUS.DEAD then
					team2Cnt = team2Cnt + 1
					team2Hp = team2Hp + mNum.getBattleHp(bf,v)
				end
			end
			local t = 2
			if team1Cnt < team2Cnt then
				t =1
			elseif team1Cnt == team2Cnt then
				if team1Hp < team2Hp then
					t =1
				elseif team1Hp == team2Hp then
					if bf.teamHurt[1] < bf.teamHurt[2] then
							t =1
					end
				end
			end
			bf.checkTeam = t
			mAction.battleEnad(bf)
			mView.battleEnd(bf)
		else	
			bf.roundStatus = "Lottery"
			mView.endRound(bf)
			startNewRound(bf)
			getPvpLottory(bf)
		end
	end
end

function defaultEndRoundHandler(bf,roundName)
	print ("#defaultEndRoundHandler ",roundName)
	if bf.checkBattleEnd then
		mAction.battleEnad(bf)
		mView.battleEnd(bf)
		return 
	end
	if roundName == "Lottery" then
		--#end of Lottery round
		if bf.lotteryStatus then
			bf.lotteryStatus = false
			local super = dealLotteryResult(bf,bf.team1)
			if super and super >0 then
				bf.roundStatus = "super"
				mView.getNextAction(bf)
			else
				bf.canSkill = true
				T1RoundStart(bf)
			end
		else
			bf.canSkill = true
			T1RoundStart(bf)
		end
		
	elseif roundName == "super" then
		--#end of supr round
		bf.canSkill = false
		mView.changeLottery(bf,mConf.LotteryType.Battle)
		mView.startPreLottery(bf)
		mView.removeDouble(bf)
		bf.double = false
		T2RoundStart(bf)
	elseif roundName == "Team1" then
		--#end of Team1 round
		bf.canSkill = false
		mView.changeLottery(bf,mConf.LotteryType.Battle)
		mView.startPreLottery(bf)
		mView.removeDouble(bf)
		bf.double = false
		bf.superFactions = -1
		T2RoundStart(bf)
	elseif roundName == "Team2" then
		--#end of Team2 round
		bf.canSkill = true
		mView.collectGold(bf)
		mView.startUserBattleLottery(bf)	
		bf.canLottery = true
		bf.firstLottery = true	
	end
end
--已经播放完的战报回调
function onActionEndCallBack(bf)
	--print ("onActionEndCallBack")
	if bf.error == true then
		mView.notSync(bf)
		return
	end
	--if bf.roundNum >= 100 then
		--return 
	--end
	--print ("onActionEndCallBack")
	xpcall(function()
		local minTime = getMinResumeTime (bf)
		if minTime >= mConf.timeMax then
			--#endRound 
			--print ("end Round #"..bf.roundStatus)
			if bf.endRoundHandler then
				bf.endRoundHandler(bf,bf.roundStatus)
			else
				defaultEndRoundHandler(bf,bf.roundStatus)
			end
			return 
		end
		--print ("time Up",minTime,bf.time)
		if minTime >= bf.time then
			bf.time = minTime 
		end
		--print ("startResume~")
		startResume(bf)
	end,errorHandler,bf)
	return bf
end

function startBattle(bf)
	bf.roundNum = 1
	bf.playList = {}
	--if bf.noButton == false then
	bf.canLottery = true
	bf.firstLottery = true	
	--end
	bf.time = 0
	--创建每一个角色的协程 
	--本战斗是使用协程的方式实现
	for i,v in pairs(bf.team1.roleMap) do
		mSkill.initPassive(bf,v)
		createCo(bf,v)
		v.resumeTime = mConf.timeMax
		v.status = mConf.ROLE_STATUS.STAND
	end
	for i,v in pairs(bf.team2.roleMap) do
		mSkill.initPassive(bf,v)
		createCo(bf,v)
		v.resumeTime = mConf.timeMax
		v.status = mConf.ROLE_STATUS.STAND
	end
	--初始化最大血量
	for i,v in pairs(bf.team1.roleMap) do
		--if v.type == mConf.ROLE_TYPE.player then
			v.hp = mNum.getHpMax(bf,v)
			v.notInit = false
		--end
	end
	for i,v in pairs(bf.team2.roleMap) do
		--if v.type == mConf.ROLE_TYPE.player then
			v.hp = mNum.getHpMax(bf,v)
			v.notInit = false
		--end
	end	

	bf.roundStatus = bf.initRoundName
	if bf.startTeam == 1 then
		bf.t1 = bf.team1
		bf.t2 = bf.team2
	else
		bf.t2 = bf.team1
		bf.t1 = bf.team2
	end
	mView.roundChange(bf,bf.roundNum-1)
	mView.startPreLottery(bf)
	if bf.type ~= 1 then
		mView.getNextAction(bf)
	end
end


function initbf(type)
	if type == nil then
		type = 1
	end
	local bf            ={}
	bf.checkBattleEnd = false
	bf.type = type
	bf.id               =1
	bf.mode             =1
	bf.roundNum         =1
	bf.status           ="running"
	bf.attackTarget     =-1
	bf.attackCharId     =1	
	bf.canSkill = true
	bf.startTeam = 1
	bf.teamHurt = {0,0}
	bf.canLottery = false
	if C_CLOCK then
		bf.startTime = C_CLOCK()
	end
	bf.drop = {
		gold = 0,
		exp  = 0,
		item = {},
	}
	bf.lotteryRefCnt = mConf.ReLotteryCnt
	if type == 1 then
		bf.autoFlag =false
		bf.doubleLottery = false
		bf.startTeam = 1
		bf.initRoundName = "Team2"
		bf.endRoundHandler  = defaultEndRoundHandler
		bf.noButton = false
		bf.noReborn = false
	elseif type == 2 then
		bf.autoFlag =true
		bf.doubleLottery = true
		bf.startTeam = 1
		bf.initRoundName = "Team2"
		bf.endRoundHandler = pvpEndRoundHandler
		bf.noButton = true
		bf.noReborn = true

	elseif type == 3 then
		bf.autoFlag = true
		bf.doubleLottery = false
		bf.startTeam = 1
		bf.initRoundName = 0
		bf.endRoundHandler = newGuideHandler
		bf.noSpAdd = true
		bf.noButton = false
		bf.noReborn = true
	end
	return bf
end
function initTeam(id)
	local team   = {}
	team.id      = id
	team.teamId  = id
	team.type    = 1
	team.status  = 0
	team.roleMap = {}
	team.passive = {} -- 队伍级passive

	return team
end