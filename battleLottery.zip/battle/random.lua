local math,table,tonumber,pairs=math,table,tonumber,pairs
module("battle.random", package.seeall)
sequence = {}
useCnt = 0
radnomMax = 15
needServer = false
Baseprime = 777777
recodeFile = nil
math.randomseed(os.time())
function getInitSequence()
	if needServer  then
		return
	end
	for i=1,radnomMax do
		table.insert(sequence,math.random(1,10000))
	end
	useCnt =0 
end
function setSequence(seq,file )
	sequence = seq
    radnomMax = #sequence
    useCnt = 0
    if debugBattle then
	    recodeFile = file
	end
end
function getNextRandom()
	--print ("userCnt",useCnt)
	local mod = math.mod(useCnt,radnomMax)
	--local fl = math.floor(useCnt/radnomMax)
	useCnt = useCnt + 1
	return sequence[ mod+1]+useCnt*(useCnt + 1)
end

function getRandom(s,e)
	--e = e+1
	--s = s -1
	local random = getNextRandom()
	local ret = random %(e-s + 1) + s
	if recodeFile then
		local file = io.open(recodeFile,"a+")
		file:write(random..","..ret.."\n")
		file:close()
	end
	return ret
end

