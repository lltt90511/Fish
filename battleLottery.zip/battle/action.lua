local math,table,tonumber,pairs=math,table,tonumber,pairs
local getn = getn
local mConf = require ("battle.conf")
local mView = require("battle.view")
local mNum = require("battle.numerial")
local mSelect=require("battle.select")
local mRandom=require("battle.random")
local mGameData = require ("template.gamedata")
local gamedata = mGameData.data
local AnimSpeed = mConf.AnimSpeed
module("battle.action",package.seeall)
function checkDead(bf,role)
	if role.status == mConf.ROLE_STATUS.PREDEAD or role.status == mConf.ROLE_STATUS.DEAD  then
		return true
	else
		return false
	end
end
function reduceHpCmd(bf,role,form,minus,notCreateHurt,time,super,superHit)
	minus=math.floor(minus)
	if minus>99999 then
		minus=99999
	end
	if time == nil then
		time = 1
	end
	local oldPercent = mNum.getHpPercent(bf,role)
	mNum.reduceHp(bf,role,minus*time)
	if time == nil then
		time = 1
	end
	if minus >0 then
		bf.teamHurt[role.teamId] = bf.teamHurt[role.teamId]  + minus
		if role.type == mConf.ROLE_TYPE.pve then
			--changeSp(bf,role,mRandom.getRandom(30,30))
		else
			--changeSp(bf,role,mRandom.getRandom(3,5))
		end
		if  super == true or form ~= nil  then
			if role.hit == nil then
				role.hit = 0
			end
			
			local curHp = minus/time
			local name = "召唤兽"
			if form ~= nil then
				name = form.name
			end
			if role.type == mConf.ROLE_TYPE.pve  then
				local goldAll = 0
				for i=1,time do
					if role.limitGod <= 0 then
						break
					end
					local factor = curHp/mNum.getHpMax(bf,role)
					if factor > 1 then
						factor = 1
					end
					local gold = math.ceil(role.lv * role.gold*factor*(role.hit+i))
					if gold > role.limitGod then
						gold = role.limitGod
					end
					role.limitGod = role.limitGod - gold
					goldAll = goldAll + gold
					mView.addGoldNoMove(bf,role.id,gold)
					bf.drop.gold = bf.drop.gold + gold
				end

				mView.addLog(bf,"【"..name.."】对 【"..role.name.."】造成了"..minus.."点伤害同时获得"..goldAll.."金币")
			else
				mView.addLog(bf,"【"..name.."】对 【"..role.name.."】造成了"..minus.."点伤害")
			end
			role.hit = role.hit  +  time
		end
	else
		mView.addLog(bf,"【"..role.name.."】恢复了"..(-minus).."点hp")
	end
	local factions = nil
	if form ~= nil then
		factions = form.factions
	else
		factions = role.factions
	end
	local hit = role.hit
	if hit == nil then
		hit = 0
	end
	if  (form == nil or form.type == mConf.ROLE_TYPE.pve) then
		hit = -time
	end
	print ("######end Of ReduceHp",mNum.getBattleHp(bf,role))
	if mNum.getBattleHp(bf,role) <= 0 then
		mView.redeceHpCmd(bf,role.id,minus*time,oldPercent,0,bf.time,0,factions,notCreateHurt,time,hit,superHit)
		role.status = mConf.ROLE_STATUS.PREDEAD
	else
		mView.redeceHpCmd(bf,role.id,minus*time,oldPercent,mNum.getHpPercent(bf,role),bf.time,0,factions,notCreateHurt,time,hit,superHit)
		
	end
end

function changeSp(bf,role,sp,special)
	local mBuff = package.loaded["battle.buff"]
	local buff = mBuff.checkHasBuff(bf,role,"passionR")

	if buff > 0 then
		sp  = math.floor(sp*(100+gamedata["buff"][buff]))
	end
	if bf.noSpAdd ==true and  special ~= true and sp >0 then
		return 
	end
    role.power = role.power + sp
    if role.power  > #role.skill * 100 then
    	role.power  = #role.skill * 100
    end
    if role.power <0 then
        role.power = 0
    end
--    print (debug.traceback())
    mView.addLog(bf,"【"..role.name.."】恢复了"..sp.."点sp 当前sp:"..role.power)
    mView.changeSp(bf,role.id,role.power)
end

function moveTo(bf,role,target,callback)
	--print ("moveTo#########################",role.id,target.id)
	local need = 0
	if role.runTime == 0 then
		return 
	end
	if role.status == mConf.ROLE_STATUS.DEAD then
		if callback then
			return
		else
			role.resumeTime = mConf.timeMax
			coroutine.yield()
		end
	end
	if role.id == target.id  then
		-- pos是现在所处的位置的英雄
		if role.pos ~= role.id then
			mView.runCmd(bf,role.id,role.id,bf.time,true,role.runTime/AnimSpeed)
			need = role.runTime/AnimSpeed
			role.pos = role.id
		end
	else 
		if role.pos ~= target.id then
			mView.runCmd(bf,role.id,target.id,bf.time,false,role.runTime/AnimSpeed)
			need = role.runTime/AnimSpeed
			role.pos = target.id
		end
	end
	if callback ~= true then
		role.resumeTime = bf.time + need
		coroutine.yield()		
		role.resumeTime = mConf.timeMax
		coroutine.yield()
	else
		if need > 0 then
			role.resumeTime = bf.time + need
			coroutine.yield()
		end
	end
end
function removeAllTarget(bf,attcker)
	if attcker.targetList then
		for i,v in pairs(attcker.targetList) do
			removeFromHurtList(bf,attcker,v)
		end
		attcker.targetList = {}
	end
end

function addTarget(bf,attcker,hurter)
	if hurter.hurtList == nil then
		hurter.hurtList = {}
	end
	if attcker.targetList == nil then
		attcker.targetList = {}
	end
	table.insert(attcker.targetList,hurter)
	table.insert(hurter.hurtList,attcker)
end

function removeFromHurtList(bf,role,target)
	print ("@@@@@@@@@@@@@removeFromHurtList",role.id,target.id)
	local hurt = true
	if target.hurtList then
		for i,v in pairs(target.hurtList) do
			if v.id == role.id then
				--hurt = true
				target.hurtList[i] = nil
			else
				-- 有其他玩家还在攻击的时候交给其他玩家处理
				hurt = false
			end
		end
	end
	if hurt  then
		if target.status == mConf.ROLE_STATUS.PREDEAD then
			--print ("dead")
			print ("@@@@@@@@@@@@@clean")
			dead(bf,target)
			if target.status == mConf.ROLE_STATUS.DEAD then
				if role.type == mConf.ROLE_TYPE.pve then
					changeSp(bf,role,20)
				else
					changeSp(bf,role,15)
				end
			end
			--print ("#dead")
		end
	end
end

function dead(bf,role)
	local mSkill = package.loaded['battle.skill']
	local isRes=false
	local hasResurrectionSkill=mSkill.checkHasPassSkill(bf,role,"resurrection")
	local hasResurrectionMaxSkill=mSkill.checkHasPassSkill(bf,role,"resurrectionMax");
	if hasResurrectionSkill>0 then
		local propNum=mSkill.getPassivePropNumInt(hasResurrectionSkill);
		local rondom = mRandom.getRandom(0,100)
		if rondom<propNum then
			isRes=true
		end
	end
	if hasResurrectionMaxSkill>0 then
		local propNum=mSkill.getPassivePropNumInt(role,hasResurrectionMaxSkill);
		local rondom = mRandom.getRandom(0,100)
		if rondom<propNum then
			isRes=true
		end
	end
	
	if isRes==true then
		print("##############hasResurrectionMaxSkill")
		if hasResurrectionMaxSkill>0 then
			role.hp=0
		else
			role.hp=math.floor(mNum.getHpMax(bf,role)*0.15)
		end
		mView.ReviveCmd(bf, role.id,bf.time,role.minusHpTotal)
	else	
		--mView.userTalk(bf,role.id,role.name,"我还会回来的")
		mView.dieCmd(bf, role.id,bf.time)
		role.status = mConf.ROLE_STATUS.DEAD
		role.resumeTime = mConf.timeMax
		cleanDead(bf,role)
	end
end

function cleanDead(bf,role,backList)
	mView.addLog(bf,"【"..role.name.."】死亡",3)
	local team = mSelect.selfTeam(bf,role)
	local cnt = 0
	for i,v in pairs(team.roleMap) do
		if v.status ~= mConf.ROLE_STATUS.DEAD then
			cnt = cnt + 1
		end
	end
	role.buff = {}
	role.sp = 0
	local selfTeam = mSelect.selfTeam(bf,role)
	local oppoTeam = mSelect.oppositeTeam(bf,role)
	for i,v in pairs(selfTeam.passive) do
		if v.roleid == role.id then
			table.remove(selfTeam.passive,i)
		end
	end
	for i,v in pairs(oppoTeam.passive) do
		if v.roleid == role.id then
			table.remove(oppoTeam.passive,i)
		end
	end
	if role.type == mConf.ROLE_TYPE.pve then
		local exp =  role.exp*role.lv
		if bf.specialEffect == 4 then
			exp  = math.ceil(exp*1.5)
		end
		mView.dropExp(bf,role.id,exp)
		bf.drop.exp = bf.drop.exp + exp
		mView.addLog(bf,"获得"..exp.."点神力")

		print ("#role.dropItemList " ..#role.dropItemList)
		if #bf.drop.item ==0 then
			--只掉落一个
			for i,v in pairs(role.dropItemList) do
				local ran = mRandom.getRandom(0,100)
				local percent = v.percent
				if bf.specialEffect == 3 then
				   percent = percent * 2
				end
				if ran <= percent then
					local name = "未知"
					if gamedata['badge'][v.id] then
						name = gamedata['badge'][v.id].name
					end
					mView.addLog(bf,"获得徽章【"..name.."】")
					mView.dropItem(bf,role.id,v.id)	
					table.insert(bf.drop.item,{id=v.id})
					break
			    end		
			end
		end
		--mView.dropItem(bf,role.id,id)
	end
	if role.fragmentDrop then
		mView.dropItem(bf,role.id)	
		bf.drop.fragmentDrop = role.fragmentDrop
	end

	if cnt == 0 then
		-- 战斗结束
		mView.addLog(bf,"本场战斗结束",1)
		print ("战斗结束！！！！！")
		bf.checkBattleEnd = true
		bf.checkTeam = team.teamId
		bf.canSkill = false
		mView.lastKillEffect(bf)
		--mView.nextActionDelay(bf,1)
		--[[
		for i,v in pairs(bf.team1.roleMap) do
			if v.status ~= mConf.ROLE_STATUS.DEAD then
				if v.pos ~= v.id then
					mView.runCmd(bf,v.id,v.id,bf.time,true,v.runTime)
					v.pos = v.id
				end
				v.status = mConf.ROLE_STATUS.STAND
				v.resumeTime = mConf.timeMax
			end
		end
		for i,v in pairs(bf.team2.roleMap) do
			if v.status ~= mConf.ROLE_STATUS.DEAD then
				if v.pos ~= v.id then
					mView.runCmd(bf,v.id,v.id,bf.time,true,v.runTime)
					v.pos = v.id
				end
				v.status = mConf.ROLE_STATUS.STAND
				v.resumeTime = mConf.timeMax
			end
		end

		battleEnad(bf,team.teamId)
		]]
	end
	--role.resumeTime = mConf.timeMax
end

function battleEnad(bf)
	-- 战斗结束
	local teamId = bf.checkTeam
	
	if teamId == 2 then
		print("###########victory")
		bf.status = "victory"
		
		mView.collectItem(bf)
		mView.collectExp(bf)
		mView.collectGold(bf)
		mView.nextActionDelay(bf,0.5)

		
		mView.VictoryEffect(bf)
		local gold = bf.drop.gold
		-- 摇金币加成
		--mView.resultGoldShow(bf,gold)
		--mView.changeLottery(bf,mConf.LotteryType.Victory)
		--local lottery = getVictoryLotty(bf)
		--mView.startLotteryForVictory(bf,lottery)
		--mView.goldChangeEffect(bf,lottery.changegold)
		--mView.resultGoldOver(bf,gold,bf.drop.gold)
		--mView.waitForLottery(bf)
	else
		print("###########lose")
		bf.status = "lose" 
	end

end