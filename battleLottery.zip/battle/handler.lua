local regListner = regListner
local pve = require ("battle.pve")
module("battle.handler")
regListner("onNewPveBattleSucceed",pve.onStartPveBattle)
regListner("onBattleEndFailed",pve.noBattleFromServer)
regListner("onBattleEndSucceed",pve.onBattleEnd)
