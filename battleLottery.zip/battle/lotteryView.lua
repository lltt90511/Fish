local oldPerformWithDelay = performWithDelay
local printTable,math,coroutine = printTable,math,coroutine
local view = require("battle.view")
--local server= require ("battle.server")
local tool = require("scene.tool")
local battle = require ("battle.battle")
local conf = require("battle.conf")
local mConf = conf
local mGameData = require ("template.gamedata")
local mPve = require("battle.pve")
local gamedata = mGameData.data
local mNum = require("battle.numerial")
local effect = require("battle.effect")
local alert = require("scene.alert")
local event = require"logic.event"
local countLv = require"logic.countLv"

module("battle.lotteryView", package.seeall)

laohujiIcon = mConf.laohujiIconPvp


local performWithDelayBattle 
local createEffect
local createGroupEffect
local bezier 
local createEnterEffect
local createExitEffect
local widget
local scene 
local startBtnEnable
local this
panelView = {}
door = {}
function initLotteryStatus()
	scene = package.loaded['battle.scene']
	performWithDelayBattle =scene.performWithDelayBattle 
	createEffect =scene.createEffect
	createGroupEffect =scene.createGroupEffect
	bezier  =scene.bezier
	createEnterEffect =scene.createEnterEffect
	createExitEffect =scene.createExitEffect
	widget = scene.widget
	startBtnEnable = scene.startBtnEnable
	this = scene.this
    laohujiView ={}
    panelView = {}
    nowLottery = -1
    for i= 1,5 do
    	createLotteryRow(i)
    end
    door  = {
        top = widget.laohuji.face.top.obj,
        topMove = widget.laohuji.face.top.move.obj,
        bottom = widget.laohuji.face.bottom.obj,
        bottomMove = widget.laohuji.face.bottom.move.obj,
    }
    door.topPos = tool.getPosition(door.top)
    door.bottomPos = tool.getPosition(door.bottom)
    door.topMove:setTouchEnabled(true)
    door.bottomMove:setTouchEnabled(true)
    door.open = false
end
function closeDoor (callBack)
    if door.open == false then
        if callBack then
            callBack()
        end
        return
    end
    tool.setPosition(door.top,door.topPos)
    tool.setPosition(door.bottom,door.bottomPos)
  
    createEnterEffect(door.top,{x=0,y=50},0.1)
    createEnterEffect(door.bottom,{x=0,y=-50},0.1,function ()
        door.topMove:setVisible(true)
        door.bottomMove:setVisible(true)
        createEnterEffect(door.topMove,{x=0,y=-220},0.5,callBack)
        createEnterEffect(door.bottomMove,{x=0,y=-220},0.5)
    end)
    door.open = false
end
function openDoor ()
    if door.open == true then
        return
    end
    createExitEffect(door.topMove,{x=0,y=-220},0.5,true)
    createExitEffect(door.bottomMove,{x=0,y=-220},0.5,true,function ()
        door.topMove:setVisible(false)
        door.bottomMove:setVisible(false)
        createExitEffect(door.top,{x=0,y=50},0.5,false)
        createExitEffect(door.bottom,{x=0,y=-50},0.5,false)
    end)
    door.open = true
end
function createLotteryRow(id)
	panelView[id] = {}

	local info = panelView[id]
	info.parent = widget.laohuji.bg["panel_"..id].obj
	local size = info.parent:getSize()
	info.width  = size.width
	info.height = size.height
	info.childHeight = size.height/4
	info.heightUnit = size.height/8  -- 度量单位 标准1 球直径为 2，球和球之间间距是 2 
	local  heightUnit = size.height/8 
	info.ballHeight = 2 -- 直径
	info.ballDis =    2 -- 间距
	info.childList = {}
	for i=1,3 do
		local child = ImageView:create()
		local currentPos = ((i-1)*(info.ballHeight + info.ballDis)+1)
		child:loadTexture( mConf.laohujiIconV[1].image)
		child:setPosition(ccp(info.width/2,info.height-(currentPos*heightUnit - heightUnit)))
        shadow = tolua.cast( child:clone() , "ImageView")
		info.parent:addChild(child,2)
        info.parent:addChild(shadow,1)
        shadow:setOpacity(75)
		table.insert(info.childList,{shadow= shadow,obj=child,initPos=currentPos,currentPos=currentPos,texture=0})
	end
	info.setTextureList = function (list)

		info.list =  list
		info.listSize = #list
		for i=1,3 do
			local id = ((3-i) ) % info.listSize + 1
			info.childList[i].texture = info.list [id]
			info.childList[i].obj:loadTexture(laohujiIcon[info.childList[i].texture].image)
			info.childList[i].obj:setPosition(ccp(info.width/2,info.height-(info.childList[i].initPos*heightUnit - heightUnit)))
            info.childList[i].shadow:loadTexture(laohujiIcon[info.childList[i].texture].image)
		end
        
	end
	info.setTextureListAfterRunning = function(list)
		local l = {}
		for i=1,3 do
			table.insert(l,info.childList[4-i].texrure)
		end
		for i=1,#list do
			table.insert(l,list[i])
		end
		info.list =  l
		info.listSize = #l
		info.afterRunningRemoveFirst = true
	end

	info.handler = nil
	local start = 0.5
	local endSpeed = 40
	local endPos  = start*endSpeed/2 

	info.countCurrentPosAndTexture = function (now)
		
		local diff = now - info.startTime 
		local diffPos = 0
		-- 加速度
		if diff < start then
			diffPos = diff*diff/start*endSpeed/2 
		elseif diff >= start then
			diffPos = (diff-start) * endSpeed +endPos
		end
		for i,v in pairs(info.childList) do
            if diff < start or ( info.limitTime and now >= info.limitTime )  then
                v.shadow:setVisible(false)
            else
                v.shadow:setVisible(true)
                v.shadow:setPositionY(v.obj:getPositionY())
                v.shadow:setZOrder(size.height-v.obj:getPositionY())
            end
            
            local oldY = v.obj:getPositionY()
			local pos = v.initPos + diffPos
			local curPos = pos %12
			v.currentPos = curPos
			v.obj:setPositionY(info.height-(curPos*heightUnit - heightUnit))
            v.obj:setZOrder(size.height-v.obj:getPositionY())
			local time = math.floor(pos / 12)
			local currentTexture = ((3-i) + 3*time ) % info.listSize + 1
			local texId = info.list[currentTexture]
			if time >= 2 and info.afterRunningRemoveFirst  then
				info.afterRunningRemoveFirst  = false
				local l = info.list
				info.list = {}
				for i=4,#l do
					table.insert(info.list,l[i])
				end
				info.listSize = #info.list
			end
			v.textListId = currentTexture
			if v.texrure ~= texId then
				v.texrure = texId
                if v.texrure > #laohujiIcon then
                    v.texrure = #laohujiIcon
                end
				v.obj:loadTexture(laohujiIcon[v.texrure].image)
                v.shadow:loadTexture(laohujiIcon[v.texrure].image)
			end
		end
	end
	info.start = function ()
		local func = nil
		info.startTime = C_CLOCK()
		info.stopLimitTime = info.startTime + 1.5*start
		info.limitTime = nil
        local now = 0
        local c
		func = function ()
			now =  C_CLOCK()
			if info.limitTime and now >= info.limitTime then
				info.countCurrentPosAndTexture(info.limitTime)
				AudioEngine.playEffect("effect_"..(16+id))
				info.handler = nil
				--info.endEffect()
				if info.stopCall then
					c = info.stopCall 
					info.stopCall = nil
					c()
				end
			else
				info.countCurrentPosAndTexture(now)
				info.handler = tool.createEffect(tool.Effect.delay,{time=1/45},info.parent,func,true)
			end
			
		end
		func()
	end
	info.stop = function()
		--计算大家当前的位置 找到小于中线的孩子
		local now =  C_CLOCK()
		if now < info.stopLimitTime then
			now = info.stopLimitTime
		end
		info.countCurrentPosAndTexture(now)
		local max = 0 
		local child = nil
		for i,v in pairs(info.childList) do
			if v.currentPos <= 5 then
				if v.currentPos > max  then
					max =v.currentPos
					child = v
				end
			end
		end
		assert(child,"?????????child not exit!!!!")
		-- 计算停下来的时间
		local dis = 5 - child.currentPos 
		local time = dis / endSpeed
		info.limitTime  = time + now
		return child.texrure
	end
	info.stopWithTexture = function (texrure,timeDelay)
		local now =  C_CLOCK()
		if now < info.stopLimitTime then
			now = info.stopLimitTime
		end
		info.countCurrentPosAndTexture(now+timeDelay)
		local max = 0 
		local child = nil
		local childId = 0
		for i,v in pairs(info.childList) do
			if v.currentPos <= 5 then
				if v.currentPos > max  then
					max =v.currentPos
					child = v
					childId = i
				end
			end
		end
		assert(child,"?????????child not exit!!!!")	
		local dis = 5 - child.currentPos 
		local time = dis / endSpeed
		info.limitTime  = time + now + timeDelay
		info.list[child.textListId] = texrure
        info.delayTime = timeDelay + now
        info.delayTexure = texrure
		info.countCurrentPosAndTexture(now)
	end
    info.stopNow = function ()
        if info.delayTime == nil then
            return false
        end
        local time  = C_CLOCK() 
        if time >= info.delayTime then
            return false
        end
        info.stopWithTexture(info.delayTexure,0)
        return true
    end
	info.stopCurrent = function ()
		if info.handler  then
			info.parent:stopAction(info.handler)
			info.handler = nil
		end
	end
	info.setVisible = function (flag)
		info.parent:setVisible(flag)
	end
	--info.start()
end
function stopRunning()
	return panelView[2].stop()
end
function exit()
	for i,v in pairs(panelView) do 
        local obj = v.parent
        obj:stopAllActions()
    end
    panelView = {}

    scene = nil
	performWithDelayBattle =nil
	createEffect =nil
	createGroupEffect =nil
	bezier  =nil
	createEnterEffect =nil
	createExitEffect =nil
	widget = nil
	startBtnEnable = nil
	this = nil
    laohujiView ={}
    panelView = {}
end
function switchAnim(stoped)
	if stoped == true then 
		for i = 1,5 do
            local obj = panelView[i].parent
            obj:getActionManager():pauseTarget(obj)
        end
     else
  		 for i = 1,5 do
			local obj = panelView[i].parent
			obj:getActionManager():resumeTarget(obj)
        end
     end
end


lotteryData = {}
allLotteryData = {}
normal = true
five   = false
nowLottery = -1
function initLottery(t,callBack,first,five,init)
    if nowLottery == t  then
        if callBack then
            callBack()
        end
        return 
    end
    local oldLottery = nowLottery
    nowLottery = t

    if t== mConf.LotteryType.PVE then
        laohujiIcon = mConf.laohujiIconPve
    elseif t== mConf.LotteryType.Battle then
        laohujiIcon =  mConf.laohujiIconPvp
    elseif t == mConf.LotteryType.BattleS then
        laohujiIcon =  mConf.laohujiIconPvpS
    else
        laohujiIcon =  mConf.laohujiIconV
    end
    local laohuji = widget.laohuji.obj
    --laohujiView ={}
    local laohujiParent = widget.laohuji.obj
    -- load所有贴图
    local change = function ()
        for i = 1,5 do
            panelView[i].setTextureList(getRadnomList())
        end
        if five == true then
            widget.laohuji.bg.left.obj:setVisible(false)
            widget.laohuji.bg.right.obj:setVisible(false)
            panelView[1].setVisible(true)
            panelView[5].setVisible(true)
        else
            widget.laohuji.bg.left.obj:setVisible(true)
            widget.laohuji.bg.right.obj:setVisible(true)
            panelView[1].setVisible(false)
            panelView[5].setVisible(false)
        end
        if t == mConf.LotteryType.BattleS then
            performWithDelay(openDoor,0.2)
        end
       -- if t == mConf.LotteryType.PVE  then
        if callBack then
             if t == mConf.LotteryType.PVE  then
                callBack()
            else
                performWithDelay(callBack,0.2)
            end
        end
    end
    if first ~= true then
        if false then
            local old = tolua.cast( widget.laohuji.obj:clone(),"Widget")
            local new = widget.laohuji.obj
            local pos = tool.getPosition(new)
            widget.obj:addChild(old)
            old:setPosition(ccp(pos.x,pos.y))
            if t < nowLottery  then
                tool.setPosition(new,pos,{x=-640,y=0})
                createEffect(tool.Effect.move,{x=640,y=pos.y,time= 0.4},old)
                createEffect(tool.Effect.move,{x=640-pos.x,y=pos.y,time= 0.4},new,callBack)
            else
                tool.setPosition(new,pos,{x=640,y=0})
                createEffect(tool.Effect.move,{x=-640,y=pos.y,time= 0.4},old)
                createEffect(tool.Effect.move,{x=-640+pos.x,y=pos.y,time= 0.4},new,callBack)
            end
            callBack = nil
        end
        closeDoor(change)
    else
        change()
    end
    --pve.lotteryType = t

end
function getRadnomList()
	local randomList = {}
    for j=1,1000 do
        local create = false
        if j~= 1 then
            --percent = {first=20,runningSame=50,sameTwo =15,sameThree=10 }, 
            local last = randomList[j-1]
            local percent = laohujiIcon[last].percent
        	local res =	math.random(1,100)

        	if res < percent.runningSame  and j~=1 then
                create = true
        		table.insert(randomList, randomList[j-1])
        	end
        end
        -- 一图概率
        if not create then
            local all = 0
            
            for i,v in pairs(laohujiIcon) do
                all = all + v.percent.first
            end
            local random = math.random(1,all)
            for i,v in pairs(laohujiIcon) do
                if random <= v.percent.first then
                    table.insert(randomList, i)
                    break
                else
                    random = random  - v.percent.first 
                end
            end
        end
   	end
   	return randomList
end

function startPreLottery(action)
    openDoor ()
    startBtnEnable(false)
    startLottery(true,false)
    print("############################",action.flag)
    if action.flag == 1  or action.flag == true then
    	-- 特殊需求一 转完一圈 全部变成刀
    	for i=2,4 do
    		panelView[i].setTextureListAfterRunning({1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1})
    	end
    else
        for i=2,4 do
    		panelView[i].setTextureListAfterRunning(getRadnomList())
    	end	
    end
end

lotteryEffect = {   
    water={image="ball/water.png",scale = 1,r=62,g=209,b=255},
    fire={image="ball/fire.png",scale = 1,r=215,g=50,b=32},
    wood={image="ball/wood.png",scale = 1,r=70,g=218,b=21},
    heart = {image="ball/heart.png",scale = 1,r=252,g=103,b=156},
    fist={image="ball/boxing.png",scale = 1,r=228,g=150,b=36},
    angle={image="ball/crystal.png",scale = 1,r=0,g=0,b=0},
}
function LotteryEndEffect(action)
    if action.effectRoleList == nil or #action.effectRoleList == 0 then

        return
    end
    -- 获取位置
    local IconList = {}
    print (action.num)
    if action.five == true then
        for i=1,action.num do
        	local info = panelView[i]
        	for i,v in pairs(info.childList) do
        		if math.abs( v.currentPos -5.0)<1 then
        			  table.insert(IconList,{
        			  	x=v.obj:getPositionX()+ info.parent:getPositionX(),
        			  	y=v.obj:getPositionY()+ info.parent:getPositionY()
        			  	})
        		end
        	end
        end
    else
        for i=1,action.num do
        	local info = panelView[i+1]
        	for i,v in pairs(info.childList) do
        		if math.abs( v.currentPos -5.0)<1 then
        			  table.insert(IconList,{
        			  	x=v.obj:getPositionX()+ info.parent:getPositionX(),
        			  	y=v.obj:getPositionY()+ info.parent:getPositionY()
        			  	})
        		end
        	end
        end      
    end
    printTable(IconList)
    local allAction = #IconList * #action.effectRoleList
    local callBack = scene.startPlay
    for i,v in pairs(IconList) do
        -- 确定 icon 在世界中的位置
        local x,y = v.x+widget.laohuji.obj:getPositionX()+widget.laohuji.bg.obj:getPositionX(),v.y+widget.laohuji.obj:getPositionY()+widget.laohuji.bg.obj:getPositionY()
        local ps = CCParticleSystemQuad:create("effect/lotteryEnd.plist")

        local info = nil
        if action.super  == true then
            if action.type == conf.SUPER.id.fist then
                info=lotteryEffect.fist
            elseif action.type == conf.SUPER.id.angle then 
                info=lotteryEffect.angle
            end
        else
            if action.type == conf.NORMAL.id.wind then
                info=lotteryEffect.water
            elseif action.type == conf.NORMAL.id.fire then 
                info=lotteryEffect.fire
            elseif action.type == conf.NORMAL.id.wood then 
                info=lotteryEffect.wood
            elseif action.type == conf.NORMAL.id.heart then 
                info=lotteryEffect.heart
            end
        end
        ps:setStartColor(ccc4f(info.r/255,info.g/255,info.b/255,1))
        ps:setPosition(ccp(x,y))
        --ps:setTexture(CCTextureCache:sharedTextureCache():addImage(info.image))
        this:addChild(ps)
        performWithDelayBattle(function()
            ps:stopSystem()
            for ii,roleid in pairs(action.effectRoleList) do
                -- 确定人物的位置
                local x2,y2 = scene.getRoleWorldPos(roleid)
                local layout = tolua.cast(Layout:create(),"Layout")
                local image = CCParticleSystemQuad:create("effect/lottery.plist")
                image:setStartColor(ccc4f(info.r/255,info.g/255,info.b/255,186/255))
                layout:addNode(image)
                image:setPosition(ccp(0,0))
                this:addChild(layout,9999)
                layout:setPosition(ccp(x,y))
                performWithDelayBattle(function()
                    bezier(layout,{x=x,y=y},{x=x2,y=y2},1+math.random(-10,10)/100,function()
                        if action.shadowEffect == true then
                            scene.addShadowSize(roleid)
                        end
                        image:stopSystem()
                        image:removeFromParentAndCleanup(true)
                        layout:removeFromParentAndCleanup(true)
                        allAction = allAction - 1
                        if allAction <= 0 then
                            local c = callBack
                            callBack = nil 
                            c()
                        end
                    end)
                end,ii*0.01)

            end
        end,(i-1)*0.1)

    end
    if allAction <= 0 then
        local c = callBack
        callBack = nil 
        c()
    end
    return "stopAction"
end
function stopNow(i)
     panelView[i].stopNow()
end
function stopLottery(data,super,now)
    allLotteryData = data
    local diffTime = 0.4
    local startTime = 0.2
    if now == true then
        diffTime = 0
        startTime = 0
    end
    if super == true then
        lotteryData = allLotteryData.super
        if five then
	        panelView[1].stopWithTexture(lotteryData[1],startTime)
	        panelView[2].stopWithTexture(lotteryData[2],startTime+diffTime*1)
	        panelView[3].stopWithTexture(lotteryData[3],startTime+diffTime*2)
	        panelView[4].stopWithTexture(lotteryData[4],startTime+diffTime*3)
	        panelView[5].stopWithTexture(lotteryData[5],startTime+diffTime*4)
	        panelView[5].stopCall = function ()
	        	lotteryEnd()
	    	end
	    else
	    	panelView[2].stopWithTexture(lotteryData[1],startTime)
	        panelView[3].stopWithTexture(lotteryData[2],startTime+diffTime*1)
	        panelView[4].stopWithTexture(lotteryData[3],startTime+diffTime*2)
	        panelView[4].stopCall = function ()
	        	lotteryEnd()
	    	end
	    end
    else
        lotteryData = allLotteryData.normal
        if panelView[2].limitTime == nil then
        	panelView[2].stopWithTexture(lotteryData[1],startTime)
        	panelView[3].stopWithTexture(lotteryData[2],startTime+diffTime*1)
        	panelView[4].stopWithTexture(lotteryData[3],startTime+diffTime*2)
        else
        	panelView[3].stopWithTexture(lotteryData[2],startTime+diffTime*1)
        	panelView[4].stopWithTexture(lotteryData[3],startTime+diffTime*2.5)
        end

 
        panelView[4].stopCall = function ()
        	lotteryEnd()
    	end
    	if allLotteryData.noReLottery ~=true then
	    	performWithDelayBattle(function ()
	    		startBtnEnable(true,true)
	    	end,0.1)
	    end
    end
    startBtnEnable(false)
end
function startLottery(_type,_five)
    -- 停止所有老虎机的动作
    --setDoubleTouchEnable(true)
    normal = _type
    five= _five
    if five then
		for i = 1,5 do
		  	panelView[i].start()
		end
	else
		for i = 2,4 do
		  	panelView[i].start()
		end
	    panelView[1].setVisible(false)
	    panelView[5].setVisible(false)
	end
    lotteryRunning = true
    --restartFlag = false
    AudioEngine.playEffect("effect_14")
    startBtnEnable(false)
end

--restartFlag =false
function reStartLottery()
    lotteryRunning = true
    startLottery(normal,five)
   -- restartFlag = true
    startBtnEnable(true)
    --startBtnEnable(false)
end

function lotteryEnd()
    startBtnEnable(false)
    local time = 1
    local data = allLotteryData 
    performWithDelayBattle(function ()
        AudioEngine.playEffect("effect_16")
    end,0.666)
    if data.supered ~= true then
        for i=1,3 do
            if data.normal[i] == data.normal[1] then
            	for i,v in pairs(panelView[i+1].childList) do
            		if math.abs( v.currentPos -5.0)<0.01 then
		                local action = CCBlink:create(time, time*3);
		                v.obj:runAction(action)   
		            end
	            end
            else
                break          
            end
        end
    else
        if data.five then
            for i=1,5 do
                if data.super[i] == data.super[1] then
	            	for i,v in pairs(panelView[i].childList) do
	            		if math.abs( v.currentPos -5.0)<0.01 then
			                local action = CCBlink:create(time, time*3);
			                v.obj:runAction(action)   
			            end
		            end
                else
                    break          
                end
            end
        else
            for i=1,3 do
                if data.super[i] == data.super[1] then
	            	for i,v in pairs(panelView[i+1].childList) do
	            		if math.abs( v.currentPos -5.0)<0.01 then
			                local action = CCBlink:create(time, time*3);
			                v.obj:runAction(action)   
			            end
		            end 
                else
                    break          
                end
            end
        end
    end
    --print ("Lottery performWithDelayBattle")
    performWithDelayBattle(function()
        if data.superFlag == false or data.supered == true then
            scene.setRefreshNum(mConf.ReLotteryCnt)
            widget.info.refresh_num.obj:setText(""..mConf.ReLotteryCnt )
            print("#end Lottery")
            scene.startPlay()
        else
            initLottery(mConf.LotteryType.BattleS,function ()
                data.supered = true
                normal =false 
                five = data.five
                startLottery(normal,five)
                stopLottery(data,true)
            end,nil,data.five)
        end
        --laohujiView[2][3].obj:setVisible(true)
    end,time+0.5)
end