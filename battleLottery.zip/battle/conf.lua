module("battle.conf", package.seeall)


NATURE = {
	wind 	= 1,
	fire 	= 2,
	wood 	= 3,		
}
ADD = {
	[NATURE.wind] = NATURE.fire,
	[NATURE.fire] = NATURE.wood,
	[NATURE.wood] = NATURE.wind,
}

ROLE_STATUS = {
	alive=1,
	dead=-1,
}

ROLE_TYPE = {
	player =1,
	pve    =2,
}

FIELD_TYPE={
	init      =0,
	battleing =1,
	endl      =2,
}

BATTLE_TYPE={
	point =1,
}

BATTLE_ACTION_TYPE={
	run                    = "run",  --跑动
	can_lottery            = "can_lottery" , --可以挥动老虎机
	lottery                = "lottery",
	revive                 = "revive",
	dodge                  = "dodge",
	parry                  = "parry",
	beHurt                 = "beHurt",
	preAttack              = "preAttack",
	endAttack              = "endAttack",
	redeceHp               = "redeceHp",
	die                    = "die",
	battleEnd              = "battleEnd",
	preSkill               = "preSkill",
	endSkill               = "endSkill",
	addBuff                = "addBuff",
	removeBuff             = "removeBuff",
	endRound               = "endRound",
	no_Lottery             = "noLottery",
	changeSp               = "changeSp",
	next_pve               = "next_pve",
	addGold                = "addGold",
	getNextAction          = "getNextAction",
	changeLottery          = "changeLottery",
	nextActionDelay        = "nextActionDelay",
	waitForLottery         = "waitForLottery",
	battleEndCallBack      = "BattleEndCallBack",
	startNewBattle         = "startNewBattle",
	pve_result             = "pve_result",
	startEvent             = "startEvent",
	pveOK                  = "pveOK",
	pveFailed              = "pveFailed",
	updatePvePrecent       = "updatePvePrecent",
	drug                   = "drug",
	bomb                   = "bomb",
	hit                    = "hit",
	addGoldNoMove          = "addGoldNoMove",
	collectGold            = "collectGold",
	startFriend            = "startFriend",
	startLotteryForVictory = "startLotteryForVictory",
	goldChangeEffect       = "goldChangeEffect",
	addExpNoMove           = "addExpNoMove",
	collectExp             = "collectExp",
	VictoryEffect          = "VictoryEffect",
	dropExp                = "dropExp",
	collectExp             = "collectExp",
	dropItem               = "dropItem",
	collectItem            = "collectItem",
	resultGoldShow         = "resultGoldShow",
	resultGoldOver         = "resultGoldOver",
	startPreLottery        = "startPreLottery",
	notSync                = "notSync",
	removeDouble           = "removeDouble",
	canDouble              = "canDouble",
	checkAutoLottery       = "checkAutoLottery",
	buffEffect             = "buffEffect",
	skillStartEffect       = "skillStartEffect",
	stopUserSkill          = "stopUserSkill",
	LotteryEndEffect       = "LotteryEndEffect",
	preSuperAttack         = "preSuperAttack",
	endSuperAttack         = "endSuperAttack",
	startUserPveLottery    = "startUserPveLottery",
	startUserBattleLottery = "startUserBattleLottery",
	showAutoBtn            = "showAutoBtn",
	hideShowAutoBtn        = "hideShowAutoBtn",
	showStartBtn           = "showStartBtn",
	hideStartBtn           = "hideStartBtn",
	showDoubleBtn          = "showDoubleBtn",
	hideDoubleBtn          = "hideDoubleBtn",
	waitForPressStop	   = "waitForPressStop",
	startBattle 		   = "startBattle",
	roundChange  		   = "roundChange",
	playEffect 			   = "playEffect",
	bossComming			   = "bossComming",
	answerView			   = "answerView",
	onSelectEnd			   = "onSelectEnd",
	needMoreGold 	       = "needMoreGold",
	needMoreDiamonds       = "needMoreDiamonds",
	skillNameEffect		   = "skillNameEffect",
	lastKillEffect    	   = "lastKillEffect",
	userTalk			   = "userTalk",
	openGuide			   = "openGuide",
	checkAndStopLottery	   = "checkAndStopLottery",
	pointAnim              = "pointAnim",
	spMaxManual            = "spMaxManual",
	leaveScene             = "leaveScene",
	runToScene             = "runToScene",
	specialPng             = "specialPng",
	monsterSkillAnimCmd    = "monsterSkillAnimCmd",
	endPveEvent            = "endPveEvent",
	log					   = "log",
}
ROLE_STATUS = {
	STAND      = 1,
	HURT       = 2,
	CAN_ACTION = 3,
	SKILL      = 4,
	WAIT       = 5,
	DEAD       = 6,
	PREDEAD    = 7,
	SKILL      = 8,
}
ATTACK_TYPE = {
	normal = 1,
	skill  = 3,
}
PVE_RES={
	SOWARD   = 1,
	DRUG     = 2,
	GOLD     = 3,
	--BOMB   = 7,
	GLASS    = 4,
	--addCyl = 5,

}

ROLE_ACTION_INTERVAL=5
LotteryType={
	Battle  = 1,
	PVE     = 2,
	Victory = 3,
	BattleS = 4,
}

ActionType ={
		BattleLottery = 1,
		PveLottery    = 2,
		selectA       = 3,
		selectB       = 4,
		lottery       = 5,
		reLottery     = 6,
		double        = 7,
		auto          = 8,
		unAuto        = 9,
		selectPoint   = 10,
		userSkill     = 11,
		reborn        = 12,
		checkPoint    = 13,
		swapPostion   = 14,
}

timeMax = 9999999

AnimSpeed = 1.5

ReLotteryCnt = 500


-- 战斗老虎机
-- first       代表随机出现概率
-- runningSame 同前图概率
-- same     二,三图相同概率
-- autoFirst   pvp的时候老虎机一图概率
laohujiIconPvp = {
    {image="nsUI/water.png"  ,name="水",texrure = nil, percent = {first=25,runningSame=60,same =40,autoFirst=25}, },
    {image="nsUI/fire.png"   ,name="火",texrure = nil, percent = {first=25,runningSame=60,same =40 ,autoFirst=25}, },
    {image="nsUI/wood.png"   ,name="木",texrure = nil, percent = {first=25,runningSame=60,same =40 ,autoFirst=25}, },
    {image="nsUI/treatment.png" ,name="恢复" ,texrure = nil, percent = {first=15,runningSame=60,same =45 ,autoFirst=15}, },
    {image="nsUI/crystal.png",name="狂暴",texrure = nil, percent = {first=10,runningSame=60,same =50 ,autoFirst=10}, },
}
-- 狂暴模式老虎机
laohujiIconPvpS = {
    {image="nsUI/boxing.png", texrure = nil, percent = {first=50,runningSame=50,same =60 ,autoFirst=50}, },
    {image="nsUI/summon.png",texrure = nil, percent = {first=50,runningSame=50,same =60 ,autoFirst=50}, },
}
--pve老虎机
laohujiIconPve = {
    {image="nsUI/sword.png",    name="战斗", texrure = nil, percent = {first=60,runningSame=50,same =40 ,autoFirst=60 }, },
    {image="nsUI/treatment.png",name="恢复",texrure = nil, percent = {first=10,runningSame=50,same =35 ,autoFirst=10 }, },
    {image="nsUI/gold.png",    name="金币", texrure = nil, percent = {first=15,runningSame=50,same =20 ,autoFirst=15 }, },
    {image="nsUI/magnifier.png",name="邂逅",texrure = nil, percent = {first=15,runningSame=50,same =25 ,autoFirst=15 }, },   
}
-- 战斗胜利老虎机 。。。 没啥用
laohujiIconV = {
    {image="nsUI/1.png",texrure = nil},
    {image="nsUI/2.png",texrure = nil},
    {image="nsUI/3.png",texrure = nil},
    {image="nsUI/4.png",texrure = nil},
    {image="nsUI/5.png",texrure = nil},   
    {image="nsUI/6.png",texrure = nil},       
}
-- 数值计算。。。。
NORMAL = {
	id = {
		wind 	= 1,
		fire 	= 2,
		wood 	= 3,
		heart 	= 4,
		crystal = 5,
	},
	percent = {
	},
	same = {

	},
}
NORMAL.percent[1]= laohujiIconPvp[1].percent.autoFirst
NORMAL.same[1] = laohujiIconPvp[1].percent.same
for i=2,5 do
	NORMAL.percent[i] = NORMAL.percent[i-1] + laohujiIconPvp[i].percent.autoFirst
	NORMAL.same[i] = laohujiIconPvp[i].percent.same
end
SUPER = {
	id = {
		fist 	= 1,
		angle	= 2,
	},
	percent = {
		[1]= laohujiIconPvpS[1].percent.autoFirst,
		[2]= laohujiIconPvpS[1].percent.autoFirst+laohujiIconPvpS[2].percent.autoFirst,
	},
	same = {
		[1]= laohujiIconPvpS[1].percent.same,
		[2]= laohujiIconPvpS[2].percent.same,
	},

}

PVE_PRECENT ={
}
PVE_SAME = {	
}
PVE_PRECENT[1]= laohujiIconPve[1].percent.autoFirst
PVE_SAME[1] = laohujiIconPve[1].percent.same
for i=2,4 do
	PVE_PRECENT[i]=PVE_PRECENT[i-1]+ laohujiIconPve[i].percent.autoFirst
	PVE_SAME[i] = laohujiIconPve[i].percent.same
end