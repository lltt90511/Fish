local tonumber,splitWithTrim,table=tonumber,splitWithTrim,table
local debugBattle = debugBattle
local mConf = require ("battle.conf")
local mGameData = require ("template.gamedata")
module("battle.view",package.seeall)
local gamedata = mGameData.data
function pushAction(bf,view) 
	--print("pushAction...............")
	if bf.playList==nil then
		bf.playList={}
	end
	if bf.playList[bf.roundNum]==nil then
		bf.playList[bf.roundNum]={}
	end
	if view.need == nil then
		view.need = 0
	end
	if debugBattle  then
		local filenamexxx = bf.battlePlayListFile
		if filenamexxx   then
			local file = io.open(filenamexxx,"a+")
			if file then
	    		file:write(bf.roundNum..","..(#bf.playList[bf.roundNum]+1)..","..view.action.."\n")
	    		file:close()
	    	end
		end
	end

	view.sysTime = bf.time
	table.insert(bf.playList[bf.roundNum],view)
end

function pushCustomAction(bf,view,params)
	params.action = view 
	pushAction(bf,params)
end

function waitCmd(bf,roleid)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.run	
	action.roleid = roleid
	pushAction(bf,action)
end
function runCmd(bf,roleid,oppid,start,back,need)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.run	
	action.roleid = roleid
	action.targetid = oppid
	action.start = start
	action.need = need 
	action.back = back
	pushAction(bf,action)
end
function startUserPveLottery(bf)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.startUserPveLottery
	pushAction(bf,action)
end

function startUserBattleLottery(bf)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.startUserBattleLottery
	pushAction(bf,action)
end

function playLottery(bf,lottery)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.lottery
	action.lottery = lottery
	action.start = bf.time
	pushAction(bf,action)
end
function ReviveCmd(bf,roleid,time,total)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.revive	
	action.roleid = roleid
	action.total = total
	action.start = time
	--action.need = need 
	pushAction(bf,action)
end
function dieCmd(bf,roleid,time)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.die	
	action.roleid = roleid
	action.start = time
	--action.need = need 
	pushAction(bf,action)
end

function dodgeCmd(bf,roleid,time)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.dodge	
	action.roleid = roleid
	action.start = time
	--action.need = need 
	pushAction(bf,action)

end
function parryCmd(bf,roleid,hp,time)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.parry	
	action.roleid = roleid
	action.start = time
	action.hp = hp
	--action.need = need 
	pushAction(bf,action)

end
function beHurtCmd(bf,roleid,hurtAnim,time,need,noAnim,hurtCnt)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.beHurt	
	action.roleid = roleid
	action.start = time
	action.need = need
	action.hurtAnim = hurtAnim
	action.noAnim = noAnim
	action.hurtCnt = hurtCnt
	--action.need = need 
	pushAction(bf,action)
end
function bossComming(bf)
	local action = {}	
	action.action =  mConf.BATTLE_ACTION_TYPE.bossComming	
	pushAction(bf,action)
end
function playEffect(bf,effect)
	local action = {}	
	action.action =  mConf.BATTLE_ACTION_TYPE.playEffect	
	action.effect = effect
	pushAction(bf,action)
end
function redeceHpCmd(bf,roleid,hp,from,to,time,xx,factions,notCreateHurt,time,hit,superHit)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.redeceHp	
	action.roleid = roleid
	action.start = time
	action.hp=hp
	action.per = per
	action.from = from
	action.to = to
	action.factions = factions
	action.notCreateHurt = notCreateHurt
	action.time = time
	action.hit = hit
	action.superHit =superHit
	--action.need = need 
	pushAction(bf,action)
	return action
end
function preAttackCmd(bf,roleid,time,need,speed)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.preAttack	
	action.roleid = roleid
	action.start = time
	action.need = need
	action.speed = speed
	--action.need = need 
	pushAction(bf,action)

end
function endAttackCmd(bf,roleid,time,need)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.endAttack	
	action.roleid = roleid
	action.start = time
	action.need = need
	--action.need = need 
	pushAction(bf,action)

end
function preSkillCmd(bf,roleid,time,need,speed,skillres,sound)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.preSkill	
	action.roleid = roleid
	action.start = time
	action.need = need
	action.speed = speed
	action.skillres = skillres
	action.sound =sound
	--action.need = need 
	pushAction(bf,action)

end
function endSkillCmd(bf,roleid,time,need,speed)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.endSkill	
	action.roleid = roleid
	action.start = time
	action.need = need
	action.speed = speed
	--action.need = need 
	pushAction(bf,action)

end
function battleEnd(bf)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.battleEnd
	pushAction(bf,action)
end
function addBuff(bf,roleid,buff)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.addBuff	
	action.roleid = roleid
	action.buff = buff
	pushAction(bf,action)
end
function removeBuff(bf,roleid,buff)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.removeBuff	
	action.roleid = roleid
	action.buff = buff
	pushAction(bf,action)	
end
function endRound(bf)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.endRound
	pushAction(bf,action)
end
function noLottery(bf)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.no_Lottery
	pushAction(bf,action)
end
function changeSp(bf,roleid,sp)
	local action = {}
	action.roleid = roleid
	action.action =  mConf.BATTLE_ACTION_TYPE.changeSp
	action.sp = sp
	action.need = 0
	pushAction(bf,action)
end

function addGold(bf,gold)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.addGold
	action.gold = gold
	pushAction(bf,action)
end

function addCyl(bf,num)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.addCyl
	action.num = num
	pushAction(bf,action)
end

function getNextAction(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.getNextAction
	pushAction(bf,action)
end

function nextPveAction(bf)
	local action = {}
	action.action =  mConf.BATTLE_ACTION_TYPE.next_pve
	pushAction(bf,action)
end

function changeLottery(bf,type)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.changeLottery
	action.type = type
	pushAction(bf,action)
end

function nextActionDelay(bf,second)
	
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.nextActionDelay
	action.delay = second
	--print ("!!!!!!!!!!!!!!!!!nextActionDelay",#bf.playList[bf.roundNum],second)
	--print (debug.traceback())
	pushAction(bf,action)
end

function waitForLottery(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.waitForLottery
	pushAction(bf,action)
end

function battleEndCallBack(bf,callBack,param)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.battleEndCallBack
	action.callBack = callBack
	action.param = param
	pushAction(bf,action)
end
function startNewBattle(bf,newbf,isBattle)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.startNewBattle
	action.newbf = newbf
	action.isBattle = isBattle
    pushAction(bf,action)
end

function pve_result(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.pve_result
	pushAction(bf,action)
end

function startEvent(bf,event)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.startEvent
	action.event = event
	pushAction(bf,action)
end

function pveOK(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.pveOK
	pushAction(bf,action)
end

function pveFailed(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.pveFailed
	pushAction(bf,action)
end

function updatePvePrecent(bf,from,to,total)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.updatePvePrecent
	action.from = from
	action.to =to
	action.total = total
	pushAction(bf,action)
end

function drug(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.drug
	pushAction(bf,action)
end

function bomb(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.bomb
	pushAction(bf,action)

end
function hitCmd(bf,role,hit)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.hit
	action.roleid = role
	action.hit = hit
	pushAction(bf,action)
end

function addGoldNoMove(bf,role,num)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.addGoldNoMove
	action.roleid = role
	action.num = num
	pushAction(bf,action)
end
function collectGold(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.collectGold
	pushAction(bf,action)	
end
function addExpNoMove(bf,role,num)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.addExpNoMove
	action.roleid = role
	action.num = num
	pushAction(bf,action)
end
function collectExp(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.collectGold
	pushAction(bf,action)	
end
function startFriend(bf)
    local action = {}
    action.action = mConf.BATTLE_ACTION_TYPE.startFriend
    pushAction(bf,action)
end

function startLotteryForVictory(bf,lottery)
	local action ={}
	action.action = mConf.BATTLE_ACTION_TYPE.startLotteryForVictory
	action.lottery= lottery
	pushAction(bf,action)
end
function goldChangeEffect(bf,gold)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.goldChangeEffect
	action.gold = gold
	pushAction(bf,action)
end

function VictoryEffect(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.VictoryEffect
	pushAction(bf,action)
end

function dropExp(bf,roleid,exp)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.dropExp
	action.exp =exp
	action.roleid = roleid
	pushAction(bf,action)
end

function collectExp(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.collectExp
	pushAction(bf,action)	

end

function dropItem(bf,roleid,id)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.dropItem
	action.id =id
	action.roleid = roleid
	pushAction(bf,action)
end

function collectItem(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.collectItem
	pushAction(bf,action)
end

function resultGoldShow(bf,gold)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.resultGoldShow
	action.gold = gold
	pushAction(bf,action)
end

function resultGoldOver(bf,from,to)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.resultGoldOver
	action.from = from
	action.to = to
	pushAction(bf,action)
end

function startPreLottery(bf,flag)
	local action ={}
	action.action = mConf.BATTLE_ACTION_TYPE.startPreLottery
	action.flag = flag
	pushAction(bf,action)
end

function notSync(bf)
	local action ={}
	action.action = mConf.BATTLE_ACTION_TYPE.notSync
	pushAction(bf,action)
end

function removeDouble(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.removeDouble
	pushAction(bf,action)
end

function canDouble(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.canDouble
	pushAction(bf,action)
end

function checkAutoLottery(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.checkAutoLottery
	pushAction(bf,action)
end

function buffEffect(bf,roleId,buff)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.buffEffect
	action.roleid = roleId
	action.buff = buff
	pushAction(bf,action)
end
function skillNameEffect(bf,name)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.skillNameEffect
	action.name = name
	pushAction(bf,action)
end
function skillStartEffect(bf,roleId,skill)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.skillStartEffect
	action.roleid = roleId
	action.skillName = skill
	pushAction(bf,action)
end
function stopUserSkill(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.stopUserSkill
	pushAction(bf,action)
end

function LotteryEndEffect(bf,super,type,num,five,effectRoleList,shadowEffect)
	local action ={}
	action.action = mConf.BATTLE_ACTION_TYPE.LotteryEndEffect
	action.type = type
	action.super = super
	action.num = num
	action.five = five
	action.effectRoleList = effectRoleList
	action.shadowEffect = shadowEffect
	pushAction(bf,action)
end

function preSuperAttack(bf,lv,hideList,effectList)
	local action ={}
	action.action = mConf.BATTLE_ACTION_TYPE.preSuperAttack
	action.hideList = hideList
	action.effectList = effectList
	action.lv = lv
	pushAction(bf,action)

end
function endSuperAttack(bf,lv,hideList,effectList)
	local action ={}
	action.action = mConf.BATTLE_ACTION_TYPE.endSuperAttack
	action.hideList = hideList
	action.effectList = effectList
	action.lv = lv
	pushAction(bf,action)

end


function waitForPressStop(bf)
	local action ={}
	action.action = mConf.BATTLE_ACTION_TYPE.waitForPressStop
	pushAction(bf,action)
end

function startBattle(bf)
	local action ={}
	action.action = mConf.BATTLE_ACTION_TYPE.startBattle
	pushAction(bf,action)	
end

function roundChange(bf,roundNum)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.roundChange
	action.round = roundNum
	pushAction(bf,action)
end

function answerView(bf,text)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.answerView
	action.text=text
	pushAction(bf,action)
end

function onSelectEnd(bf,hasBattle,fragmentDrop)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.onSelectEnd
	action.hasBattle =  hasBattle
	action.fragmentDrop = fragmentDrop
	pushAction(bf,action)
end

function needMoreGold(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.needMoreGold
	pushAction(bf,action)
end
function needMoreDiamonds(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.needMoreDiamonds
	pushAction(bf,action)
end

function lastKillEffect(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.lastKillEffect
	pushAction(bf,action)
end

function userTalk(bf,roleId,name,context)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.userTalk 
	action.roleId = roleId
	action.name = name
	action.context = context
	pushAction(bf,action)
end

function openGuide(bf,event)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.openGuide
	action.event = event
	pushAction(bf,action)
end

function checkAndStopLottery(bf,lottery)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.checkAndStopLottery
	action.lottery = lottery
	pushAction(bf,action)
end

function pointAnim(bf,animId)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.pointAnim
	action.animId = animId
	pushAction(bf,action)
end

function spMaxManual(bf,role)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.spMaxManual
	action.roleId = role
	pushAction(bf,action)
end

function leaveScene(bf,id)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.leaveScene
	action.id = id
	pushAction(bf,action)
end

function runToScene(bf)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.runToScene
	pushAction(bf,action)
end

function specialPng(bf,roleId,png)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.specialPng
	action.roleId = roleId
	action.png = png
	pushAction(bf,action)
end


function monsterSkillAnimCmd(bf,roleId,anim)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.monsterSkillAnimCmd
	action.roleId = roleId
	action.anim = anim
	pushAction(bf,action)
end

function endPveEvent(bf,START,END)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.endPveEvent
	action.START = START
	action.END = END
	pushAction(bf,action)
end

function addLog(bf,log,color)
	local action = {}
	action.action = mConf.BATTLE_ACTION_TYPE.log
	action.log = log
	action.time = math.ceil(bf.time*100)/100
	action.color = color
	pushAction(bf,action)
end