local printTable,math,coroutine = printTable,math,coroutine
local debug,print = debug,print
local view = require("battle.view")
--local server= require ("battle.server")
local tool = require("scene.tool")
local battle = require ("battle.battle")
local conf = require("battle.conf")
local mConf = conf
local mGameData = require ("template.gamedata")
local mPve = require("battle.pve")
local mRandom = require("battle.random")
local gamedata = mGameData.data
local mRole = require("battle.role")
module("battle.effect", package.seeall)
this = nil
widget = nil
startPlay = nil
local oldPerformWithDelay = performWithDelay
local performWithDelay = function (func,time)
    if time  == nil or time < 0 then
        time = 0
    end
    local mScene = package.loaded['battle.scene']
    if mScene.speed == 0  then
        time =0
    else
        time = time /mScene.speed
    end
    --print ("performWithDelay",time)
    tool.createEffect(tool.Effect.delay,{time=time},this,func,true,false)
end

function bombEffect(action)
    local callBack = startPlay
    local time = 0
    local list = {}
    for i=1,10 do
      performWithDelay(function()
        local ps = CCParticleSystemQuad:create("effect/explodingring.plist")
        ps:setPosition(ccp(Screen.width/2+math.random(-320,320),
            Screen.height/4*3+math.random(-320,320))) 
        this:addChild(ps)
        table.insert(list,ps)
       end,time)
      time = time +0.1
    end
    performWithDelay(function()
        for i,v in pairs(list) do
            v:removeFromParentAndCleanup(true)
        end
        if callBack then
            callBack()
        end
    end,1.5)
    return "stopAction"
end

function goldEffect(action)
    local callBack = startPlay
    local gold = action.gold
    local path = "nsUI/gold.png"
    local list = {}
    local oneCnt = nil
    local num = nil
    local last = action.gold
    if action.gold > 50 then
        oneCnt = math.floor(action.gold/50)
        num = 50  
    else 
        oneCnt = 1
        num = 1
    end

    for i=1,num+1 do
        if i == num + 1 and last == 0 then
            break
        end

        local x,y = math.random(0,640),720
        local toX,toY = x,math.random(50,300)
        local size = widget.battle_scene.obj:getSize()
        local sprite  = CCArmature:create("gold")
        local anim = sprite:getAnimation()
        anim:playWithIndex(0)
        sprite:setScale(1)
        sprite:setPosition(ccp(x,y))
        sprite:setZOrder(math.random(5,45))

        --tool.goldAnim(sprite,{x=pos.x,y=pos.y},{x=pos.x+x,y=pos.y+y},0.6)
        -- local action = CCMoveTo:create(0.2,point)
        --sprite:runAction(action)
        widget.battle_scene.obj:addNode(sprite,2)
        if i == num +1 then
            table.insert(list,{sprite=sprite,gold=last})
        else
            table.insert(list,{sprite=sprite,gold=oneCnt})
        end
        last = last - oneCnt
        performWithDelay(function ()
            tool.createEffect(tool.Effect.move,{x=toX,y=toY,time =0.5},sprite,function()
                local tx = toX+math.random(0,100)
                 AudioEngine.playEffect("system_07")
                tool.goldAnim(sprite,{x=toX,y=toY},{x=tx,y=toY},0.3,function()
                    tool.goldAnim(sprite,{x=tx,y=toY},{x=tx+math.random(-50,50),y=toY},0.2)
                end)
            end)
        end,math.random(1,1000)/1000)
    end

    performWithDelay(function()
        local x,y = widget.info2.obj:getPositionX()+widget.info2.gold.obj:getPositionX(),
            720-(1136-Screen.height)/2-25
        for i,v in pairs(list) do
            performWithDelay (function()
                v.sprite:stopAllActions()
                tool.goldAnim(v.sprite,{x=v.sprite:getPositionX(),y=v.sprite:getPositionY()},{x=x,y=y},0.6,function()
                  addOneGold(v.gold)
                    v.sprite:removeFromParentAndCleanup(true)
                end)    
            end,math.random(1,1000)/1000)
        end
    end,1.3)
    performWithDelay(function()
        GoldAllAdded(action.gold)
        startPlay()
    end,2.2)
    return "stopAction"
end

goldList = {}
function addGoldNoMove(action)
	local scene = package.loaded['battle.scene']
    local gold = action.gold
    local path = "nsUI/gold.png"
    local id   = scene.playerToPostion[action.roleid]
    local role = scene.Role[id]
    local info = scene.spaceInfo[id]
    local pos = {x=role.sprite:getPositionX(),y=role.sprite:getPositionY()-50}
    local oPoint=ccp(pos.x,pos.y)
    local list = {}
    local t = 0
    local mod = 10
    local scale = 1-0.05
    local gold = math.ceil(action.num/2)
    for i=1,2 do
        if i == 2 then
            gold = action.num  - gold
            if gold == 0 then
                break
            end
        end
        local x = math.random(-100,100)
        local y = math.random(-50,50)
        local point =ccp(pos.x+x,pos.y+y)
        local sprite  = tolua.cast(CCArmature:create("gold"),"CCArmature")
        local anim = sprite:getAnimation()
        
        anim:playWithIndex(0)
        sprite:setScale(scale)
        sprite:setPosition(oPoint)
        tool.goldAnim(sprite,{x=pos.x,y=pos.y},{x=pos.x+x,y=pos.y+y},0.4,function()
              AudioEngine.playEffect("system_07")
        end)
        local z = 0
        if x > 0 then
            z = math.random(0,10)
        elseif x < 0 then 
            z = math.random(-10,0)
        end
        widget.battle_scene.obj:addNode(sprite,2)
        table.insert(goldList,{sprite=sprite,gold=gold,x=pos.x+x,y=pos.y+y})
    end   

 

    if #goldList > 10 then
        collectGold()
    end
end
function collectGold()
    --performWithDelay(function()
    local x,y = widget.info2.obj:getPositionX()+widget.info2.gold.obj:getPositionX(),
        720-(1136-Screen.height)/2-25
        local all = 0
    for i,v in pairs(goldList) do
        performWithDelay (function()
        tool.createEffect(tool.Effect.scale,{time = 1,scale=1},v.sprite,nil,true,true)
        tool.goldAnim(v.sprite,{x=v.x,y=v.y},{x=x,y=y},0.8,function()
            addOneGold(v.gold)
            v.sprite:removeFromParentAndCleanup(true)
        end)
        --[[
        tool.createEffect(tool.Effect.move,{time = 5,x=x,y=y},v.sprite,function()
            addOneGold(v.gold)
            v.sprite:removeFromParentAndCleanup(true)
        end,true,true)]]
        end,math.random(1,1000)/1000)
        all = all + v.gold
    end
    goldList = {}
    local num = all
    if num > 0 then
        performWithDelay(function()
            --GoldAllAdded(num)
        end,2)
    end
    
end
function goldChangeEffect(action)
    local gold = action.gold
    GoldAllAdded(gold)
    goldCnt = goldCnt + gold
    setGoldCnt(goldCnt)
end

function GoldAllAdded(num)
--   print (debug.traceback())
   local x,y = widget.info2.obj:getPositionX()+widget.info2.gold_num.obj:getPositionX(),
        widget.info2.obj:getPositionY()+widget.info2.gold_num.obj:getPositionY()
    local obj = tolua.cast(widget.info2.gold_num.obj:clone(),"Label")
    if num >=0 then
        obj:setText("+"..num)
    else
        obj:setText(num)
    end
    obj:setPosition(ccp(x,y-50))
    this:addChild(obj)
    tool.createEffect(tool.Effect.move,{time=1,x=x,y=y+0},obj)
    performWithDelay(function()
        obj:stopAllActions()
        obj:removeFromParentAndCleanup(true)
    end,1)
end
goldCnt = 0
function setGoldCnt(cnt)
    goldCnt = cnt
    widget.info2.gold_num.obj:setText("x"..cnt)
end
function addOneGold(num)
    AudioEngine.playEffect("system_06")
    goldCnt = goldCnt + num
    setGoldCnt(goldCnt)
end
function VictoryEffect(action)
    return winEffect(bf,startPlay)
end
function winEffect(bf,callBack)
    -- 播放win的动画 并且回掉
    print("winEffect")
    local scene = package.loaded['battle.scene']
    local y = 700 + (Screen.height - 960)*2/3
    local dis = 100
    scene.stringEffect({
        {file = "nsUI/win_01.png",pos= {x=320-1.5*dis,y=y}},
        {file = "nsUI/win_02.png",pos= {x=320-0.5*dis,y=y}},
        {file = "nsUI/win_03.png",pos= {x=320+0.5*dis,y=y}},
        {file = "nsUI/win_04.png",pos= {x=320+1.5*dis,y=y}},
    },{x=320,y=y},callBack)
    return "stopAction"
end
itemList = {}
function dropItem(action)
    local scene = package.loaded['battle.scene']
    --local gold = action.exp
    --local tpl = gamedata['badge'][action.id]
   -- local path = "nsUI/exp.png"
   local lz = 0
   local lx = 0
   local ly=0
   if action.roleid ~= nil then
        local id =   scene.playerToPostion[action.roleid]
        local role = scene.Role[id] 
        local info = scene.spaceInfo[id]
         lx=role.sprite:getPositionX()
         ly=role.sprite:getPositionY()-50
         lz = info.z
    else
        lx = scene.spaceInfo[15].pos.x
        ly = scene.spaceInfo[15].pos.y
        lz = 100
    end
    local pos = {x=lx,y=ly}
    local oPoint=ccp(pos.x,pos.y)
    --local list = {}
    local x = math.random(-100,100)
    local y = math.random(-50,50)
    --local point =ccp(pos.x+x,pos.y+y)
    local sprite  = tolua.cast(CCSprite:create("nsUI/box.png"),"CCSprite")
    sprite:setScale(0.7)

    sprite:setPosition(oPoint)
    local z = 0
    if x > 0 then
        z = math.random(0,10)
    elseif x < 0 then 
        z = math.random(-10,0)
    end
    widget.battle_scene.obj:addNode(sprite,lz)
    tool.goldAnim(sprite,{x=pos.x,y=pos.y},{x=pos.x+x,y=pos.y+y})
    table.insert(itemList,{sprite=sprite})
end

function collectItem(action)
    --performWithDelay(function()
    local x,y = widget.info2.obj:getPositionX()+widget.info2.box.obj:getPositionX(),
        720-(1136-Screen.height)/2-25
        local all = 0
    for i,v in pairs(itemList) do
        local obj = v
        performWithDelay (function()
            --tool.createEffect(tool.Effect.scale,{time = 1,scale=1},v.sprite,nil,true,true)
            tool.createEffect(tool.Effect.move,{time = 1,x=x,y=y},obj.sprite,function()
                --addOneExp(v.exp)
                addOneBox()
                tool.createEffect(tool.Effect.scale,{time = 0.5,scale=1},obj.sprite,nil,true,true)
                tool.createEffect(tool.Effect.fadeOut,{time = 0.5,scale=1},obj.sprite,function ()
                    obj.sprite:removeFromParentAndCleanup(true)
                end,true,true)
                
            end,true,true)
        end,math.random(1,1000)/1000)
        --all = all + v.exp
    end
    itemList = {}
end 
boxCnt = 0
function addOneBox()
    boxCnt = boxCnt + 1
    widget.info2.box_num.obj:setText("x"..boxCnt)
end
function setBoxCnt(cnt)
    boxCnt = cnt
    widget.info2.box_num.obj:setText("x"..cnt)
end
expList = {}
function dropExp(action)
    local scene = package.loaded['battle.scene']

   -- local path = "nsUI/exp.png"
    local id =   scene.playerToPostion[action.roleid]
    local role = scene.Role[id] 
    local info = scene.spaceInfo[id]
    local pos = {x=role.sprite:getPositionX(),y=role.sprite:getPositionY()-50}
    local oPoint=ccp(pos.x,pos.y)
    local list = {}
    local t = 0
    local mod = 10
    local scale = 1-0.05
    local exp = math.ceil(action.exp/2)
 
    for i=1,2 do
        if i == 2 then
            exp = action.exp - exp
            if exp == 0 then
                break
            end
        end
        local x = math.random(-100,100)
        local y = math.random(-50,50)
        local point =ccp(pos.x+x,pos.y+y)
        local sprite  = tolua.cast(CCArmature:create("exp"),"CCArmature")
        local anim = sprite:getAnimation()

        anim:playWithIndex(0)
        sprite:setScale(scale)
        
        sprite:setPosition(oPoint)
        tool.goldAnim(sprite,{x=pos.x,y=pos.y},{x=pos.x+x,y=pos.y+y})
        local z = 0
        if x > 0 then
            z = math.random(0,10)
        elseif x < 0 then 
            z = math.random(-10,0)
        end
        widget.battle_scene.obj:addNode(sprite,info.z)
        table.insert(expList,{sprite=sprite,exp=exp,x=pos.x+x,y=pos.y+y})
    end
 
end
function collectExp()
    --performWithDelay(function()
    --local x,y = widget.info2.obj:getPositionX()+widget.info2.exp.obj:getPositionX(),
    --    720-(1136-Screen.height)/2-25
    local scene = package.loaded['battle.scene']
    local all = 0
    local rolei = 1
    local roleList = {}
    for i = 1,3 do
        if scene.Role[i] ~= nil and scene.Role[i].isDead ~= true then
            table.insert(roleList,scene.Role[i])
        end
    end
    local ci = 1
    for i,v in pairs(expList) do
        local info =v 
        local x,y 
        local role = roleList[ci]
        ci = ci + 1
        if ci > #roleList then
            ci = 1
        end
        if role == nil then
            return
        end
        x = role.spaceInfo.pos.x+30
        y = role.spaceInfo.pos.y+20
        performWithDelay (function()
            tool.createEffect(tool.Effect.scale,{time = 0.8,scale=1},info.sprite,nil,true,true)
            tool.goldAnim(info.sprite,{x=info.x,y=info.y},{x=x,y=y},0.8,function()
                info.sprite:removeFromParentAndCleanup(true)
            end,{x=0,y=300})
        end,math.random(1,1000)/1000)
        --all = all + v.exp
    end
    expList = {}
    local num = all
    if num > 0 then
        performWithDelay(function()
            ExpAllAdded(num)
        end,2)
    end
   
end


function ExpAllAdded(num)
   local x,y = widget.info2.obj:getPositionX()+widget.info2.exp_num.obj:getPositionX(),
        widget.info2.obj:getPositionY()+widget.info2.exp_num.obj:getPositionY()
    local obj = tolua.cast(widget.info2.exp_num.obj:clone(),"Label")
    if num >=0 then
        obj:setText("+"..num)
    else
        obj:setText(num)
    end
    obj:setPosition(ccp(x,y-50))
    this:addChild(obj)
    tool.createEffect(tool.Effect.move,{time=1,x=x,y=y+0},obj)
    performWithDelay(function()
        obj:stopAllActions()
        obj:removeFromParentAndCleanup(true)
    end,1)
end
expCnt = 0
function setExpCnt(cnt)
    expCnt = cnt
    widget.info2.exp_num.obj:setText("x"..cnt)
end
function addOneExp(num)
    expCnt = expCnt + num
    setExpCnt(expCnt)
end