local math,table,tonumber,pairs,print,printTable,splitWithTrim=math,table,tonumber,pairs,print,printTable,splitWithTrim
local coroutine,L_onError,xpcall,string,debug = coroutine,L_onError,xpcall,string,debug

local mRole = require("battle.role")
local mGameData = require ("template.gamedata")
local mConf=require("battle.conf")
local mRandom=require("battle.random")
local mBattle = require("battle.battle")
local mView = require("battle.view")
local mNum = require("battle.numerial")
local userdata = require"logic.userdata"
local gamedata = mGameData.data
module("battle.pvp", package.seeall)
function getBf(data)
   local id,team1Fans,team2Fans,random,leader1,leader2,team1,team2,startTeam,info =data.pvpId,data.selfFansCount,data.oppoFansCount,data.battleRandomQue,data.selfLeader,data.oppoLeader,data.teamSelf,data.teamOppo,2,{team1=data.team1,team2=data.team2}
    print("xXXXXXXXXXXXXXXXXXX")
    mRandom.setSequence(random)
    for i,v in pairs(team1) do
        if type(v) ~= "userdata" then
            v.hp = nil
        else
            team1[i]=nil
        end
    end
    for i,v in pairs(team2) do
        if type(v) ~= "userdata" then
            v.hp = nil
        else
            team2[i]=nil
        end
    end
    local bf = infoForPvpBattle(leader1,leader2,team1,team2)
    bf.team1.fans = team1Fans
    bf.team2.fans = team2Fans
    bf.pvpInfo = info
    return bf
end
function onStartPvpBattle(data,test)
    local team1 = data.teamSelf
    local team2 = data.teamOppo
    local bf = getBf(data)
   
    local round = 1
    local playedAction = 1
    while true do
        --printTable(bf.playList)
        local action = bf.playList[round][playedAction]
        local lotteryStatus = false
        playedAction = playedAction + 1
        --print (round,playedAction)

        if action.action ==   mConf.BATTLE_ACTION_TYPE.getNextAction then
            mBattle.onActionEndCallBack(bf)
        elseif action.action ==  mConf.BATTLE_ACTION_TYPE.battleEnd then
            local succeed = 0
            if bf.status == "victory" then
                 succeed = 1
            end
            if test then 
                return succeed
            end
            encryptCall("endPvpBattle",{pvpId=data.pvpId,succeed=succeed})
            break
        elseif action.action ==   mConf.BATTLE_ACTION_TYPE.endRound then
            round = round + 1
            playedAction = 1
        end
    end


    bf = getBf(data)
     bf.isFriend = data.isFriend
 
    local animList = {}
    for i,v in pairs(team1) do
    	table.insert(animList,{type=1,id=v.badge.tid})
    end
    for i,v in pairs(team2) do
    	table.insert(animList,{type=1,id=v.badge.tid})
    end
     mView.battleEndCallBack(bf,endPvpBattle,{bf=bf,pvpId=id,data=data})
    local scene = package.loaded['battle.scene']
    scene.bf = bf
    scene.pve = nil
    scene.loadAllAnimSuper(animList,function ()
        local sceneManager = package.loaded['scene.sceneManager']
        sceneManager.change(sceneManager.SceneType.nsbattleScene)  
    end)
   
  
end
function endPvpBattle(data)
    local succeed = 0
    if data.bf.status == "victory" then
        succeed = 1
    end
    -- 分析战斗结果
    local team1 = {badgeList = {},hurt=0,hp=0,info=data.data.team1}
    local team2 = {badgeList = {},hurt=0,hp=0,info=data.data.team2}
    team1.hurt = data.bf.teamHurt[1]
    team2.hurt = data.bf.teamHurt[2]
    for i,role in pairs(data.bf.team1.roleMap) do
       printTable(role.badgeBean)
        table.insert(team1.badgeList,{tid = role.badgeBean.tid,lv=role.badgeBean.lv})
        team1.hp = team1.hp + mNum.getBattleHp(data.bf,role)
    end 
    for i,role in pairs(data.bf.team2.roleMap) do
        table.insert(team2.badgeList,{tid = role.badgeBean.tid,lv=role.badgeBean.lv})
        team2.hp = team2.hp + mNum.getBattleHp(data.bf,role)
    end 
    local endData = {succeed=succeed,team1=team1,team2=team2,isFriend= data.bf.isFriend } 
       print ("bf.isFriend:",endData.isFriend)
   -- errorFunc()
    -- 为结束准备
    --printTable(endData)
    local arenaResult = package.loaded["scene.arenaResult"]
    arenaResult.initResult(endData)
    
end
function infoForPvpBattle(leader1,leader2,team1,team2)
    local bf = mBattle.initbf(2)
    bf.canSkill = false
    bf.team1 = mBattle.initTeam(1)
    bf.team2 = mBattle.initTeam(2)
    --bf.team1.fans = team1.fans
    --bf.team2.fans = team2.fans
    local l1 = 0
    local l2 = 0
    for i,v in pairs(team1) do
        local role = mRole.initRole(v.id,1,mConf.ROLE_STATUS.STAND,v)
        bf.team1.roleMap[i] = role
        if i == leader1 then
            l1 = i
        end
    end
    for i,v in pairs(team2) do
        local role = mRole.initRole(v.id,2,mConf.ROLE_STATUS.STAND,v)
        bf.team2.roleMap[i] = role
        if i == leader2 then
            l2 = i
        end
    end
    bf.team1.teamLeaderId = l1
    bf.team2.teamLeaderId = l2
    mBattle.startBattle(bf)
    return bf
end
