local math,table,tonumber,pairs,print,printTable,splitWithTrim=math,table,tonumber,pairs,print,printTable,splitWithTrim
local coroutine,L_onError,xpcall,string,debug = coroutine,L_onError,xpcall,string,debug
local notWriteFile = notWriteFile
local mRole = require("battle.role")
local mGameData = require ("template.gamedata")
local mConf=require("battle.conf")
local mRandom=require("battle.random")
local mBattle = require("battle.battle")
local mView = require("battle.view")
local mNum = require("battle.numerial")
local userdata = require"logic.userdata"
local gamedata = mGameData.data
local conf = mConf
module("battle.remuser", package.seeall)
ErrorCode = {
    [1] = "战斗进入死循环",
    [2] = "遇到意外的错误",
    [3] = "未知的计算错误",
    [4] = "战斗成功",
    [5] = "战斗失败",
    [6] = "非法的老虎机开始按钮触发",
    [7] = "非法的双倍按键触发",
}
function remusePveData(pve,runningInfo,battleTest)
	-- 当前玩家操作序列id
	local mPve = package.loaded['battle.pve']
	local actionId = 1
	local actionList = pve.actionList
	local bf = pve.bf
	pve.playedAction = 1
	pve.round = 1
	if actionList[actionId] == nil then
		return true,"",pve.bf
	end
	local cnt = 0 
    --printTable(actionList)
	while true do
		cnt = cnt + 1
		if cnt > 10000 then
			-- 恢复失败。。。循环太长啦
			return false,1,2
		end 
 		local action = bf.playList[pve.round][pve.playedAction]
        local lotteryStatus = false
        pve.playedAction = pve.playedAction + 1
 
        if action == nil then
            print ("#####no Action processCnt ",pve.processCnt," round ",pve.round," playedAction ",pve.playedAction)
            return false,2,2  
        end
        local oldPveProcess = pve.process
        if action.action ==   conf.BATTLE_ACTION_TYPE.startNewBattle then
        	bf = action.newbf
        	pve.round = 1
        	pve.playedAction = 1
        elseif action.action == conf.BATTLE_ACTION_TYPE.startBattle then
        	pve.inBattle = true
        elseif action.action == conf.BATTLE_ACTION_TYPE.startPreLottery then
        	pve.lotteryRunning = true
            pve.preLotteryActionCache = action
        elseif action.action == conf.BATTLE_ACTION_TYPE.startEvent then
        	bf = pve.bf
            pve.round = 1
			pve.playedAction =3
            pve.startEvent = true
        elseif action.action ==   conf.BATTLE_ACTION_TYPE.notSync then
        	return false,3,2
        elseif action.action ==   conf.BATTLE_ACTION_TYPE.lottery then 
        	pve.buttonStatus.start.touch  = false
        	pve.lotteryRunning = false
        	pve.lottery = action.lottery
        elseif action.action ==   conf.BATTLE_ACTION_TYPE.startUserPveLottery then
        	pve.buttonStatus.start.touch  = true
        elseif action.action ==   conf.BATTLE_ACTION_TYPE.startUserBattleLottery then
        	pve.buttonStatus.start.touch  = true
        elseif action.action ==   conf.BATTLE_ACTION_TYPE.canDouble then
        	pve.buttonStatus.double.touch = true
        elseif action.action ==   conf.BATTLE_ACTION_TYPE.pve_result then
        	mPve.eventResult(pve)
            pve.result_back = {bf=bf,playedAction=pve.playedAction,round=pve.round}
        elseif action.action ==   conf.BATTLE_ACTION_TYPE.getNextAction then
        	mBattle.onActionEndCallBack(bf)
        elseif action.action ==   conf.BATTLE_ACTION_TYPE.battleEndCallBack then
        	pve.battleEndCallBack = action
        elseif action.action ==   conf.BATTLE_ACTION_TYPE.battleEnd then	
            local endBattleFlag = true
            if bf.status == "lose" then
                if  actionList[actionId] and 
                    actionList[actionId].battleId == bf.id and
                    actionList[actionId].round == pve.round and
                    actionList[actionId].playedAction == pve.playedAction  
                    and actionList[actionId].type  == mConf.ActionType.reborn 
                    then
                    actionId = actionId + 1
                    mPve.rebornDiamonds(pve)
                    mBattle.reborn(bf)
                    endBattleFlag = false
                    
                end
            end
            if endBattleFlag then
            	pve.inBattle  = false
            	if pve.battleEndCallBack then
            		local callBack = pve.battleEndCallBack
            		pve.battleEndCallBack = nil
            		callBack.callBack(callBack.param)
            	end
            end
        elseif action.action ==   conf.BATTLE_ACTION_TYPE.no_Lottery then	
        	pve.startBtnTouchStatus = false
        elseif action.action ==   conf.BATTLE_ACTION_TYPE.endRound then
	        pve.round = pve.round + 1
	        pve.playedAction = 1
       	elseif action.action ==   conf.BATTLE_ACTION_TYPE.removeDouble then
       		--pve.double = false
       		pve.buttonStatus.double.status = false
       	elseif action.action ==   conf.BATTLE_ACTION_TYPE.changeLottery then
       		pve.lotteryType = action.type
       		pve.lottery = nil
       	elseif action.action ==   conf.BATTLE_ACTION_TYPE.preSuperAttack then
       		pve.super = #bf.playList[pve.round]+1
       	elseif action.action ==   conf.BATTLE_ACTION_TYPE.endSuperAttack then
       		pve.super = nil
       	elseif action.action ==   conf.BATTLE_ACTION_TYPE.pveOK then
       		-- 不应该出现呀！！！ 服务端用
       		return false,4,1,pve
       	elseif action.action ==   conf.BATTLE_ACTION_TYPE.pveFailed then
       		-- 不应该出现呀！！！ 服务端用
       		return false,5,0,pve
       	end
        while actionList[actionId] and actionList[actionId].battleId == bf.id and
            actionList[actionId].round == pve.round and
            actionList[actionId].playedAction == pve.playedAction do
            
            local type = actionList[actionId].type
            local paramStr = actionList[actionId].param
            print ("userAction "..actionId.." #"..type.."   process:"..bf.id .." round:"..pve.round.." playedAction:"..pve.playedAction)
            actionId = actionId + 1
            local param = tonumber(paramStr)
            if type == mConf.ActionType.BattleLottery then
                pve.relottery = false
                if pve.lotteryType == mConf.LotteryType.Battle and bf.canLottery == true  and 
                    pve.buttonStatus.start.touch  then
                    pve.buttonStatus.reStart.touch = true
                    pve.playedAction = #bf.playList[pve.round] + 1
                    if param >= 0 then
	                    mBattle.getLotteryRandom(bf,param)
                    else
                        mBattle.getLotteryRandom(bf) 
	                end
                else
                    print ("battleLottery , Error")
                    --return false,6,2
                end
            elseif type == mConf.ActionType.PveLottery then
                pve.relottery = false
                if pve.lotteryType == mConf.LotteryType.PVE and pve.canLottery == true and 
                    pve.buttonStatus.start.touch  then
                    pve.buttonStatus.reStart.touch = true
                    pve.playedAction = #bf.playList[pve.round] + 1
                    if param >=0 then
	                    mPve.getNextPveLottory(pve,param)
                    else
                        mPve.getNextPveLottory(pve)
	                end
                else
                    print ("pveLottery , Error")
                end
            elseif type == mConf.ActionType.reLottery then
                if pve.lotteryType == mConf.LotteryType.Battle then
                    mPve.changeGoldForBattleRestart(pve)
                else
                    mPve.changeGoldForReStart(pve)
                end   
                pve.buttonStatus.start.touch = true
                pve.buttonStatus.reStart.touch = false
                pve.lotteryRunning = true
                pve.relottery = true          
            elseif type == mConf.ActionType.double then
               
            elseif type == mConf.ActionType.auto then
                pve.autoFlag  = true
                bf.autoFlag = true
                pve.buttonStatus.auto.status = true
            elseif type == mConf.ActionType.unAuto then
                pve.autoFlag  = false
                bf.autoFlag = false
                pve.buttonStatus.auto.status = false
            elseif type == mConf.ActionType.selectPoint then
                --mBattle.selectRole(bf,param)
            elseif type == mConf.ActionType.selectA then
                mPve.select(pve,1,nil)
                pve.startEvent = false
            elseif type == mConf.ActionType.selectB then
                mPve.select(pve,2,nil)
                pve.startEvent = false
            elseif  type == mConf.ActionType.userSkill then
                mBattle.skillAction(bf,param)
            elseif type == mConf.ActionType.checkPoint then
                -- 检查点。。。 如果莫名奇妙被关掉
            elseif type == mConf.ActionType.swapPostion then
                local strx = splitWithTrim(paramStr,":")
                mPve.swapPostion(pve,tonumber(strx[1]),tonumber(strx[2]))
            end 
        end   
        --battleTest 不直接结束 直到pveOK
        local endFlag = false
        if bf.id > runningInfo.battleId then
            endFlag = true
        elseif bf.id == runningInfo.battleId then
            if pve.round > runningInfo.round then
                endFlag = true
            elseif pve.round == runningInfo.round then
                if pve.playedAction >= runningInfo.playedAction then
                    endFlag = true
                end
            end
        end
        if battleTest ~= true and endFlag == true  then
            print ("endInfo",bf.id ,pve.round,pve.playedAction)
            print ("actionID",actionId)
            print("xxx",runningInfo.battleId,runningInfo.round,runningInfo.playedAction)
            printTable(actionList[actionId])
        	local curBf = handleLastAction(pve,bf)
        	return true,"",curBf
        end
	end
end


-- 该函数 用以处理最后战报操作结束的位置
-- 该位置可能出现为止的地方枚举
-- 1. 正在进行老虎机摇动
-- 2. 已经开始preLottery，等待按钮按下
-- 3. 按下了老虎机结束按钮 
-- 4. 大招的时候
function handleLastAction(pve,bf)
	
	if pve.startEvent then
        --pve.result_back = {bf=bf,playedAction=pve.playedAction,round=pve.round}
        print("handleLastAction#startEvent",pve.result_back.playedAction,pve.result_back.round)
        pve.round = pve.result_back.round
        pve.playedAction = pve.result_back.playedAction
        return pve.result_back.bf
    end
   if pve.super ~= nil then
       pve.playedAction = pve.super
       return bf
    end
    local action = bf.playList[pve.round][pve.playedAction-1]
	-- 女神出现 重新开始摇
    if action.action == mConf.BATTLE_ACTION_TYPE.lottery then
        pve.playedAction = pve.playedAction + 1
    end

    return bf
end