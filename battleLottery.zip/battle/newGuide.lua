local math,table,tonumber,pairs,print,printTable,splitWithTrim=math,table,tonumber,pairs,print,printTable,splitWithTrim
local coroutine,L_onError,xpcall,string,debug = coroutine,L_onError,xpcall,string,debug
local scriptsVersion = scriptsVersion
local notWriteFile = notWriteFile
local mRole = require("battle.role")
local mGameData = require ("template.gamedata")
local mConf=require("battle.conf")
local mRandom=require("battle.random")
local mBattle = require("battle.battle")
local mView = require("battle.view")
local mNum = require("battle.numerial")
local userdata = require "logic.userdata"
local mRemuser = require "battle.remuser"
local guideEvent = require "guide.conf".EVENT
local gamedata = mGameData.data
local conf = mConf
module("battle.newGuide",package.seeall)
-- 写死的战斗。。。。
selfRoleList = {
	{
	  id = 1,
      tid =13,
      autoFlag = false,
      charmExp = gamedata["charmExp"][5].exp,
      exp = gamedata["roleExp"][20].exp,
      dear = 0,
      badge = {
        tid = 13,
      	exp = gamedata["badgeExp"][45].exp*gamedata["badge"][13].expchange,
      	skillLv = 0,
      	breakTime = 0,
  	  },
	},
	{
	  id = 2,
      tid =14,
      autoFlag = false,
      charmExp = gamedata["charmExp"][5].exp,
      exp = gamedata["roleExp"][45].exp,
      dear = 0,
      badge = {
        tid = 21,
      	exp = gamedata["badgeExp"][45].exp*gamedata["badge"][21].expchange,
      	skillLv = 0,
      	breakTime = 0,
  	  },
	},
	{
	  id = 3,
      tid =16,
      autoFlag = false,
      charmExp = gamedata["charmExp"][5].exp,
      exp = gamedata["roleExp"][45].exp,
      dear = 0,
      badge = {
        tid = 11,
      	exp = gamedata["badgeExp"][45].exp*gamedata["badge"][11].expchange,
      	skillLv = 0,
      	breakTime = 0,
  	  },
	},
}
oppoMonster = {
	{id=11,tid=2001,lv=1,lv2=1,limitGod=0},
	{id=12,tid=2004,lv=1,lv2=1,limitGod=0},
	{id=13,tid=2003,lv=1,lv2=1,limitGod=0},
	{id=14,tid=2002,lv=1,lv2=1,limitGod=0},
}
newGuideRoundSetp ={
  {action="pointAnim",id=9999},
  {action="runToScene"},
  {action="chechkAndStop",lottery={
      normal   = {mConf.NORMAL.id.wood,mConf.NORMAL.id.wood,mConf.NORMAL.id.wood},
    super = {2,2,2,2,2},
    five = false,
    superFlag = false,
    noReLottery = true,
    }},
  {action="Team1",target=1},
  {action = "startPreLottery"},
  {action="Team2"},
  {action="chechkAndStop",
    lottery={
      normal   = {mConf.NORMAL.id.wind,mConf.NORMAL.id.wind,mConf.NORMAL.id.wind},
      super = {2,2,2,2,2},
      five = false,
      superFlag = false,
      noReLottery = true,
    }},
  {action="Team1",target=4},
  {action="talk",id=3,text="居然这么硬！让你尝尝我的必杀技",},
  {action="spMaxManual",id=3},
  {action ="startPreLottery"},
  {action="talk",id=14,text="哈哈哈哈！一帮刚出道的小妞，只有这点能耐嘛"},
  {action="talk",id=14,text="让你们尝尝我火灵王的愤怒！！"},
  {action="spMaxAuto",id=14},
  {action="talk",id=2,text="啊！啊！啊！发型都被打乱啦！本姑娘真的生气啦~~~"},
  {action="chechkAndStop",lottery={
      normal   = {mConf.NORMAL.id.crystal,mConf.NORMAL.id.crystal,mConf.NORMAL.id.crystal},
    super = {2,2,2,2,2},
    five = true,
    superFlag = true,
    noReLottery = true,
    }},
  {action="battleEnd"},
  {action="pointAnim",id=10000},
  {action="leaveScene",id = 1}
}
function startGuideBattle()

  local sceneManager = package.loaded['scene.sceneManager']
  sceneManager.change(sceneManager.SceneType.loading) 
  local loading = package.loaded['scene.loading']
  loading.okCall = function ()
    local animList = {}
      for i,v in pairs(selfRoleList) do
        table.insert(animList,{type=1,id=v.badge.tid})
      end
      for i,v in pairs(oppoMonster) do
        table.insert(animList,{type=2,id=v.tid})
      end
    local bf = initGuideBf()
    bf.newGuideRoundSetp = newGuideRoundSetp
    local scene = package.loaded['battle.scene']
    scene.bf = bf
    scene.pve = nil
    scene.loadAllAnimSuper(animList,function ()
      local sceneManager = package.loaded['scene.sceneManager']
      sceneManager.change(sceneManager.SceneType.nsbattleScene) 
    end)
  end

end
function initGuideBf()
 	local bf = mBattle.initbf(3)
 	local roleId = 10000
    bf.canSkill = false
    bf.team1 = mBattle.initTeam(1)
    bf.team2 = mBattle.initTeam(2)
    bf.team1.fans = 69999999999
    bf.team2.fans = 0
    bf.autoFlag = false 
     mRandom.setSequence({1,2,3,4,5,6,7,8,9})
    for i,v in pairs(selfRoleList) do
        local role = mRole.initRole(v.id,1,mConf.ROLE_STATUS.STAND,v,i)
        bf.team1.roleMap[i] = role
    end
    for i,v in pairs(oppoMonster) do
        local role = mRole.initMonster(v.id,2,mConf.ROLE_STATUS.STAND,v.tid, v.lv,v.lv2,i,v.limitGod)
        bf.team2.roleMap[i] = role
    end
    mBattle.startBattle(bf)


    return bf
end