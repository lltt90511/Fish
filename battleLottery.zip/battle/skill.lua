local tonumber,splitWithTrim,table,print,printTable=tonumber,splitWithTrim,table,print,printTable
local mView = require ("battle.view")
local mRole=require("battle.role")
local mGameData = require ("template.gamedata")
local mConf = require ("battle.conf")
local mView=require("battle.view")
local mSelect=require("battle.select")
local mAction = require ("battle.action")
local mNum =require ("battle.numerial")
local AnimSpeed = mConf.AnimSpeed
local mBuff = require("battle.buff")
local mRandom = require("battle.random")
module("battle.skill",package.seeall)

local gamedata = mGameData.data

function checkHasPassSkill(bf,role,propName)
	local selfTeam = mSelect.selfTeam(bf,role)
	for i,v in pairs(role.passive) do
		if v.passive.propName  == propName then
			return v.passive.id
		end
	end
	for i,v in pairs(selfTeam.passive) do
		if (v.factions ==nil or v.factions == role.factions) and v.passive.propName  == propName then
			return v.passive.id
		end
	end
	return 0
end

function getPassivePropNumInt(skillId)
	local   passiveTpl = gamedata["passive"][skillId]
	return getPropNumInt(passiveTpl.propNum)
end
function getPropNumInt(propNum)
	local propVal = 0
	if string.find(propNum,",") then
		local propArr = splitWithTrim(propNum, "," )
		local lower=tonumber(propArr[1])
		local upper=tonumber(propArr[2])
		propVal = mRandom.getRandom(upper,lower)
	else
		propVal = tonumber(propNum)
	end
	return propVal
end

--初始化被动技能的buff已经队伍级被动技能
function initPassive(bf,role)
	local selfTeam = mSelect.selfTeam(bf,role)
	local oppoTeam = mSelect.oppositeTeam(bf,role)
	if role.type == mConf.ROLE_TYPE.player then
		local roleTpl = gamedata["role"][role.tid]
		if roleTpl.passive ~= "" then
			local skillArr = splitWithTrim(roleTpl.passive, ";")
			local limitArr = splitWithTrim(roleTpl.openLv, ";")
			for i = 1, #skillArr do
				local limit=tonumber(limitArr[i])
				local skillId=tonumber(skillArr[i])
				if role.lv >= limit then
					--目标类型 0=自己 1=己方指定目标（同元素属性） 2=己方全体 3=敌方全体
					initCurrectPassive(bf,skillId,role,selfTeam,oppoTeam)
				end
			end	
		end
		for i,v in pairs(role.initPassive) do
			initCurrectPassive(bf,v.tid,role,selfTeam,oppoTeam)
		end
		--initCurrectPassive(bf,26,role,selfTeam,oppoTeam)
	elseif role.type == mConf.ROLE_TYPE.pve then
		local roleTpl = gamedata["battleMonster"][role.tid]
		local skillArr = splitWithTrim(roleTpl.passive, ";") 
		if roleTpl.passive=="" then
			return -1
		end
		for i = 1, #skillArr do
			local skillId=tonumber(skillArr[i])
			initCurrectPassive(bf,skillId,role,selfTeam,oppoTeam)
		end
	end
end

-- 注意 factions ，可以区分针对属性应用的
function initCurrectPassive(bf,skillId,role,selfTeam,oppoTeam)
	--目标类型 0=自己 1=己方指定目标（同元素属性） 2=己方全体 3=敌方全体
	print (skillId)
	local passiveTpl = gamedata["passive"][skillId]
	local target = nil
	local factions = role.factions
	if passiveTpl.targetClass == 0  then
		target = role
		factions = nil
	elseif passiveTpl.targetClass ==1 then
		target = selfTeam
	elseif passiveTpl.targetClass == 2 then
		target = selfTeam
		factions = nil
	elseif passiveTpl.targetClass == 3  then
		target = oppoTeam
		factions = nil
	end

	table.insert(target.passive,{passive=passiveTpl,roleid = role.id,factions =factions})
	if passiveTpl.buff2 > 0  then
		if passiveTpl.targetClass == 0 then
			mBuff.addBuff(passiveTpl.buff2,role,role,passiveTpl.rate1)
		elseif passiveTpl.targetClass == 1 then
			for i,v in pairs(selfTeam.roleMap) do
				if v.factions == role.factions then
					mBuff.addBuff(bf,passiveTpl.buff2,role,v,passiveTpl.rate1)
				end
			end
		elseif passiveTpl.targetClass == 2 then
			for i,v in pairs(selfTeam.roleMap) do
				mBuff.addBuff(bf,passiveTpl.buff2,role,v,passiveTpl.rate1)
			end
		elseif passiveTpl.targetClass == 3 then
			for i,v in pairs(oppoTeam.roleMap) do
				mBuff.addBuff(bf,passiveTpl.buff2,role,v,passiveTpl.rate1)
			end
		end
	end
	if passiveTpl.buff1 >0 then
		local random = mRandom.getRandom(1,100)
		mBuff.addBuff(bf,passiveTpl.buff1,role,role,passiveTpl.rate1)
	end
end


function canDodge(bf,attackType,attacker,hurter)
	--local hasAccurateSkill=checkHasPassSkill(bf,attacker,"accurate")	
	--local hasFocusedSkill=checkHasPassSkill(bf,attacker,"focused")
	local hasDodgeSkill = nil	
	if 	attackType == mConf.ATTACK_TYPE.normal  then
		local hasAccurateSkill=checkHasPassSkill(bf,attacker,"accurate")
		hasDodgeSkill=checkHasPassSkill(bf,hurter,"dodge")
		if hasAccurateSkill >0 or hasDodgeSkill <=0 then
			return false
		end
	elseif attackType == mConf.ATTACK_TYPE.skill then
		local hasFocusedSkill=checkHasPassSkill(bf,attacker,"focused")
		hasDodgeSkill=checkHasPassSkill(bf,hurter,"skillDodge")
		if hasFocusedSkill >0 or hasDodgeSkill <=0 then
			return false
		end
	end
	if hasDodgeSkill >0 then
		local propNum=getPassivePropNumInt(hasDodgeSkill)
		local rondom = mRandom.getRandom(1,100)
		if rondom < propNum then
			mView.dodgeCmd(bf,hurter.id,bf.time)
			return true
		end
	end
	return false

end






-- attributeHurtR	属性攻击力%比，对应自身的元素属性（角色装备的徽章属性）
-- restore			HP恢复类，恢复量=Satk*（1+atk/1000）*0.3*（填写倍率）
-- restoreR			HP恢复类，恢复量=最大HP%比
-- bleed	HP值直接减少，减少值=Satk*（1+atk/1000）*（填写%）
-- bleedR	HP值百分比减少，减少值=HP*（填写）%
-- position	固定伤害
local skillAnimRate = 6
function doSkillAttack(bf,role,targetList,skillId)
	local tpl = gamedata["skill"][skillId]
	local propNum = tpl.propNum
	local hasBack = false
	local backSkill = nil
	local backPercent = 0.5
	local spAdd = 0
	if tpl.type == 1 then
		mView.skillNameEffect(bf,tpl.name)
	end
	local add = 1
	if tpl.skillres == 2 then
		add = 1.5
	end
	if tpl.releaseNum  > 1 then
		mView.preSkillCmd(bf,role.id,bf.time,role.preSkillTime/skillAnimRate/AnimSpeed*add,skillAnimRate*AnimSpeed*add,tpl.skillres,tpl.sound)
		role.resumeTime = bf.time + role.preSkillTime/skillAnimRate/AnimSpeed*add
	else
		mView.preSkillCmd(bf,role.id,bf.time,role.preSkillTime/AnimSpeed*add,1*AnimSpeed*add,tpl.skillres,tpl.sound)
		role.resumeTime = bf.time + role.preSkillTime/AnimSpeed*add
	end
		
	coroutine.yield()
	if tpl.buff1 >0 then
		mBuff.addBuff(bf,tpl.buff1,role,role,tpl.rate1)
	end
	for i=1,tpl.releaseNum do
		for _,target in pairs(targetList) do
			local hp = 0
			if tpl.propName == "restore" then
	            --TODO:修改
				hp = -role.badgeBean.satk *(1+role.atk/1000)*0.3*propNum
			elseif tpl.propName == "restoreR" then
				hp = -mNum.getHpMax(bf,role)*(propNum/100)
			elseif tpl.propName == "bleed" then
				hp = role.badgeBean.satk *(1+role.atk/1000)*propNum /100
			elseif tpl.propName == "bleedR" then
				hp = mNum.getBattleHp(bf,target)*propNum /100
			elseif tpl.propName == "position" then
				hp = propNum
			elseif tpl.propName == "clear" then
				hp = 0
				mBuff.clear(bf,target)
			elseif tpl.propName == "attributeHurtR" then
				hp = mNum.getBattleAtk(bf,role,propNum)-mNum.getBattleDef(bf,target) 
				if target.factions==mConf.ADD[role.factions]  then
					hp = math.ceil(hp * 1.5)
				end
				if role.factions==mConf.ADD[target.factions]   then
					hp = math.ceil(hp * 0.5)
				end	
				if hp < 0 then
					hp = 1
				end
			end
			if hp == 0 then -- 无视

			elseif hp <0 then --恢复系
				if tpl.skillres == 1 then
					mView.beHurtCmd(bf,target.id,role.hurtAnim ,bf.time,target.hurtTime,true)	
				else
					mView.beHurtCmd(bf,target.id,role.skillHurtAnim ,bf.time,target.hurtTime,true)	
				end
				local buff = mBuff.checkHasBuff(bf,target,"trauma")
				if buff<=0 then

					mAction.reduceHpCmd(bf,target,role,hp)
				else
					mView.buffEffect(bf,target.id,gamedata['buff'].buff)
				end
				--mAction.reduceHpCmd(bf,target,role,hp)
			else
				--第一·
				if i == 1 then
					mView.specialPng(bf,target.id,tpl.specialPng)	
				end
				if not canDodge(bf,mConf.ATTACK_TYPE.skill,role,target) then
					local hp = mNum.getHurtAfterParry(bf,mConf.ATTACK_TYPE.skill,target,role,hp)
					--for time=1,tpl.blowNum do
					mAction.reduceHpCmd(bf,target,role,hp,false,tpl.blowNum)
					--end
					if spAdd < 8 then
						if role.type == mConf.ROLE_TYPE.pve then
							mAction.changeSp(bf,role,30)
						else
							mAction.changeSp(bf,role,5)
						end
						spAdd = spAdd + 1
					end
					if tpl.skillres == 1 then
						mView.beHurtCmd(bf,target.id,role.hurtAnim ,bf.time,target.hurtTime,false,tpl.blowNum)	
					else
						mView.beHurtCmd(bf,target.id,role.skillHurtAnim ,bf.time,target.hurtTime,false,tpl.blowNum)	
					end
					mNum.Vampire(bf,mConf.ATTACK_TYPE.skill,role,hp)
				end
			end
		end
		if i ~= tpl.releaseNum then
			--准备下一次法术释放
			mView.endSkillCmd(bf,role.id,bf.time,role.endSkillTime/skillAnimRate/AnimSpeed*add,skillAnimRate*AnimSpeed*add)
			role.resumeTime = bf.time+ role.endSkillTime/skillAnimRate/AnimSpeed*add
			coroutine.yield()
			mView.preSkillCmd(bf,role.id,bf.time,role.preSkillTime/skillAnimRate/AnimSpeed*add,skillAnimRate*AnimSpeed*add,tpl.skillres)
			role.resumeTime = bf.time + role.preSkillTime/skillAnimRate/AnimSpeed*add
			coroutine.yield()

		end
	end

	if tpl.buff2 >0 then
		for _,target in pairs(targetList) do
			mBuff.addBuff(bf,tpl.buff2,role,target,tpl.rate2)
		end
	end
	if tpl.buff3 > 0 then
		local team = mSelect.selfTeam(bf,role)
		for _,target in pairs(team.roleMap) do
			if target.status ~= mConf.ROLE_STATUS.DEAD then
				mBuff.addBuff(bf,tpl.buff3,role,target,tpl.rate3)
			end
		end	
	end	
	mAction.removeAllTarget(bf,role)
	if tpl.releaseNum  > 1 then
		mView.endSkillCmd(bf,role.id,bf.time,role.endSkillTime/skillAnimRate/AnimSpeed*add,skillAnimRate*AnimSpeed*add)
		role.resumeTime = bf.time + role.endSkillTime/skillAnimRate/AnimSpeed*add
	else
		mView.endSkillCmd(bf,role.id,bf.time,role.endSkillTime/AnimSpeed*add,1*AnimSpeed*add)
		role.resumeTime = bf.time + role.endSkillTime/AnimSpeed*add
	end
	coroutine.yield()
	return hasBack,backPercent,backSkill
end



function skillAttack(bf,role,skillId)
	print ("skillAttack",skillId)
	local battle = package.loaded['battle.battle']
	local tpl = gamedata["skill"][skillId]
	mView.addLog(bf,"【"..role.name.."】使用技能 【"..tpl.name.."】")
	--目标类型 0=自己 1=敌方指定目标 2=己方指定目标 3=己方全体 4=敌方全体
	if tpl.targetClass == 0 then
		doSkillAttack(bf,role,{role},skillId)
		if role.afterSkillAction  then
			role.afterSkillAction  = nil
			mView.stopUserSkill(bf)
		end
		mAction.moveTo(bf,role,role,false)
	elseif tpl.targetClass == 1 then
		local target = nil
		-- 跑动
		target = mSelect.getAttackTarget(bf,role,-1)
		if target == nil and role.status ~= mConf.ROLE_STATUS.DEAD then
			-- 死光了？
			mAction.moveTo(bf,role,role,true)
			role.status = mConf.ROLE_STATUS.STAND
			role.resumeTime = mConf.timeMax
			coroutine.yield()	
			return 
		end
		mAction.moveTo(bf,role,target,true)
		local targetList = {target}
		--添加到伤害列表 防止提前死亡
		for _,v in pairs(targetList) do
			mAction.addTarget(bf,role,v)
		end
		--if target ~= nil then
		local speed = 1
		if tpl.releaseNum > 1 then
			speed = 2
		end
		doSkillAttack(bf,role,targetList,skillId)
		if role.afterSkillAction  then
			role.afterSkillAction  = nil
			mView.stopUserSkill(bf)
		end
		role.status = mConf.ROLE_STATUS.STAND	
		mAction.moveTo(bf,role,role,true)

		if bf.autoFlag == true then
			local skillId,power = battle.checkCanSkill(bf,role)
			if skillId > 0 then
				mView.playEffect(bf,"effect_12")
				mAction.changeSp(bf,role,-power)
				battle.beforeSkillStart(bf,role,gamedata['skill'][skillId].name)
				skillAttack(bf,role,skillId)
			else
				role.status = mConf.ROLE_STATUS.STAND
				role.resumeTime = mConf.timeMax
				coroutine.yield()
			end
		else
			role.status = mConf.ROLE_STATUS.STAND
			role.resumeTime = mConf.timeMax
			coroutine.yield()
		end
		--end
	elseif tpl.targetClass == 2 then

	elseif tpl.targetClass == 3 then
		local team = mSelect.selfTeamAlive(bf,role)
		doSkillAttack(bf,role,team,skillId)
		if role.afterSkillAction  then
			role.afterSkillAction  = nil
			mView.stopUserSkill(bf)
		end
		mAction.moveTo(bf,role,role,false)
	elseif tpl.targetClass == 4 then
		if tpl.propName == "believerSkill" then
		
		else
			local target = nil
			-- 跑动
			target = mSelect.getAttackTarget(bf,role,-1)
			if target == nil and role.status ~= mConf.ROLE_STATUS.DEAD then
				-- 死光了？
				mAction.moveTo(bf,role,role,true)
				role.status = mConf.ROLE_STATUS.STAND
				role.resumeTime = mConf.timeMax
				coroutine.yield()
				return 	
			end
			local targetList = mSelect.oppositeTeamAlive(bf,role)
			for _,v in pairs(targetList) do
				mAction.addTarget(bf,role,v)
			end
			
			mAction.moveTo(bf,role,target,true)

			
			doSkillAttack(bf,role,targetList,skillId)
			if role.afterSkillAction  then
				role.afterSkillAction  = nil
				mView.stopUserSkill(bf)
			end
			--coroutine.yield()
			mAction.moveTo(bf,role,role,false)
			--role.resumeTime = mConf.timeMax
		end
	end
end