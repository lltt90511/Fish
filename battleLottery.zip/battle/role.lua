local math,table,tonumber,pairs,splitWithTrim,string=math,table,tonumber,pairs,splitWithTrim,string
local mGameData = require ("template.gamedata")
--local mSkill=require("battle.skill")
local mConf = require ("battle.conf")
local mSelect=require("battle.select")
local mView=require("battle.view")
local countLv = require("logic.countLv")
local nNum = require("battle.numerial")
module("battle.role",package.seeall)

local gamedata = mGameData.data
--[[
public int id;
public int charId;
public String name;
public int tid;
public long exp;
public int believer;
public long charmExp;
public int owner;
public int dear ;//玩家请密度 加成
public ClientBattleBadge badge= {
    public int id;
    public int tid;
    public int charId;
    public int roleId;
    public long exp;
    public int breakTime;
    public int skillLv;
}
]]--
function getSkillByIdAndLv(groupId,lv)
    for i,v in pairs(gamedata['skill']) do
        if v.group == groupId and v.level == lv then
            return i
        end
    end
    return -1
end
function updateLv(bf,role,badgeExp,roleExp)
    role.badgeLv = countLv.getBadgeLv(role.badgeBean.tid,badgeExp)
    role.badgeBean.lv = role.badgeLv
    role.lv = countLv.getRoleLv( roleExp )
    role.badgeBean.shp,role.badgeBean.satk,role.badgeBean.sdef = countLv.getBadgeBaseAttribute(role.badgeBean.tid,role.badgeBean.breakTime,badgeExp)
    role.hpMax,role.atk,role.def = countLv.getRoleBaseAttribute(role.tid,role.charmExp,roleExp)
    role.hp = nNum.getHpMax(bf,role)

    
end
function initRole(id,teamId,status,info,pos)
    local role = {}
    role.viewPos = pos
    role.owner = info.owner
    
    role.id=id
    role.tid=info.tid
    role.autoFlag = info.autoFlag
    role.teamId=teamId
    role.charmExp = info.charmExp
    role.badgeLv = countLv.getBadgeLv(info.badge.tid,info.badge.exp)
    role.charmLv = countLv.getCharmLv( info.charmExp);
    role.lv = countLv.getRoleLv( info.exp )
    role.name = info.name
    role.notInit = true
    local roleTpl=gamedata["role"][info.tid]
    local badgeTpl=gamedata["badge"][info.badge.tid]
    --printTable (info.badge)
    --TODO:更具徽章等级计算徽章的攻击防御
    --role.badgeBean=cloneTable(badgeTpl)
    if role.name == nil then
        role.name = badgeTpl.name
    end
    role.badgeBean = {}
    role.badgeBean.lv = role.badgeLv
    role.badgeBean.tid = info.badge.tid
    role.badgeBean.skill = badgeTpl.skill
    role.badgeBean.openLv = badgeTpl.openLv
    role.badgeBean.breakTime = info.badge.breakTime

    if role.badgeBean.breakTime == nil then
        role.badgeBean.breakTime = 0
    end
    role.badgeBean.quality  = badgeTpl.quality + role.badgeBean.breakTime 
    role.skillLv = info.badge.skillLv
    if role.skillLv == nil then
        role.skillLv = 0
    end
    role.skillLv = role.skillLv + 1
    role.badgeBean.shp,role.badgeBean.satk,role.badgeBean.sdef = countLv.getBadgeBaseAttribute(info.badge.tid,role.badgeBean.breakTime,info.badge.exp)


    role.img = "Image/icon_circle_"..badgeTpl.img..".png"
    role.anim = badgeTpl.res
    role.name = badgeTpl.name
    role.dear = info.dear
    role.animFlag = true
    -- TODO:根据成长线 计算当前的攻击力防御力
    role.hpMax,role.atk,role.def = countLv.getRoleBaseAttribute(role.tid,info.charmExp,info.exp)
    role.hp = role.hpMax
    --动画
    local anim = gamedata['anim'][badgeTpl.animId]

    role.runTime = anim.runFrame/12
    role.preAtkTime =anim.frontFrame/12
    role.endAtkTime =anim.afterFrame/12
    role.hurtTime   =anim.runFrame/12
    role.preSkillTime = anim.skillFrontFrame/12
    role.endSkillTime = anim.skillAfterFrame/12
    role.selfAnim = anim
    role.hurtAnim = gamedata['anim'][badgeTpl.hurtAnimId]
    --role.hurtSound = anim.Sound
    role.skillHurtAnim = gamedata['anim'][badgeTpl.skillHurtAnimId]
    role.status=status
    role.power=0
    role.factions=badgeTpl.factions
    role.initFactions=badgeTpl.factions
    role.atkCeilNum=-1
    role.minusHpTotal=0
    role.type=mConf.ROLE_TYPE.player

    role.buff = {}
    role.passive = {}
    role.hurtList ={}
    role.atkeft      =nil
    role.minusHpTotal = 0
    role.pos = id
    role.initPassive = {}

    initRoleSkill(role)
    if info.passiveSkill then
        for i,v in pairs(info.passiveSkill) do
            local str = splitWithTrim(v,":")
            local sid = tonumber(str[1])
            local slv = tonumber(str[2])
            table.insert(role.initPassive ,{tid = sid})
        end
        printTable(info.passiveSkill)
    end
    return role
end

function initMonster(id,teamId,status,tid,lv,lv2,pos,limitGod)

    local role = {}
    role.viewPos = pos
    role.id=id
    role.tid=tid
    role.teamId=teamId
    role.lv = lv
    role.badgeLv = lv2
    role.notInit = true
    role.limitGod = limitGod
    local monTpl= gamedata["battleMonster"][tid]
    local grow =  gamedata['growUp'][monTpl.growId]
    --role.hp = monTpl.hp*(lv2-1) 

    role.def = monTpl.def*(lv2-1)
    role.atk = monTpl.atk*(lv2-1)
    role.hpMax = monTpl.hp*(lv2-1) 
    role.shdow_x = monTpl.shdow_x
    role.badgeBean = {}
    role.badgeBean.shp = monTpl.shp + grow.hpgrow *(lv-1)
    role.badgeBean.satk = monTpl.satk + grow.atkgrow *(lv-1)
    role.badgeBean.sdef = monTpl.sdef + grow.defgrow *(lv-1)
     role.badgeBean.quality  = 0
    --print (role.def ,role.atk,role.hpMax,role.badgeBean.shp,role.badgeBean.satk,role.badgeBean.sdef)
    role.hp = role.hpMax
    role.name = monTpl.name
    role.gold = monTpl.gold
    role.exp = monTpl.godPower
    role.dropItemList = {}
    local item = monTpl.dropBadge

    local itemList = splitWithTrim(item, "|")
    for i = 1, #itemList do
        local List = splitWithTrim(itemList[i], ",")
        table.insert(role.dropItemList,{id=tonumber(List[1]),percent=tonumber(List[2])})
    end

    role.status=status
    role.power=0
    role.factions=monTpl.factions
    role.initFactions=monTpl.factions
    role.atkCeilNum=-1
    role.minusHpTotal=0
    role.img = "Image/icon_circle_"..monTpl.img..".png"
    role.anim = "Image/icon_npc_"..monTpl.img..".png"
    role.animFlag = false
    role.type=mConf.ROLE_TYPE.pve
    --role.lv = math.floor( monTpl.level *lv )
    role.animType = monTpl.animType
    role.hurtAnim = gamedata['anim'][tonumber(monTpl.hrtanimid)]
    role.skillHurtAnim = gamedata['anim'][tonumber(monTpl.skillhurtanimid)]
    role.scale = monTpl.scale
--动画类型1=地面近战 2=地面远程 3=空中近战 4=空中远程
    local animScale = 1.5
    if role.animType == 1 then
        role.runTime = 0.5
        role.preAtkTime = 0.25*animScale
        role.endAtkTime = 0.1*animScale
        role.hurtTime   = 0.1*animScale
        role.preSkillTime = 0.25*animScale
        role.endSkillTime = 0.1*animScale
    elseif role.animType == 2 then
        role.runTime = 0
        role.preAtkTime = 0.25*animScale
        role.endAtkTime = 0.1*animScale
        role.hurtTime   = 0.1*animScale
        role.preSkillTime = 0.25*animScale
        role.endSkillTime =0.1*animScale
    elseif role.animType == 3 then
        role.runTime = 0.5
        role.preAtkTime = 0.25*animScale
        role.endAtkTime = 0.1*animScale
        role.hurtTime   = 0.1*animScale
        role.preSkillTime = 0.25*animScale
        role.endSkillTime = 0.1*animScale
    elseif role.animType == 4 then
        role.runTime = 0
        role.preAtkTime = 0.25*animScale
        role.endAtkTime = 0.1*animScale
        role.hurtTime   = 0.1*animScale
        role.preSkillTime = 0.25*animScale
        role.endSkillTime =0.1*animScale
    end
    if tid == 2002 then
        role.preSkillTime = 1
        role.endSkillTime =0.1
    end
    role.buff = {}
    role.passive = {}
    role.hurtList ={}
    role.pos = id

    role.skill = {}
    initMonsterSkill(role,monTpl)
    --initRoleSkill(role)
    return role
end
function initMonsterSkill(role,monTpl)
    local skillArr = splitWithTrim(monTpl.skill, ";")
    for i = 1, #skillArr do
        table.insert(role.skill,tonumber(skillArr[i]))
    end
end
function initRoleSkill(role)
	local badgeTpl = role.badgeBean
	if badgeTpl == nil then
		return
	end
	role.skill = {}
	if badgeTpl.skill == nil then
		return
	end
	--local roleTpl = gamedata["role"][badgeTpl.tid]
	--if roleTpl.passive ~= "" then
	local skillArr = splitWithTrim(badgeTpl.skill, ";")
	local limitArr = splitWithTrim(badgeTpl.openLv, ";")
    for i = 1, #skillArr do
		local limit=tonumber(limitArr[i])
		local skillId=getSkillByIdAndLv(tonumber(skillArr[i]),role.skillLv)
		if role.badgeBean.quality >= limit then

			table.insert(role.skill,skillId)
		end
	end

end

