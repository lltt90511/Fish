local math,table,tonumber,pairs,print,printTable,splitWithTrim=math,table,tonumber,pairs,print,printTable,splitWithTrim
local coroutine,L_onError,xpcall,string,debug = coroutine,L_onError,xpcall,string,debug
local scriptsVersion = scriptsVersion
local notWriteFile = notWriteFile
local mRole = require("battle.role")
local mGameData = require ("template.gamedata")
local mConf=require("battle.conf")
local mRandom=require("battle.random")
local mBattle = require("battle.battle")
local mView = require("battle.view")
local mNum = require("battle.numerial")
local userdata = require "logic.userdata"
local mRemuser = require "battle.remuser"
local event = require"logic.event"
local guideEvent = require "guide.conf".EVENT
local gamedata = mGameData.data
local conf = mConf
local mLottery = require "battle.lottery"
local data = require "battle.data"
module("battle.pve", package.seeall)
--[[
selfTeam = {
    [1]={id = 1,tid=4,badgetid=1,lv=1},
    [2]={id = 2,tid=5,badgetid=1,lv=1},
    [3]={id = 3,tid=8,badgetid=1,lv=1},
    [4]={id = 4,tid=1,badgetid=1,lv=1},
}
]]
bfUnId = 0
endTime = 0
fileName = "/pvpTmp.obj"
cut  = "nshxfengefu"
encryptStrCnt = 7
function clearData(pve)
    local file = io.open(pve.path,"wb")
    file:close()
end
function writeData(pve,str)
    if notWriteFile ~= true then
        if pve.file == nil then
            pve.file = io.open(pve.path,"ab+")
        end
        pve.file:write(C_encryptString(str..cut))
        pve.file:flush()
    end
end
function recodeUserAction(pve,bf,type,param)
    if pve == nil or pve.pvp == true or pve.newGuide == true then
        return
    end
    if param == nil then
        param = -1
    end
    data.setRunningInfo("battleId",bf.id)
    data.setRunningInfo("round",pve.round)
    data.setRunningInfo("playedAction",pve.playedAction)
    if type ~= mConf.ActionType.checkPoint then
        data.addUserAction(pve,bf,type,param)
    end
end
function endPveCallBack(pve)
    local actionList = {}
    for i=1,#pve.actionList do
        if pve.actionList[i].type  ~= mConf.ActionType.checkPoint  then
            local action = pve.actionList[i]
            table.insert(actionList,{action.type,action.process,action.round,action.playedAction,action.param})
        end
    end
    if pve.file then
        pve.file:close()
        pve.file = nil
    end
    encryptCall("endPveBattle",{pveId=pve.pveid,
        result=pve.succes,
        restartGold = pve.result.restartGold,
        resultDiamonds=pve.result.resultDiamonds, 
        gold=pve.result.gold,
        exp=pve.result.exp,
        itemList=pve.result.item,
        itemCnt = #pve.result.item,
        fragmentList = pve.result.fragment,
        fragmentCnt = #pve.result.fragment,
        giftList = pve.result.giftList,
        giftCnt = #pve.result.giftList,
        actionList=actionList})
end
function onStartPveBattle(info,startAnim,endAnim,gold)
    performWithDelay(function()
        data.battleDbInit()
        data.clearUserAction()
        data.clearRunningInfo()
        data.writeBattleJson(info,startAnim,endAnim,gold)
        data.setRunningInfo("hasBattle",true)
        data.setRunningInfo("battleId",0)
        data.setRunningInfo("round",0)
        data.setRunningInfo("playedAction",0)
        local pve,bf,info2 = onRemusePveBattle(info,startAnim,endAnim,gold,{},{})  
        startPveBattle(pve,bf,info2)
    end,0)
end

function startPveBattle(pve,bf,info)
    print ("pve bf id:",bf.id)
    local scene = package.loaded['battle.scene']
    scene.pve = pve
    scene.bf  = bf
    
    scene.loadAllAnimSuper(pve.animList,function()
        local sceneManager = package.loaded['scene.sceneManager']
        sceneManager.change(sceneManager.SceneType.nsbattleScene)
        event.pushEvent("LOADINGMIN_CHANGE",true)
    end)
end

function remuseNotEndBattle()
    data.battleDbInit()
    local runningInfo = data.getRunningInfo()
    if runningInfo.hasBattle ~= "true" then
        return false
    end
    if runningInfo.battleEnd  == "true" then
        -- special 
        return false
    end
    runningInfo.battleId = tonumber(runningInfo.battleId)
    runningInfo.round = tonumber(runningInfo.round)
    runningInfo.playedAction = tonumber(runningInfo.playedAction)

    local actionList = data.readAllUserAction()
    local parm = data.readBattleJson()
    if parm == nil then
        data.battleDbInit()
        data.clearUserAction()
        data.clearRunningInfo()
        return false
    end
   
    --file:close()
    local pve
    local bf
    local info2
    local err =true
    xpcall(function ()
        pve,bf,info2,error = onRemusePveBattle(parm.info,parm.startAnim,parm.endAnim,parm.gold,actionList,runningInfo)
        pve.path = path
        err= false
    end)
    if err  then
        return false
    else
        return true,pve,bf,info2,error
    end
end
-- 根据参数初始化pve运行环境
function initForPve(pveid,specialEffect,selfTeam,startAnim,endAnim,gold,diamonds,fans,leader)
    --startAnim = true
    local pve = {}
    pve.battlePlayListFile = "battlelist_"..os.time()..".txt"
    pve.pveid = pveid
    pve.battleId = 0
    pve.animList  = {}
    pve.specialEffect = specialEffect
    -- 战斗开始时身上金币和钱
    pve.gold = gold
    pve.diamonds = diamonds
    -- 重摇花费管理
    pve.lotteryRefCnt = mConf.ReLotteryCnt
    pve.newLottery = true2

    -- 战斗返回参数
    pve.succes =2
    -- pve模版表分析
    -- 事件
    pve.tmp = gamedata['battlePoint'][pveid]  
    pve.sceneMap  = pve.tmp.sceneMap
    local propArr = pve.tmp.eventList
    pve.event = {}
    for i,v in pairs(gamedata['event']) do
        if v.groupId  == pve.tmp.eventList then
            print ("############################",i)
            table.insert(pve.event,i)
        end
    end

    pve.eventCnt = #pve.event
    --关务
    local monsterList = splitWithTrim(pve.tmp.monsterList, "|")
    pve.monsterList = {}
    pve.monsterListCnt = #monsterList
    for i,v in pairs(monsterList) do
        local str = splitWithTrim(v, ",")
        local m = {}
        m.tid = tonumber(str[1])
        m.lv = tonumber(str[2])
        m.lv2=tonumber(str[3])
        m.limitGod = tonumber(str[4])
        table.insert(pve.monsterList ,m)
        table.insert(pve.animList,{type=2,id=m.tid})
    end
    --boss
    local bList = splitWithTrim(pve.tmp.bossList, "|")
    local bossList = {}
    for i= 1,#bList do
        local boss = splitWithTrim(bList[i],",")
        local bossInfo = {}
        bossInfo.time = tonumber(boss[1])
        local cnt = tonumber(boss[2])
        bossInfo.monsterList = {}
        for i=1,cnt do
            local mon = {}
            mon.tid = tonumber(boss[(i-1)*4+3])
            mon.lv = tonumber(boss[(i-1)*4+4])
            mon.lv2 = tonumber(boss[(i-1)*4+5])
            mon.limitGod =  tonumber(boss[(i-1)*4+6])
            table.insert(bossInfo.monsterList ,mon)
            table.insert(pve.animList,{type=2,id=mon.tid})
        end
        table.insert(bossList ,bossInfo)
    end
    pve.bossList = bossList
    --百分比添加
    pve.processAdd =  100 / pve.tmp.process 
    --已经进入几次关卡了
    pve.processCnt = 0
    pve.processTotal = pve.tmp.process  
    -- 产出
    pve.selfTeam = selfTeam
    pve.selfTeamCnt = 0
    pve.roleMaxId = 100
    for i,v in pairs(selfTeam) do
        if v.id > pve.roleMaxId then
            pve.roleMaxId = v.id
        end
        if v.id == leader then
            pve.leader = i
        end
        pve.selfTeamCnt = pve.selfTeamCnt + 1
        table.insert(pve.animList,{type=1,id=v.badge.tid})
    end
    pve.roleMaxId = pve.roleMaxId + 1
    pve.canLottery = true
    pve.firstLottery = true

    if startAnim then
       pve.startAnim = pve.tmp.startPlot
    end
    --pve.startAnim  = 1
    if endAnim then
        pve.endAnim = pve.tmp.endPlot
    end
    pve.fans = fans
    --产出花费 记录
    pve.result = {resultDiamonds = 0,restartGold = 0,gold = 0,exp=0,item={},fragment={},giftList={}}
    --初始战报
    initSelfTeamHp(pve)
    mView.changeLottery(pve.bf,mConf.LotteryType.PVE)
    mView.startUserPveLottery(pve.bf)
    mView.openGuide(pve.bf,guideEvent.startPveMachine)
    mView.addLog(pve.bf,"开始战斗")
    --mView.waitForLottery(pve.bf)
    --mView.canDouble(pve.bf)
    -- ************运行信息*********
    -- 是否正在pve战斗中 否则在事件中
    pve.inBattle = false
    -- 回合状态
    pve.process = 0
    pve.round = 1
    pve.playedAction = 1
    pve.lotteryRunning = false
    pve.lottery = nil
    -- 老虎机当前类型
    pve.lotteryType = mConf.LotteryType.PVE
    -- 战斗结束回调
    pve.battleEndCallBack = nil
    -- 所有按钮控制位 精确控制所有按钮的状态和是否可以按下

    pve.buttonStatus = {
        start   = {vis = true ,touch = false },
        double  = {vis = true ,touch = false ,status = false},
        reStart = {vis = false ,touch = false },
        auto    = {vis = true ,touch = true ,status = false},
    }
    -- 是否自动Flag
    pve.autoFlag = false
    -- ************运行信息**********

    return pve
end

function onRemusePveBattle(info,startAnim,endAnim,gold,actionList,runningInfo,battleTest)
    mRandom.setSequence(info.battleRandomQue,"random_"..os.time()..".txt")
    printTable(info.battleRandomQue)
    for i,v in pairs(info.team) do
        if type(v) ~= "userdata" then
            v.hp = nil
            v.power = 0
        else
            info.team[i]=nil
        end
    end
    
    local pve = initForPve(info.pveId,info.specialEffect,info.team,startAnim,endAnim,gold,diamonds,info.fans,info.leader)
    pve.path = path
    pve.actionList = actionList
    local flag,error,bf = mRemuser.remusePveData(pve,runningInfo,battleTest)
    if battleTest then
        return flag,error,pve
    end
    print ("#end Remuse Pve Data")
    --printTable(bf.playList)
    if #pve.actionList > 0 then
        pve.enterAnim = false
    else
        pve.enterAnim = true
    end
    if flag == false then
        if error == 4 or error == 5 then
            endPveCallBack(pve)
            return pve,bf,info,error
        end
        assert(flag,error)
        return 
    else

    end
    return pve,bf,info,error
end
function noBattleFromServer()
    data.battleDbInit()
    data.clearUserAction()
    data.clearRunningInfo()
    data.clearBattleJson()
     local sceneManager = package.loaded['scene.sceneManager']
           sceneManager.change(sceneManager.SceneType.mainScene)
  -- 战斗验证失败
end
function onBattleEnd(info,dearAdd,dear,image,exp,activeExp,first)
   print("##########onBattleEnd")
   info.dearAdd =dearAdd
   info.dear =dear
   info.image = image
   info.exp2 = exp
   info.activeExp = activeExp
    data.battleDbInit()
    data.clearUserAction()
    data.clearRunningInfo()
    data.clearBattleJson()
   performWithDelay (function ()
            --printTable(info)
        if userdata.UserInfo.pvePointBattle < info.pveId then
           userdata.UserInfo.pvePointBattle = info.pveId
        end
        if info.result == 1 then
           if userdata.UserInfo.pvePointClear < info.pveId then
              userdata.UserInfo.pvePointClear = info.pveId
           end
           local sceneManager = package.loaded['scene.sceneManager']
           sceneManager.change(sceneManager.SceneType.mainScene)

           local pveResult =  package.loaded['scene.pveResult']
           pveResult.info = info
           local mainScene = package.loaded['scene.main']
           mainScene.afterLoadingEnd = function()
              mainScene.createSubWeiget(mainScene.widgetID.pveResult)
           end
        else
           local sceneManager = package.loaded['scene.sceneManager']
           sceneManager.change(sceneManager.SceneType.mainScene)
           local mainScene = package.loaded['scene.main']
           mainScene.afterLoadingEnd = function()
              mainScene.createSubWeiget(mainScene.widgetID.battleQuest)
           end
        end
    end,endTime-os.time())
end

function pveDouble(pve)
    if pve.diamonds >= 10 then
        pve.diamonds = pve.diamonds - 10
        pve.result.resultDiamonds = pve.result.resultDiamonds + 10
        pve.double = true
        return true
    else
        return false
    end 
end
function pveBattleDouble(pve)
    return false
end
function rebornDiamonds(pve)
    if userdata.UserInfo.diamonds >= 100 then
        userdata.UserInfo.diamonds = userdata.UserInfo.diamonds - 100
        pve.result.resultDiamonds = pve.result.resultDiamonds + 100
        return true
    else
        return false
    end
end
function changeGoldForBattleRestart(pve)
    if pve.gold >= pve.bf.lotteryRefCnt then
        pve.gold = pve.gold - pve.bf.lotteryRefCnt
        pve.result.restartGold = pve.result.restartGold +pve.bf.lotteryRefCnt
        return true
    else
        return false
    end 
end
function changeGoldForReStart (pve)
    if pve.gold > pve.lotteryRefCnt then
        pve.gold = pve.gold - pve.lotteryRefCnt
        pve.result.restartGold = pve.result.restartGold +pve.lotteryRefCnt
        return true
    else
        return false
    end
end




function initSelfTeamHp(pve)
    local bf = mBattle.initbf()
    bf.specialEffect = pve.specialEffect
    bf.battlePlayListFile = pve.battlePlayListFile 
    pve.battleId = pve.battleId + 1
    bf.id = pve.battleId
    bf.canSkill = false
    bf.team1 = mBattle.initTeam(1)
    bf.team2 = mBattle.initTeam(2)
   for i=1,4 do
        local v = pve.selfTeam[i]
        if v ~= nil then
            local role = mRole.initRole(v.id,1,mConf.ROLE_STATUS.STAND,v,i)
            bf.team1.roleMap[i] = role
        end
    end
    bf.team1.teamLeaderId = pve.leader
    mBattle.startBattle(bf)
    for i,role in pairs(bf.team1.roleMap) do
        for ii,v in pairs(pve.selfTeam) do
            if v.id == role.id then
                v.hpMax = mNum.getHpMax(bf,role)
                if v.hp == nil then
                    v.hp = v.hpMax
                end
                role.power = v.power
                role.owner = v.owner
            
                mNum.reduceHp(bf,role,v.hpMax - v.hp)
                --v.status = mConf.ROLE_STATUS.STAND
                if v.hp <=0 or v.status == mConf.ROLE_STATUS.DEAD then
                    role.status = mConf.ROLE_STATUS.DEAD
                end
            end
        end
    end
    pve.bf = bf
end
function swapPostion(pve,roleA,roleB)
    local i1,i2 = roleA,roleB
    local r1,r2
    local b1,b2
    for i,v in pairs(pve.selfTeam) do
        if i  == i1 then
            r1 = v
            b1 = pve.bf.team1.roleMap[i]
        end
        if i == i2 then
            r2 = v
            b2 = pve.bf.team1.roleMap[i]
        end
    end
    pve.selfTeam[i1] = r2
    pve.selfTeam[i2] = r1
    pve.bf.team1.roleMap[i1] = b2
    pve.bf.team1.roleMap[i2] = b1
    if b1 ~= nil then
        b1.viewPos = i2
    end
    if b2 ~= nil then
        b2.viewPos = i1
    end

end
function initPveGlassBf(pve,badgeList)
    local bf = mBattle.initbf(1)
    bf.specialEffect = pve.specialEffect
    bf.battlePlayListFile = pve.battlePlayListFile 
    bfUnId = bfUnId + 1
    bf.id = bfUnId
    bf.canSkill = false

    bf.team1 = mBattle.initTeam(1)
    bf.team2 = mBattle.initTeam(2)
    bf.team1.fans = pve.fans
    bf.team2.fans = 0
    bf.autoFlag = pve.autoFlag 
    for i=1,4 do
        local v = pve.selfTeam[i]
        if v ~= nil then
            local role = mRole.initRole(v.id,1,mConf.ROLE_STATUS.STAND,v,i)
            bf.team1.roleMap[i] = role
        end
    end
    for i,v in pairs(badgeList) do
        local badgeExp = math.ceil(gamedata['badgeExp'][v.badgeLv].exp * (1+gamedata['badge'][v.badgeId].expchange/10))
        local roleExp = gamedata['roleExp'][v.roleLv].exp
        local role = mRole.initRole(pve.roleMaxId,2,mConf.ROLE_STATUS.STAND,
            {
            tid=v.roleId,charmExp=0,exp=roleExp,dear=0,
            badge={tid=v.badgeId,exp=badgeExp,breakTime=0},
            autoFlag = true,
            },i)
        pve.roleMaxId = pve.roleMaxId  + 1
        bf.team2.roleMap[i] = role
    end
    -- 获得所有人的hpMax

    mBattle.startBattle(bf)
    for i,role in pairs(bf.team1.roleMap) do
        for ii,v in pairs(pve.selfTeam) do
            if v.id == role.id then
                v.hpMax = mNum.getHpMax(bf,role)
                mNum.reduceHp(bf,role,v.hpMax - v.hp)
                role.power = v.power

                if v.status == mConf.ROLE_STATUS.DEAD then
                    role.status = v.status
                end
            end
        end
    end
    --printTable(bf.team2.roleMap)
    pve.bf = bf
    return bf   

end
function initPveBf(pve,monsterList,lvAdd,type)
    local bf = mBattle.initbf(type)
    bf.specialEffect = pve.specialEffect
    bf.battlePlayListFile = pve.battlePlayListFile 
    pve.battleId = pve.battleId + 1
    bf.id = pve.battleId
    bf.canSkill = false

    bf.team1 = mBattle.initTeam(1)
    bf.team2 = mBattle.initTeam(2)
    bf.team1.fans = pve.fans
    bf.team2.fans = 0
    bf.autoFlag = pve.autoFlag 
   for i=1,4 do
        local v = pve.selfTeam[i]
        if v ~= nil then
            local role = mRole.initRole(v.id,1,mConf.ROLE_STATUS.STAND,v,i)
            bf.team1.roleMap[i] = role
        end
    end
    for i,v in pairs(monsterList) do
        local role = mRole.initMonster(pve.roleMaxId,2,mConf.ROLE_STATUS.STAND,v.tid, math.floor(v.lv*lvAdd),math.floor(v.lv2*lvAdd),i,v.limitGod)
        pve.roleMaxId = pve.roleMaxId  + 1
        bf.team2.roleMap[i] = role
    end
    -- 获得所有人的hpMax

    mBattle.startBattle(bf)
    for i,role in pairs(bf.team1.roleMap) do
        for ii,v in pairs(pve.selfTeam) do
            if v.id == role.id then
                v.hpMax = mNum.getHpMax(bf,role)
                mNum.reduceHp(bf,role,v.hpMax - v.hp)
                role.power = v.power

                role.owner = v.owner

                if v.status == mConf.ROLE_STATUS.DEAD then
                    role.status = v.status
                end
            end
        end
    end
    --printTable(bf.team2.roleMap)
    pve.bf = bf
    return bf
end
function afterBattle(pve,bf)
    -- 设置自己队伍各个玩家的血量和状态
    for i,role in pairs(bf.team1.roleMap) do
        for ii,v in pairs(pve.selfTeam) do
            if v.id == role.id then
                v.hp = mNum.getBattleHp(bf,role)
                v.power = role.power
                v.status = role.status
            end
        end
    end
    printTable(pve.result)
    print(bf.gold)
    pve.result.gold = pve.result.gold + bf.drop.gold
    pve.result.exp = pve.result.exp + bf.drop.exp
    --pve.result.exp  = 0
    for i,v in pairs(bf.drop.item) do
        table.insert(pve.result.item,v)
    end
    if bf.drop.fragmentDrop then
        table.insert(pve.result.fragment,bf.drop.fragmentDrop)
    end
    bf.drop.exp = 0
    bf.drop.gold = 0
    bf.drop.item = {}
end
function getNextPveLottory(pve,first)
    if pve.canLottery == false then
        return false
    end
    local firstLottery = false
    if pve.firstLottery then
        pve.firstLottery = false
        pve.lotteryRefCnt = mConf.ReLotteryCnt
        pve.newLottery = false
        lotteryFirst = true
    else
        pve.lotteryRefCnt  = pve.lotteryRefCnt *2
        lotteryFirst = false
    end
    local boss = false
    local bossId= 0
    for i=1,#pve.bossList do
        if pve.processCnt >= pve.bossList[i].time - 1  and
            pve.bossList[i].used ~= true then
            boss = true
            bossId = i
            break
        end
    end
    pve.lottery = mLottery.getPVELottery(boss,bossId,first)
    pve.lottery.lotteryRefCnt = pve.lotteryRefCnt
    pve.lottery.first = lotteryFirst
    mView.playLottery(pve.bf,pve.lottery)
    mView.waitForLottery(pve.bf)
    mView.pve_result(pve.bf)
    return true
end
function startPreLottery(pve)
    local flag = false
    for i=1,#pve.bossList do
        if pve.processCnt >= pve.bossList[i].time - 1  and
            pve.bossList[i].used ~= true then
            flag = true
            break
        end
    end
    mView.startPreLottery(pve.bf,flag)
end
function cancelBattle(pve)
    endPveCallBack(pve)
end

function pveEnd(pve,result)
    if result == true then
        mView.pveOK(pve.bf)
        pve.succes = 1
    else
        mView.pveFailed(pve.bf)
        pve.succes= 2
    end
end
function endPveBattle(pve)
    print ("#endPveBattle")

    afterBattle(pve,pve.bf)
    mView.changeLottery(pve.bf,mConf.LotteryType.PVE)
    
    
    if pve.process >= 100 then
        pveEnd(pve,true)
    else
        --mView.updatePvePrecent(pve.bf,pve.processCnt-1,pve.processCnt,pve.processTotal)
        if  pve.bf.status == "victory"  then
            eventEnd(pve)
        else
            pveEnd(pve,false)
        end
    end
    pve.bf.double =false

    --mView.removeDouble(pve.bf)
    --mView.canDouble(pve.bf)
    return false
end
function eventEnd(pve)
    if pve.process >= 100 then
        pveEnd(pve,true)
    else
        mView.updatePvePrecent(pve.bf,pve.processCnt-1,pve.processCnt,pve.processTotal)
    end
    startPreLottery(pve)
    mView.startUserPveLottery(pve.bf)
    pve.canLottery = true
    pve.firstLottery = true
end
function eventResult(pve)
    pve.canLottery = false
    local lottery = pve.lottery
    printTable(lottery.normal)
    local sameCnt = lottery.sameCnt
    pve.process = pve.process + pve.processAdd
    pve.processCnt = pve.processCnt + 1

    if  pve.processCnt == pve.processTotal then
       pve.process = 100
    end

    mView.addLog(pve.bf,"摇到了老虎机："..
        mConf.laohujiIconPve[lottery.normal[1]].name..":"..
        mConf.laohujiIconPve[lottery.normal[2]].name..":"..
        mConf.laohujiIconPve[lottery.normal[3]].name,2)
    
    if lottery.boss == true then
        local oldbf = pve.bf
        local i = lottery.bossid
        pve.bossList[i].used = true
        lottery.normal = {mConf.PVE_RES.SOWARD,mConf.PVE_RES.SOWARD,mConf.PVE_RES.SOWARD}
        if pve.process == 100 then
            mView.bossComming(pve.bf)
        end
        initPveBf(pve,pve.bossList[i].monsterList,1)

        mView.startBattle(pve.bf)
        mView.changeLottery(oldbf,mConf.LotteryType.Battle)
        --printTable(pve.bf)

        mView.battleEndCallBack(oldbf,endPveBattle,pve)
        mView.startNewBattle(oldbf,pve.bf,true)
        
        mView.startUserBattleLottery(pve.bf)
        mView.openGuide(pve.bf,guideEvent.startPveBattle)

    else
        lottery.event = lottery.normal[1]
        lottery.sameCnt = sameCnt
        pve.curEvent = lottery.event
        if lottery.event == mConf.PVE_RES.SOWARD then
            local oldbf = pve.bf
            local levenAdd = 1 + (lottery.sameCnt -1)*0.2
            local monsterList = {}
            local monsterListCnt =  mRandom.getRandom(pve.selfTeamCnt-1,pve.selfTeamCnt+1)
            if monsterListCnt > 4 then
                monsterListCnt = 4
            end
            if monsterListCnt == 0 then
                monsterListCnt = 1
            end
            --monsterListCnt = 4
            for i=1,monsterListCnt do
                local random = mRandom.getRandom(1,pve.monsterListCnt) 
                --print (random,pve.monsterList[random])
                table.insert(monsterList,pve.monsterList[random])
            end
            --printTable(monsterList)
            initPveBf(pve,monsterList,levenAdd)
            pve.next = 2
            mView.startBattle(pve.bf)
            mView.changeLottery(oldbf,mConf.LotteryType.Battle)
            mView.battleEndCallBack(oldbf,endPveBattle,pve)
            mView.startNewBattle(oldbf,pve.bf,true)
            
            mView.startUserBattleLottery(pve.bf)
            mView.openGuide(pve.bf,guideEvent.startPveBattle)
        elseif lottery.event == mConf.PVE_RES.DRUG then
            --initSelfTeamHp(pve)
            local hpPerArr = {0.25,0.5,1}
            local hp = hpPerArr[sameCnt]
            mView.drug(pve.bf)
            for i,v in pairs(pve.selfTeam) do
                if v.hp >=0 then
                    local old = v.hp/v.hpMax
                    v.hp = v.hp + math.floor(hp * v.hp)
                    if v.hp > v.hpMax then
                        v.hp = v.hpMax
                    end
                    local role = nil
                    for ii,vv in pairs(pve.bf.team1.roleMap) do
                        if vv.id == v.id then
                            role = vv
                            break
                        end
                    end

                    mNum.reduceHp(pve.bf,role,-math.floor(hp * v.hp))
                    mView.redeceHpCmd(pve.bf,v.id,-math.floor(hp * v.hp),old,v.hp/v.hpMax)
                end
            end
            mView.playEffect(pve.bf,"effect_01")
            eventEnd(pve)
        elseif lottery.event == mConf.PVE_RES.GOLD then
            local itemUse = {}
            for i,v in pairs(gamedata['randomGift']) do
                if v.groupId == pve.tmp.giftList and v.start == sameCnt then
                    table.insert(itemUse,v)
                end  
            end
            local max = 0
            for i,v in pairs(itemUse) do
                max = max + 20
            end
            local item = itemUse[1]
            local r = mRandom.getRandom(0,max)
            for i,v in pairs(itemUse) do
                r = r - 20 
                if r <= 0 then
                     item =v 
                     break
                end
            end
            mView.addLog(pve.bf,"获得了礼物 "..item.name,3)
            table.insert(pve.result.giftList,{id=item.itemId,num=item.num})

            mView.dropItem(pve.bf)
            mView.nextActionDelay(pve.bf,1)
            mView.collectItem(pve.bf)
            mView.nextActionDelay(pve.bf,2)
            eventEnd(pve)
          
            
        elseif lottery.event == mConf.PVE_RES.GLASS then

            local random = mRandom.getRandom(1,20)
            local cnt  = 0
            local event = nil
            if pve.eventCnt > 0 then
                local flag = true
                for i,v in pairs(pve.event) do
                    local ev = gamedata['event'][v]
                    if ev.star == sameCnt then
                        flag = false
                    end
                end
                while true do
                    for i,v in pairs(pve.event) do
                        local ev = gamedata['event'][v]
                        if flag or ev.star == sameCnt then
                            cnt = cnt + 1
                            if random == cnt then
                                event = ev
                                break
                            end
                        end
                    end
                    if event then
                        break
                    end
                end
            end
           -- printTable(event)

            local scene = package.loaded['battle.scene']
            if scene then           
                scene.loadAllAnim({event.badgeId})
            end
            pve.GlassEvent = event
            mView.openGuide(pve.bf,guideEvent.startPveAdventure)
            mView.startEvent(pve.bf,event)
            
            initPveGlassBf(pve,{{badgeId = event.badgeId,roleId=event.roleId,badgeLv = event.lv1,roleLv =event.lv2}})

            --initPveBf(pve,{{tid=event.monsterId,lv=1,lv2=1}},1)
        end
    end
    pve.newLottery = true
    pve.double = false
    --mView.removeDouble(pve.bf)

end

--[[
A选项触发的事件
填写格式为事件类型;参数
类型1=游戏币 参数=数量有-号表示减少
类型2=钻石 参数=数量有-号表示减少
类型3=对应badgeID的本源碎片 参数=碎片个数
类型4=触发战斗 参数=等级（等级对应神使和幻神）
不填则无任何事件，多个事件间以|号隔开
]]
function select(pve,option)
    local event =  pve.GlassEvent
    local result = nil
    local answer = nil
    local bf = pve.bf
    if option == 1 then
        result = event.eventA
        answer = event.answerA
        mView.addLog(bf,"选择了A",1)
    elseif option == 2 then
        result = event.eventB
        answer = event.answerB
        mView.addLog(bf,"选择了B",1)
    end
   
    local type,num
    local hasBattle = false
    local drop = false
    local battleLv = 1
    if result ~= nil and result ~= "" then
        local eventList = splitWithTrim(result,"|")
        for _,e in pairs(eventList) do
            local ss = splitWithTrim(e, ";")
            local type,num = tonumber(ss[1]),tonumber(ss[2])
            --print("#################",result,type,num)
            if type == 1 then
                if num < 0 then
                    if pve.gold < -num then
                        -- 金币不足
                        mView.needMoreGold(pve.bf)
                        return
                    else
                        pve.result.restartGold = pve.result.restartGold - num
                    end
                else
                    --mView.addGold(pve.bf,num)
                    pve.result.gold = pve.result.gold + num
                end
                mView.addLog(bf,"选项触发了金币变化 "..num,3)
                pve.gold = pve.gold + num
            elseif type == 2 then
                if num < 0 then
                    if  userdata.UserInfo.diamonds < -num then
                        mView.needMoreDiamonds(pve.bf)
                        return 
                    else
                        userdata.UserInfo.diamonds = userdata.UserInfo.diamonds + num
                        pve.result.resultDiamonds = pve.result.resultDiamonds - num
                    end
                end
                mView.addLog(bf,"选项触发了钻石变化 "..num,3)
                pve.diamonds = pve.diamonds + num
                --mView.addCyl(pve.bf,num)
            elseif type == 3 then
                mView.addLog(bf,"选项触发了获得"..num.."个"..gamedata['badge'][event.badgeId].name.."碎片",3)
                table.insert(pve.result.fragment,{tid=event.badgeId,num=num})
                drop  = true
            elseif type == 4 then
                hasBattle = true
                battleLv = num
            end
        end
    end
    mView.answerView(pve.bf,answer)
    if result ~= nil and result ~= "" then
        local eventList = splitWithTrim(result,"|")
        for _,event in pairs(eventList) do
            local ss = splitWithTrim(event, ";")
            local type,num = tonumber(ss[1]),tonumber(ss[2])
            if type == 1 then
                if num > 0 then
                    
                    mView.addGold(pve.bf,num)
                end
            elseif type == 2 then
                
                mView.addCyl(pve.bf,num)
            elseif type == 3 then

            elseif type == 4 then

            end
        end
    end
    if hasBattle then
        mView.addLog(bf,"选项触发了战斗",3)
        local badgeExp = math.ceil(gamedata['badgeExp'][battleLv].exp * (1+gamedata['badge'][event.badgeId].expchange/10))
        local roleExp = gamedata['roleExp'][battleLv].exp        
        for _,v in pairs(pve.bf.team2.roleMap) do
            v.fragmentDrop = {tid=event.badgeId,num=event.fragmentDrop}
            mRole.updateLv(pve.bf,v,badgeExp,roleExp)
        end      

        mView.onSelectEnd(pve.bf,hasBattle,drop)
        mView.startBattle(pve.bf)
        mView.changeLottery(pve.bf,mConf.LotteryType.Battle)
        mView.startPreLottery(pve.bf,false)
        mView.battleEndCallBack(pve.bf,endPveBattle,pve)
        mView.startUserBattleLottery(pve.bf)
    else
        if drop then
            local roleid = 0
            for _,v in pairs(pve.bf.team2.roleMap) do
                roleid = v.id
            end
            mView.dropItem(pve.bf,roleid)
        end
        mView.onSelectEnd(pve.bf,hasBattle,drop)
        mView.nextActionDelay(pve.bf,0.2)
        mView.collectItem(pve.bf)    
        eventEnd(pve)
    end
end
function findFriend()
    local random = mRandom.getRandom(1,100)
    if random <=20 then
        return true
    end
    return true;
end
