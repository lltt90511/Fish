local math,table,tonumber,pairs,print,printTable=math,table,tonumber,pairs,print,printTable
local mGameData = require ("template.gamedata")
local mConf = require ("battle.conf")
module("battle.select",package.seeall)

local gamedata = mGameData.data
function getAttackTarget(bf,self)
	local tarRoleList={}
	local tarTeam=oppositeTeam(bf,self)
	local selfTeam = selfTeam(bf,self)
	local attackTarget = selfTeam.attackTarget
	--printTable(tarTeam)
	if attackTarget ~= nil and attackTarget>0 and tarTeam.roleMap[attackTarget].status ~= mConf.ROLE_STATUS.PREDEAD and 
		tarTeam.roleMap[attackTarget].status ~= mConf.ROLE_STATUS.DEAD then
		--table.insert(tarRoleList,tarTeam.roleMap[attackTarget])	
		return	tarTeam.roleMap[attackTarget]
	else	
		--�Ƿ�������Կ���
		local target=getTarRestrain(tarTeam,self)
		--return target
		if target==-1 then
			target=getLeaderTarget(bf,selfTeam)
		end
		return tarTeam.roleMap[target]	
	end

	return nil
end

function getLeader(bf,team)
	local leader=team.roleMap[team.teamLeaderId]
	--printTable(leader)
	--print (team.teamLeaderId)

	if leader == nil then
		for i,v in pairs(team.roleMap) do
			team.teamLeaderId = i
			return v
		end
	end
	return leader
end
function getLeaderTarget(bf,team)
	local leader=getLeader(bf,team)
	local tarTeam=oppositeTeam(bf,team)
	local target=-1
	if leader~=nil then
		target=getTarRestrain(tarTeam,leader)
	end	
	
	if target==-1 then
		target=getFirstAliveRole(tarTeam)
	end
	return target
end
	
function getTarRestrain(team,self)
	for i,role in pairs(team.roleMap) do
		--local role=team.roleMap[i]
		if role.status ~=mConf.ROLE_STATUS.DEAD and role.viewPos == self.viewPos then
			if i == 4 then
				if team.roleMap[1].status ~=mConf.ROLE_STATUS.DEAD then
					return 1
				end
			end
			return i
		end	
	end	
	return -1
end

function getFirstAliveRole(team)
	for i,role in pairs(team.roleMap) do
		--local role=team.roleMap[i]
		if role.status~=mConf.ROLE_STATUS.DEAD  then
			return i
		end	
	end
	return -1	
end

function selfTeam(bf,self)
	if self.teamId == 1 then
		return bf.team1
	else
		return bf.team2
	end
end
function selfTeamAlive(bf,self)
	local oppoTeam = selfTeam(bf,self)
	local team = {}
	for i,v in pairs(oppoTeam.roleMap) do
		if v.status ~= mConf.ROLE_STATUS.PREDEAD and 
			v.status ~= mConf.ROLE_STATUS.DEAD then
			table.insert(team,v)
		end
	end
	return team
end
function oppositeTeamAlive(bf,self)
	local oppoTeam = oppositeTeam(bf,self)
	local team = {}
	for i,v in pairs(oppoTeam.roleMap) do
		if v.status ~= mConf.ROLE_STATUS.PREDEAD and 
			v.status ~= mConf.ROLE_STATUS.DEAD then
			table.insert(team,v)
		end
	end
	return team
end
function oppositeTeam(bf,self)
	if self.teamId == 1 then
		return bf.team2
	else
		return bf.team1
	end	
end

function selRoleById(bf,self,id) 
	local selfTeam=selfTeam(bf,self)
	local tarTeam=oppositeTeam(bf,self)
	for k,v in pairs(selfTeam.roleMap) do
		if v.id==id	then
			return v
		end
	end
	for k,v in pairs(tarTeam.roleMap) do
		if v.id==id	then
			return v
		end
	end	
	return nil
end

