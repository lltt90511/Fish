local mConf=require("battle.conf")
local mRandom = require("battle.random")
local mAction = require("battle.action")
local mNum = require("battle.numerial")
local mGameData = require ("template.gamedata")
local mView=require("battle.view")
local gamedata = mGameData.data
module("battle.buff",package.seeall)

function checkHasBuff(bf,role,propName)
	for k,v in pairs(role.buff) do
		local  tpl=v.buff
		if tpl.propName==propName then
			return tpl.id
		end
	end
	return -1
end
--回合开始的时候检查buff有效期
function checkBuff(bf,role)
	local removeBuffTab = {}
	for i,v in pairs(role.buff) do
		if not mAction.checkDead(bf,role) then
			local tpl = v.buff
			if tpl.propName=="restore" then
				mAction.reduceHpCmd(bf,role,nil,-v.from.badgeBean.satk *(1+v.from.atk/10000)*0.3*tpl.propNum)
				mView.buffEffect(bf,role.id,tpl)

			end
			if tpl.propName=="restoreR" then
				mAction.reduceHpCmd(bf,role,nil,-math.floor(mNum.getHpMax(bf,role)*tpl.propNum/100))
				mView.buffEffect(bf,role.id,tpl)
			end
			if tpl.propName=="bleed" then
				mAction.reduceHpCmd(bf,role,nil,v.from.badgeBean.satk *(1+v.from.atk/10000)*tpl.propNum/100)
				mView.buffEffect(bf,role.id,tpl)
				mView.beHurtCmd(bf,role.id,nil,bf.time,role.hurtTime,attacker.hurtSound)	
				if mAction.checkDead(bf,role) then
					dead(bf,role)
				end				
			end
			if tpl.propName=="bleedR" then
				mAction.reduceHpCmd(bf,role,nil,mNum.getBattleHp(bf,role)*tpl.propNum/100)	
				mView.buffEffect(bf,role.id,tpl)
				mView.beHurtCmd(bf,role.id,nil,bf.time,role.hurtTime,attacker.hurtSound)
				if mAction.checkDead(bf,role) then
					dead(bf,role)
				end							
			end
			if role.status==mConf.ROLE_STATUS.DEAD then
				break
			end
			if v.buff.round > 0 then
				local remove = v.buff.round+v.startRound 
				-- 最后一回合
				if remove <= bf.roundNum then
					table.insert(removeBuffTab,i)
				end
			end
		end
	end
	--print ("start Remove Buff")
	for i,v in pairs(removeBuffTab) do
		removeBuff(bf,role,v)
	end
end
function removeBuff(bf,role,num)
	local tpl = role.buff[num].buff
	role.buff[num] = nil
	mView.removeBuff(bf,role.id,tpl)
	-- 调整hp的话。。。
	if tpl.propName == "hp_upR" then
		mAction.reduceHpCmd(bf,role,nil,0,true)
	elseif tpl.propName == "hp_downR" then
		mAction.reduceHpCmd(bf,role,nil,0,true)
	elseif tpl.propName == "frozen" then
		role.factions = role.initFactions
	elseif tpl.propName == "petrifaction" then
		role.factions = role.initFactions
	elseif tpl.propName == "restriction" then
		role.factions = role.initFactions
	end
end
-- role 释放一个buff
-- target 对于群放可以为空
function addBuff(bf,buffid,role,target,rate)
	local buff = gamedata["buff"][buffid]
	local tpl =buff
	--叠加形式 1同类型可叠加 2同类型高级替代 3无法叠加
	local type = buff.type
	local bf2 = checkHasBuff(bf,target,"resistance")
	if buff.variety == 2 and bf2 >0 then
		local random = mRandom.getRandom(1,100)
		if random < rate - gamedata["buff"][bf2].propNum then
			mView.buffEffect(bf,target.id,gamedata["buff"][bf2])
			return 
		end
	else
		local random = mRandom.getRandom(1,100)
		if random > rate then
			return 
		end
	end

	if type == 1 then

	elseif type == 2 then
		for i,v in pairs(target.buff) do
			if v.buff.Group == buff.Group  then
				if  v.buff.level >= buff.level then
					return 
				else
					removeBuff(bf,target,i)
					break
				end
			end
		end
	elseif type ==3 then
		for i,v in pairs(target.buff) do
			if v.buff.Group == buff.Group  then
				removeBuff(bf,target,i)
				break
			end
		end		
	end
	table.insert(target.buff,{buff=buff,startRound = bf.roundNum,from=role})
	mView.addBuff(bf,target.id,buff)
	-- 调整 hp的话。。。。
	if tpl.propName == "hp_upR" then
		mAction.reduceHpCmd(bf,role,nil,-mNum.getHpMax(bf,role)*buff.propNum/100,true)
	elseif tpl.propName == "hp_downR" then
		mAction.reduceHpCmd(bf,role,nil,0,true)
	elseif tpl.propName == "frozen" then
		role.factions = mConf.NATURE.wind
	elseif tpl.propName == "petrifaction" then
		role.factions = mConf.NATURE.wood
	elseif tpl.propName == "restriction" then
		role.factions = mConf.NATURE.fire
	end

end
function hasStopBuff(bf,role)
	for i,v in pairs(role.buff) do
		local tpl=v.buff
		if tpl.propName=="frozen" or tpl.propName=="petrifaction" or tpl.propName=="restriction" then
			return true
		end
	end		
end
function clear(bf,role)
	local removeBuff = {}
	for i,v in pairs(role.buff) do
		local tpl=v.buff
		if tpl.variety == 2 then
			removeBuff.insert(removeBuff,i)
		end
	end	
	for i,v in pairs(removeBuff) do
		removeBuff(bf,role,v)
	end
end

function clearX(bf,role)
	local removeBuff = {}
	for i,v in pairs(role.buff) do
		local tpl=v.buff
		if tpl.variety == 1 then
			removeBuff.insert(removeBuff,i)
		end
	end	
	for i,v in pairs(removeBuff) do
		removeBuff(bf,role,v)
	end
end