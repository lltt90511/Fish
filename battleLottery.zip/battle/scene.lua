local printTable,math,coroutine = printTable,math,coroutine
local oldPerformWithDelay = performWithDelay
local release = release
local view = require("battle.view")
--local server= require ("battle.server")
local tool = require("scene.tool")
local battle = require ("battle.battle")
local conf = require("battle.conf")
local mConf = conf
local mGameData = require ("template.gamedata")
local mPve = require("battle.pve")
local gamedata = mGameData.data
local mNum = require("battle.numerial")
local effect = require("battle.effect")
local alert = require("scene.alert")
local event = require"logic.event"
local countLv = require"logic.countLv"
local lottery = require "battle.lotteryView"
local guide = require "guide.core"
local userdata =require "logic.userdata"
local openFunction = require"guide.openFunction"
local scrollList = require "widget.scrollListV2"
local buyDiamond = require "scene.buyDiamond"
module("battle.scene", package.seeall)

--lottery 函数

this = nil
speedInit = {1.5,2,4}
speed = speedInit[1]
disconnect = false
performWithDelayBattle = function (func,time)
    if time  == nil or time < 0 then
        time = 0
    end
    if speed == 0  then
        time =0
    else
        time = time /speed
    end
    --print ("performWithDelayBattle",time)
    return tool.createEffect(tool.Effect.delay,{time=time},this,func,true,false)
end
createEffect = function(e,param,obj,callBack,preAction,anim)
     if param.time then
        if speed == 0  then
            param.time =0
        else
            param.time = param.time /speed
        end
    end
     tool.createEffect(e,param,obj,callBack,preAction,anim)
end
createGroupEffect = function(obj,actionList,callBack,preAction,anim)
    for i,v in pairs(actionList) do
        local param = v[2]
        if speed == 0  then
            param.time =0
        else
            param.time = param.time /speed
        end
    end
    tool.createGroupEffect(obj,actionList,callBack,preAction,anim)
end
bezier = function(obj,start,xend,time,func,control)
    if speed == 0  then
        time =0
    else
        time = time /speed
    end
    tool.bezier(obj,start,xend,time,func,control)
end
createEnterEffect = function(obj,diffpos,time,callback,anim)
    if speed == 0  then
        time =0
    else
        time = time /speed
    end
    tool.createEnterEffect(obj,diffpos,time,callback,anim)
end
createExitEffect = function(obj,diffpos,time,recovery,callback)
    if speed == 0  then
        time =0
    else
        time = time /speed
    end
    tool.createExitEffect(obj,diffpos,time,recovery,callback)
end
bf = nil
pve = nil

spaceInfo = {
    [1] = {side = false,name= "11",z=30},
    [2] = {side = false, name= "12",z=40 },
    [3] = {side = false, name= "13" ,z=10},
    [4] = {side = false, name= "14" ,z=20},
    [5] = {side = false, name= "15" ,z=20},
   [11] = { side = true, name= "1",z=30},
   [12] = { side = true, name= "2" ,z=40},
   [13] = { side = true, name= "3" ,z=10},
   [14] = { side = true,name= "4" ,z=20},
   [15] = { side = true,name= "5" ,z=20},
}
--roleParent = nil
Role = {}

RoleIcon = {}

delayPlayHandler = nil --delay的handler对于技能可以取消上一次
goldCnt = 0
doubleFlag = false -- 老虎机double 按钮状态！ 重要

animList = {}

function loadAllAnim(list)
    for i,v in pairs(list) do
        local tmp = gamedata['anim'][gamedata['badge'][v].animId]
        if tmp  then
            tool.loadAnim(tmp.name,tmp.pngNum)
            animList[tmp.name]= tmp.pngNum
        end
        if gamedata['badge'][v].hurtAnimId > 0 then
            local tmp = gamedata['anim'][gamedata['badge'][v].hurtAnimId]
            if tmp  then
                tool.loadAnim(tmp.name,tmp.pngNum)
                animList[tmp.name]= tmp.pngNum
                if tmp.Sound ~= "" then
                    AudioEngine.preloadEffect(tmp.Sound)
                end
            end
        end
        if gamedata['badge'][v].skillHurtAnimId > 0 then
            local tmp = gamedata['anim'][gamedata['badge'][v].skillHurtAnimId]
            if tmp  then
                tool.loadAnim(tmp.name,tmp.pngNum)
                animList[tmp.name]= tmp.pngNum
                if tmp.Sound ~= "" then
                    AudioEngine.preloadEffect(tmp.Sound)
                end
            end
        end

    end
end

function loadAllAnimSuper(list,func)
    local anim = {}
    for i,v in pairs(list) do
        if v.type == 1 then
            anim[gamedata['badge'][v.id].animId]=true
            anim[gamedata['badge'][v.id].skillHurtAnimId]=true
            anim[gamedata['badge'][v.id].hurtAnimId]=true

        elseif v.type == 2 then
            printTable(v)
            anim[tonumber(gamedata['battleMonster'][v.id].hrtanimid)]=true
            anim[tonumber(gamedata['battleMonster'][v.id].skillhurtanimid)]=true            
        end
    end 

    local count = 0
    local loadEnd = function ()
        print ("finish Loading",count)
        count = count - 1
        if count ==0 then
            func()
        end
    end
    
    for i,v in pairs(anim) do
         local tmp = gamedata['anim'][i]
         if tmp then
            count = count + 1
            tool.loadAnimAsync(tmp.name,tmp.pngNum,loadEnd)
            animList[tmp.name]= tmp.pngNum
            if tmp.Sound ~= "" then
                AudioEngine.preloadEffect(tmp.Sound)
            end
        end
    end
    local perAnim = {
        {name="gold",pngNum=1},
        {name="exp",pngNum=1},
        {name="skillEffect",pngNum=2},
        {name="skillfull",pngNum=1},
        {name="summon_anim_001",pngNum=2},
        {name="skillfull2",pngNum=1},
        {name="runtoscene01",pngNum=1},
        {name="eventCnter",pngNum=1},  
    }
    for i,v in pairs(perAnim) do
        if animList[v.name] == nil then
            animList[v.name] = v.pngNum 
            tool.loadAnimAsync(v.name,v.pngNum,loadEnd)
            count = count + 1
        end
    end
    if count == 0 then
        func()
    end
end
nowStoped = false
function create()
    --load 所有动画
    --loadAllAnim()
    --
    nowStoped = false
    CCDirector:sharedDirector():setAnimationInterval(1.0 / 50);
    animStoped = false
    disconnect = false
    for i=1,9 do
        AudioEngine.preloadEffect("effect_0"..i)
    end
    for i=10,21 do
        AudioEngine.preloadEffect("effect_"..i)
    end
    stoped  = false
    --load主界面
   
   -- if pve ~= nil or bf.type ~=2 then
        this = tool.loadWidget("nshx/battlePve",widget)
    --else
    --    this = tool.loadWidget("nshx/battle",widget)
    --end
    local oopp = tool.getPosition(widget.role_icon_tmp_super.info.obj)
    local oosize = widget.role_icon_tmp_super.info.obj:getSize()
    widget.role_icon_tmp_super.info.obj:setAnchorPoint(ccp(0.5,0.5))
    tool.setPosition(widget.role_icon_tmp_super.info.obj,oopp,{x=oosize.width/2,y=oosize.height/2})
     for i,v in pairs(spaceInfo) do
        local wid = widget.battle_scene["role_"..v.name].obj
        local pos = tool.getPosition(wid)

        v.pos = pos
    end

    widget.quest.obj:setVisible(false)
    local bossSize = widget.boss.obj:getSize();
    widget.boss.obj:setSize(CCSize(bossSize.width,bossSize.height+Screen.height-960))
    widget.boss.obj:setVisible(false)
    -- 设置重摇初始值
    widget.info.refresh_num.obj:setText(""..mConf.ReLotteryCnt )
    --初始化老虎机icon的位置 并且记录基础信息
    --openFunction.checkAndShowFunction(openFunction.EVENT.AUTO_FIGHT,widget.auto_btn.obj)
    --初始化effect模块
    effect.this = this
    effect.widget = widget
    effect.startPlay = startPlay
    --初始化按钮
    widget.control.refresh_btn.obj:setVisible(false)
    widget.control.refresh_btn.obj:setTouchEnabled(false)
    --重设事件的位置
    widget.a_btn.obj:setTouchEnabled(false)
    widget.b_btn.obj:setTouchEnabled(false)
    widget.battle_scene.combos.obj:setVisible(false)

    widget.text_bg.obj:setVisible(false)
    widget.a_btn.obj:setVisible(false)
    widget.b_btn.obj:setVisible(false)
      
    --转场图片高度
    widget.zhuanchang.obj:setScaleY((Screen.height-250+20)/464)
    --隐藏怪物属性
    widget.oppo.obj:setVisible(false) 

    --重设战斗场景的位置 适应屏幕分辨率
    --初始化地图
    
    local pos = tool.getPosition(widget.battle_scene.obj)
    tool.setPosition(widget.battle_scene.obj,{align = pos.align,left = 0,right = 0,top=(Screen.height-1136)/2,bottom=0,type =LAYOUT_RELATIVE})

    -- 把人物的位置默认隐藏
    for i=1,5 do
        widget.battle_scene["role_"..i].obj:setVisible(false)
        widget.battle_scene["role_"..(i+10)].obj:setVisible(false)
    end
    --重设定时器
    delayPlayHandler = nil
    --初始化失败面板
    local this2 = tool.loadWidget("nshx/lose_plane",widget2)
    this:addChild(this2,100000)
    widget2.lose_plane.obj:setPosition(ccp(Screen.width/2,Screen.height/2))
    hideLoseSelect(true)

    --初始化一些其他信息
    --effect.setGoldCnt(goldCnt)
    --setJewNum(pve.gold)
    --注册所有事件
    --初始化战斗模式

    lottery.initLotteryStatus()
    registerAll()
    if pve ~= nil then
        setForPVE()
    else
        if bf.type == 2 then
            setForPVP()
        elseif bf.type == 3 then
            setForNewGuide()
        end
    end
    --CCDirector:sharedDirector():getScheduler():setTimeScale(0.5);
    --performWithDelayBattle(function ()
        --TextEffect("这个特效超牛逼")
    --end,1)
    initLog()
    return  this
end
logView = nil
logList = nil
logPos = nil
function initLog()
    logView = scrollList.create(widget.log_view.list.obj,widget.log_view.loading_bg.loading.obj,widget.log_view.loading_bg.obj,widget.log_view.log_tmp.obj,{
         scroll = {rowNum = 1,emptySize={top= 0,bottom=0,left=-150},heightOffset =Screen.height-960},
         item = {size = {width=300,height=40}},
         func = {itemSetFunc=setLog},
      })
    logList = 0
    logPos = tool.getPosition(widget.log_view.obj)
    tool.setPosition(widget.log_view.obj,logPos,{x=-320,y=0})
    widget.log_view.obj:setVisible(false)
    if release then
          widget.showLog.obj:setVisible(false)
    end
end
function showLog(event)
    if event == "releaseUp" then
        logView.draw()
        tool.setPosition(widget.log_view.obj,logPos)
        widget.showLog.obj:setVisible(false)
        widget.showLog.obj:setTouchEnabled(false)
        widget.log_view.obj:setVisible(true)
    end
end
function hideLog(event)
    if event == "releaseUp" then
        logView.stopDraw()
        widget.showLog.obj:setVisible(true)
        widget.showLog.obj:setTouchEnabled(true)
        tool.setPosition(widget.log_view.obj,logPos,{x=-320,y=0})
        widget.log_view.obj:setVisible(false)
    end
end
function setLog(obj,info)
    local time = tool.findChild(obj,"time","Label")
    local log = tool.findChild(obj,"log","Label")
    time:setText(info.time)
    log:setText(info.log)
    if info.color == nil then
        log:setColor(ccc3(255,255,255))
    elseif info.color == 1 then
        log:setColor(ccc3(225,0,0))
    elseif info.color == 2 then
        log:setColor(ccc3(225,255,0))
    elseif info.color == 3 then
        log:setColor(ccc3(0,0,255))
    end
end
function addLog(action)
    if logList ~= nil then
        logList = logList + 1
        logView.addNewItem(logList,{time=action.time,log=action.log,color=action.color})
        logView.draw()
    end
end
function getRoleWorldPos(roleid)
    local  id = playerToPostion[roleid]
    local role = Role[id] 
    local info2 = spaceInfo[id]
    return info2.pos.x+widget.battle_scene.obj:getPositionX(),info2.pos.y+widget.battle_scene.obj:getPositionY()
end
function spliteText(str)
    local tb = {}
    i = 1
    while i < #str  do
       c = str:sub(i,i)
       ord = c:byte()
       if ord > 128 then
          table.insert(tb,str:sub(i,i+2))
          i = i+3
       else
          table.insert(tb,c)
          i=i+1
       end
    end
    return tb
end
function TextEffect(text,func)
    local str = spliteText(text)
    local len = #str
    local posy = Screen.height-200
    local center =  320 
    local width = 75
    local sWidth = 200
    local leftStart =0
    local sLeftStart = 0
    printTable(str)
    if len % 2== 0 then
        leftStart = center - (width/2 + len/2*width) 
        sLeftStart = center - (sWidth/2 + len/2*sWidth) 
    else
        leftStart = center - (len-1)/2 * width
        sLeftStart = center - (len-1)/2 * sWidth
    end
    local waitTime = 0.3
    local effectFadeIn = 0.3
    local afterFadeInTime = 0.1
    local effectFadeIn2 = 0.1
    local fadeOutDelay = 0.05
    local fadeOutTime = 0.1
    for i=1,len do
        local fromX = sLeftStart + (i-1)*sWidth
        local toX = leftStart +(i-1)*width
        local toX2 = 0
        if toX <= center then
            toX2 = -100
        else
            toX2 = 740
        end
        local y = posy
        local text = tolua.cast(Label:create(),"Label")
        text:setText(str[i])
        text:setFontSize(55)
        text:setFontName(DEFAULT_FONT)
        this:addChild(text)
        text:setPosition(ccp(fromX,y))
        text:setVisible(false)
        if   platform == "Windows"   then
            text:setColor(ccc3(26,26,26))
            local shadow = tolua.cast(text:clone(),"Label")
            shadow:setVisible(true)
            shadow:setColor(ccc3(255,255,255))
            text:addChild(shadow)
            shadow:setPosition(ccp( -1,1))
        else
            local font =  tolua.cast(text:getVirtualRenderer(),"CCLabelTTF")
            font:enableStroke(ccc3(0,0,0),4)
        end
        createEffect(tool.Effect.delay,{time=waitTime*(i-1)},text,function()
            text:setVisible(true)
            createEffect(tool.Effect.move,{x=toX,y=y,time=effectFadeIn},text)
            text:setOpacity(20)
            text:setScale(10)
            createEffect(tool.Effect.delay,{time=effectFadeIn/2},text,function()

            end,true)
            createEffect(tool.Effect.fadeIn,{time=effectFadeIn},text,nil,true)
            createEffect(tool.Effect.scale,{time=effectFadeIn,scale=1.5},text,function()
                local clone = text:clone()
                clone:setOpacity(128)
                this:addChild(clone)
                createEffect(tool.Effect.fadeOut,{time=effectFadeIn/2},clone)
                createEffect(tool.Effect.scale,{time=effectFadeIn/2,scale=3},clone,function()
                    clone:removeFromParentAndCleanup(true)
                 end,true)
                createEffect(tool.Effect.scale,{time=effectFadeIn2,scale=1},text,function()
                    createEffect(tool.Effect.delay,{time=waitTime*(len-(i-1))+afterFadeInTime+fadeOutDelay*(i-1)},text,function()
                        text:stopAllActions()
                        text:setScale(1)
                        text:setOpacity(255)
                        text:setPosition(ccp(toX,y))
                        createEffect(tool.Effect.fadeOut,{time=fadeOutTime},text)
                        createEffect(tool.Effect.scale,{time=fadeOutTime,scale = 2},text,function()
                            text:removeFromParentAndCleanup(true)
                            if func then
                                local call = func
                                func = nil
                                call()
                            end
                        end,true)
                    end,true)
                end,true)
            end,true)

        end)
    end

end
function setPowerBar(info,sp,hp)
    info.powerBar1:setVisible(false)
    info.powerBar2:setVisible(false)
    info.powerBar3:setVisible(false)
    if info.name_0 then
        for i=0,2 do
            info["name_"..i]:setVisible(false)
        end
    end
    if hp ~= nil and hp <= 0 then
        if info.name_0 then
            info.name_0:setVisible(true)
        end
        return
    end
    if info.name_0 then
        local name = ""
        if sp < 100 then
            name = "0"
        elseif sp < 200 then
            name = "0"
        elseif sp < 300 then
            name = "1"
        else
            name = "2"
        end
        info["name_"..name]:setVisible(true)
    end

    local full = false
    local lv = 1

    if sp <=100 then
        info.powerBar1:setVisible(true)
        info.powerBar1:setPercent(sp)
        if sp == 100 then
            full = true
            lv = 1
            --twinkle(info.powerBar1)
        end

    elseif sp <= 200 then
        info.powerBar1:setVisible(true)
        info.powerBar1:setPercent(100)
        info.powerBar2:setVisible(true)
        info.powerBar2:setPercent(sp-100)
        if sp == 200 then
            full = true
            lv = 2
            --twinkle(info.powerBar2)
        else
            full = true
            lv = 1
            --twinkle(info.powerBar1)
        end
    elseif sp <= 300 then
        --info.powerBar1:setVisible(true)
        --info.powerBar1:setPercent(100)
        info.powerBar2:setVisible(true)
        info.powerBar2:setPercent(100)    
        info.powerBar3:setVisible(true)  
        info.powerBar3:setPercent(sp-200)
        if sp == 300 then
            full = true
            lv = 3
            --twinkle(info.powerBar3)
        else
            full = true
            lv = 2
           -- twinkle(info.powerBar2)
        end
    end

    
    if full and (hp==nil or hp >0) then
        if info.full == nil then
            --info.full = tolua.cast(CCArmature:create("skillfull"),"CCArmature")
            
            if info.pvp == true then

                info.full = tolua.cast(CCArmature:create("skillfull"),"CCArmature")
                info.sprite:addNode(info.full,9999)
                 info.full:setPosition(ccp(50,50))
            else
                info.full = tolua.cast(CCArmature:create("skillfull2"),"CCArmature")
                info.spbg:addNode(info.full,15)
                info.full:setPosition(ccp(0,0))
            end
            local anim = info.full:getAnimation()
            anim:playWithIndex(0)
           
            
            local info2 = nil
            if lv == 1 then
                info2=lottery.lotteryEffect.wood
            elseif lv == 2 then
                info2=lottery.lotteryEffect.fire
            elseif lv == 3 then
                info2=lottery.lotteryEffect.water
            end
            info.full:setShader(kCCShader_PositionColorPower);
            info.full:setColor(ccc3(info2.r,info2.g,info2.b))
        end
    else
        if info.full ~= nil then
            info.full:removeFromParentAndCleanup(true)
            info.full  = nil
        end
    end
end
function exit()

    if this ~=nil then
        stopClick()
        CCDirector:sharedDirector():setAnimationInterval(1.0 / 45);
        for i,v in pairs(animList) do
            tool.unLoadAnim(i,v)
        end
         lottery.exit()
        animList = {}
        AudioEngine.stopMusic(true)
        if hitHandler then
            unSchedule(hitHandler)
            hitHandler= nil
        end
        widget.quest.loadingbar.obj:stopAllActions()
        local par = this
        this = nil
        par:stopAllActions()
        for i,v in pairs(Role) do
            if v.sprite then
                v.sprite:stopAllActions()
                if v.animSprite then
                    v.animSprite:stopAllActions()
                end
                v.sprite:removeFromParentAndCleanup(true)
            end
        end
       
        --this:remo(true)
        par:removeFromParentAndCleanup(true)

        effect.this = nil
        effect.widget = nil
        effect.startPlay = nil
       -- package.loaded['battle.lotteryView'] = nil
       -- require('battle.lotteryView')

        --obj = nil
    end
end
function leaveThisScene(loading)
    exit()
    local dis = disconnect
    local pveTmp = pve
    package.loaded['battle.scene'] = nil
    package.loaded['battle.scene'] =require('battle.scene')
    if loading then
        local sceneManager = package.loaded['scene.sceneManager']
        sceneManager.change(sceneManager.SceneType.loading)
        package.loaded['scene.loading'].okCall=function ()
            if dis then
                local nc = package.loaded['logic.nc']
                nc.connect()
                local callBack = package.loaded['handler.login']
                callBack.afterBattleConnec = function ()
                    mPve.endPveCallBack(pveTmp)
                end
            else
                mPve.endPveCallBack(pveTmp)
            end
        end
    else

    end
end
function leaveThisSceneAndGotoHome()
    leaveThisScene()
    local sceneManager = package.loaded['scene.sceneManager']
    sceneManager.change(sceneManager.SceneType.mainScene)
    --local pveResult =  package.loaded['scene.pveResult']
    --pveResult.info = info
    local mainScene = package.loaded['scene.main']
    mainScene.afterLoadingEnd = function()
        mainScene.createSubWeiget(mainScene.widgetID.homepage)
    end
end
function leaveThisSceneAndGotoCreate()
	local sceneManager = package.loaded['scene.sceneManager']
	sceneManager.change(sceneManager.SceneType.loading) 
	local loading = package.loaded['scene.loading']
	loading.okCall = function ()
        local createrole = package.loaded['login.createrole']
        createrole.loadRole(function ()
    		local sceneManager = package.loaded['scene.sceneManager']
    		sceneManager.change(sceneManager.SceneType.createrole)
        end)
	end
end
function leaveSceneAndGotoPvpList()
   --leaveThisSceneAndGotoHome()
   -- leaveThisScene()
   exit()
   package.loaded['battle.scene'] = nil
   require('battle.scene')
   local sceneManager = package.loaded['scene.sceneManager']
   local mainScene = package.loaded['scene.main']
   sceneManager.change(sceneManager.SceneType.mainScene)
   mainScene.nextSubWidget = 4
   --local sceneManager = package.loaded['scene.sceneManager']
   --sceneManager.change(sceneManager.SceneType.loading)
end
function setForNewGuide()
    --loadAnim("effects_a998",1)
   -- initLotteryBtn()

   widget.laohuji.top.obj:setTouchEnabled(false)
    widget.laohuji.top.obj:registerEventScript(guideStartTouch)
     widget.battle_scene.bg.obj:loadTexture("battle/map1.jpg")
    tool.loadAnim("effects_a998",1)
    animList["effects_a998"]= 1
    AudioEngine.playMusic("bgm_02.mp3",true)
    pve = {
        round = 1,
        playedAction = 1,
        pvp = false,
        autoFlag = false,
        gold = 0,
        lotteryType = conf.LotteryType.Battle,
        newGuide = true,
    }
  --初始化头像的基础数据

    for i=1,4 do
        local parent = widget["role_icon_"..i].obj
        local obj = widget.role_icon_tmp_super.obj:clone()
        parent:addChild(obj,10)
        obj:setPosition(ccp(0,0))
        obj:setTouchEnabled(false)
        RoleIcon[i] = {}
        local info =  RoleIcon[i]
        info.shader = kCCShader_PositionTextureColor
        info.id = i
        info.parent = parent
        info.sprite = obj
           info.moveSpace = tolua.cast(obj:getChildByName("info"),"Layout")
        info.level = tolua.cast( info.moveSpace:getChildByName("level"), "ImageView")
        info.image = tolua.cast( info.moveSpace:getChildByName("image"), "ImageView")
        info.image_real = tolua.cast(info.moveSpace:getChildByName('image_real'),"ImageView")
        info.nature = tolua.cast( info.moveSpace:getChildByName("nature"), "ImageView")
        info.hpBar =  tolua.cast( obj:getChildByName("hpbg"):getChildByName("bar"), "LoadingBar")
        info.spbg = tolua.cast(  obj:getChildByName("spbg"), "ImageView")
        info.powerBar1 = tolua.cast(info.spbg :getChildByName("bar1"), "LoadingBar")
        info.powerBar2 = tolua.cast( info.spbg :getChildByName("bar2"), "LoadingBar")
        info.powerBar3 = tolua.cast( info.spbg :getChildByName("bar3"), "LoadingBar")

        info.name_0  =  tolua.cast(  info.spbg:getChildByName("name_0"), "ImageView")
        info.name_1  =  tolua.cast(  info.spbg:getChildByName("name_1"), "ImageView")
        info.name_2  =  tolua.cast(  info.spbg:getChildByName("name_2"), "ImageView")
    end  
    --bf = pve.bf
    initIcon()
    initSelfPlayer()
    initOppoPlayer()
    --startBtnEnable(false)

    lottery.initLottery(pve.lotteryType,nil,true)
    startBtnEnable(pfalse)

    setAutoStatus(false,false,false)
    --top
    effect.setGoldCnt(0)
    effect.setBoxCnt(0)
    effect.setExpCnt(0)
    setJewNum(pve.gold)
    
    widget.oppo.obj:setVisible(true)
    widget.quest.obj:setVisible(false)
    widget.mian_btn.obj:setVisible(false)
     widget.mian_btn.obj:setTouchEnabled(false)
    widget.control.start_btn.obj:registerEventScript(guideStartTouch)
    startPlay()
end
function startRunToSceeneForAll()
    runToScene(1,1,function()
        runToScene(2,1,startPlay)
    end)
    return "stopAction"
end
function setForPVP()
    widget.battle_scene.bg.obj:loadTexture("battle/map0.jpg")
    AudioEngine.playMusic("bgm_03.mp3",true)
    pve = {
        round = 1,
        playedAction = 1,
        pvp = true,
        autoFlag = true,
    }

    local pos = tool.getPosition(widget.battle_scene.obj)
    tool.setPosition(widget.battle_scene.obj,{align = pos.align,left = 0,right = 0,top=(Screen.height-1136)/2+95,bottom=0,type =LAYOUT_RELATIVE})
    for i=1,3 do

        local parent = widget.pvp["role_icon_"..i].obj
        local obj = widget.role_icon_tmp.obj:clone()
        parent:addChild(obj,10)
        obj:setPosition(ccp(0,0))
        obj:setTouchEnabled(false)
        RoleIcon[i] = {}
        local info =  RoleIcon[i]
        info.id = i
        info.parent = parent
        info.sprite = obj
        info.level = tolua.cast( obj:getChildByName("level"), "ImageView")
        info.image = tolua.cast( obj:getChildByName("image"), "ImageView")
        info.nature = tolua.cast( obj:getChildByName("nature"), "ImageView")
        info.hpBar =  tolua.cast( obj:getChildByName("hpbg"):getChildByName("bar"), "LoadingBar")
        info.powerBar1 = tolua.cast( obj:getChildByName("spbg"):getChildByName("bar1"), "LoadingBar")
        info.powerBar2 = tolua.cast( obj:getChildByName("spbg"):getChildByName("bar2"), "LoadingBar")
        info.powerBar3 = tolua.cast( obj:getChildByName("spbg"):getChildByName("bar3"), "LoadingBar")
        info.pvp = true
    end 
    for i=11,13 do
        local parent = widget.pvp["role_icon_"..i].obj
        local obj = widget.role_icon_tmp_1.obj:clone()
        parent:addChild(obj,10)
        obj:setPosition(ccp(100,0))
        obj:setTouchEnabled(false)
        RoleIcon[i] = {}
        local info =  RoleIcon[i]
        info.id = i
        info.parent = parent
        info.sprite = obj
        info.level = tolua.cast( obj:getChildByName("level"), "ImageView")
        info.image = tolua.cast( obj:getChildByName("image"), "ImageView")
        info.nature = tolua.cast( obj:getChildByName("nature"), "ImageView")
        info.hpBar =  tolua.cast( obj:getChildByName("hpbg"):getChildByName("bar"), "LoadingBar")
        info.powerBar1 = tolua.cast( obj:getChildByName("spbg"):getChildByName("bar1"), "LoadingBar")
        info.powerBar2 = tolua.cast( obj:getChildByName("spbg"):getChildByName("bar2"), "LoadingBar")
        info.powerBar3 = tolua.cast( obj:getChildByName("spbg"):getChildByName("bar3"), "LoadingBar")
        info.pvp = true
    end 
    lottery.initLottery(mConf.LotteryType.Battle,nil,true)
    initSelfPlayer(true)
    widget.oppo.obj:setVisible(false)
    widget.quest.obj:setVisible(false)
    widget.info2.obj:setVisible(false)
    widget.battle_scene.bg.obj:setPosition(ccp(0,0))
    local pos = tool.getPosition(widget.laohuji.obj)
    tool.setPosition(widget.laohuji.obj,pos,{x=0,y=65})

    widget.pvp.obj:setVisible(true)
    widget.pvp_info.obj:setVisible(true)
    widget.pvp_info.name_1.obj:setText(bf.pvpInfo.team2.charName)
    widget.pvp_info.name_2.obj:setText(bf.pvpInfo.team1.charName)

    local lv1 = countLv.getPvpLv(bf.pvpInfo.team2.pvpExp)
    local lv2 = countLv.getPvpLv(bf.pvpInfo.team1.pvpExp)
    widget.pvp_info.lv_1.obj:setText(gamedata["pvpExp"][lv1].name)
    widget.pvp_info.lv_2.obj:setText(gamedata["pvpExp"][lv2].name)
    widget.pvp_info.exp_1.obj:setText(bf.pvpInfo.team2.pvpExp)
    widget.pvp_info.exp_2.obj:setText(bf.pvpInfo.team1.pvpExp)
    local charList = {bf.pvpInfo.team2.charId,bf.pvpInfo.team1.charId}
    call(interface.getImageFileList,charList)
    for i = 1, 2 do
       local func1,func2
       func1 = function(fileName)
	  if fileManager.hash[fileName] == true then
	     widget.pvp_info["image_"..i].obj:loadTexture(fileManager.path.."/"..fileName)
	  else
	     func2 = function()
		widget.pvp_info["image_"..i].obj:loadTexture(fileManager.path.."/"..fileName)
		event.unListen(fileName,func2)
	     end
	     event.listen(fileName,func2)
	     fileManager.download(downloadURL,splitString(fileName,"")[1],0,0)
	  end
	  event.unListen("getImageFileList"..charList[i],func1)
       end
       event.listen("getImageFileList"..charList[i],func1)
    end
  
    widget.pvp_info.round.obj:setText("0")
    widget.control.obj:setVisible(false)
    widget.info.obj:setVisible(false)
    --initOppoPlayer()
    initIcon(true)
    runToScene(1,1,function()
        runToScene(2,1,startPlay)
    end)
end
function roundChange(action)
    widget.pvp_info.round.obj:setText(action.round)
    widget.pvp_info.round.shadow:setText(action.round) 
end
--[[
    1.设置pve进度
    2.初始化将要运行的bf
    3.初始化icon以及己方玩家的信息
    4.初始化属性
    5.初始化老虎机
    6.如果有开场剧情则开始使用开场剧情
    7.否则开始播放战斗序列
]]
function initLotteryBtn()
    widget.laohuji.top.obj:setTouchEnabled(true)
    local x = nil 
    local y =nil
    local ps =nil
    widget.laohuji.top.obj:registerEventScript(function (event,data)
        --print (event)
        local pos = data:getLocation()
        if event == "pushDown" then
            if  widget.control.pre_refresh_btn.obj:isTouchEnabled()  then
               onPreRefresh("releaseUp") 
               return
            end
            if not widget.control.start_btn.obj:isTouchEnabled() then
                return 
            end
            x = pos.x
            y = pos.y
            -- lik
            onStart("pushDown")
            ps = CCParticleSystemQuad:create("effect/lotteryFinger.plist")
            ps:setPosition(ccp(pos.x,pos.y))
            this:addChild(ps,1000)
            performWithDelay(function ()
                if ps then
                    ps:removeFromParentAndCleanup(true)
                    ps = nil
                end

            end,1.5)
        else
            if x== nil then
                return
            end
            if ps then
                ps:setPosition(ccp(pos.x,pos.y))
            end
            local diffx = pos.x - x
            local diffy = pos.y - y
            if diffy > 200 or diffy < -200 then
                if ps then
                    ps:removeFromParentAndCleanup(true)
                    ps = nil
                end
                x = nil
                y = nil
                return 
            end
            if event == "move" then
               
               -- print (diffx)
                if diffx > 110 then
                    if lottery.stopNow(3) then
                       -- print("stopNow ... 3")
                    end
                end
                if diffx > 110 *2 then
                    if lottery.stopNow(4) then
                       -- print ("stopNow ... 4")
                    end
                end
            end
            if event == "releaseUp" or event == "cancelUp" then
                x = nil
                y = nil
                if ps then
                    ps:removeFromParentAndCleanup(true)
                    ps = nil
                end
            end
        end

    end)
end
local enterCall = nil
function enterTransitionFinish()
    if enterCall then
        local call = enterCall
        enterCall = nil
        call()
    end
end
function onEnter(callBack)
    for i =1,4 do
        RoleIcon[i].iVis = RoleIcon[i].parent:isVisible()
        RoleIcon[i].parent:setVisible(false)

    end
    enterCall = function ()
        local r = 1.0
        local pos = RoleIcon[1].ipos
        for i = 1,4 do
            if RoleIcon[i].iVis == true then
                local  info  = RoleIcon[i]
                local  parent = info.parent 
                local  sp = info.spbg
                local  hpBar = info.hpBar
                parent:setVisible(true)
                tool.setPosition(parent,pos)
                local percent = hpBar:getPercent()
                hpBar:setPercent(0)

                createEnterEffect(parent,{x=640,y=0,easeIn = true},0.2*r,function()
                    performWithDelay(function ()
                        createEffect(tool.Effect.rotate,{rotate = 15,time=0.2*r,easeIn = true},info.moveSpace,function ()
                            tool.setPosition(parent,info.ipos)
                            createEffect(tool.Effect.rotate,{rotate = 0,time=0.2*r},info.moveSpace,nil,true)
                            createEnterEffect(parent,{x=pos.x-info.ipos.x,y=0},0.3*r,function()
                                local func  
                                local startTime = C_CLOCK()
                                local allTime = 0.2
                                func = function (dt)
                                    
                                    timeAll =  C_CLOCK() - startTime
                                    --print (timeAll)
                                    if timeAll > allTime then
                                        hpBar:setPercent(percent)
                                        return 
                                    else
                                        hpBar:setPercent(percent*timeAll/allTime)
                                        createEffect(tool.Effect.delay,{time=0},hpBar,func,true,false)
                                    end
                                end
                                func()
                                local c = callBack
                                callBack = nil 
                                if c ~= nil then
                                    c ()
                                end
                            end,true)
                        end)
                end,0.05)
                end,nil,tool.EnterAddEffect.drop)           
             end
        end
    end
end
function setForPVE()
    AudioEngine.playMusic("bgm_02.mp3",true)
    widget.battle_scene.bg.obj:loadTexture("battle/map"..pve.sceneMap..".jpg")
     --初始化头像的基础数据
    initLotteryBtn()
    
    for i=1,4 do
        local parent = widget["role_icon_"..i].obj
        local obj = widget.role_icon_tmp_super.obj:clone()
        parent:addChild(obj,10)
        obj:setPosition(ccp(0,0))
        obj:setTouchEnabled(false)
        RoleIcon[i] = {}
        local info =  RoleIcon[i]
        info.id = i
        info.parent = parent
        info.sprite = obj
        info.shader = kCCShader_PositionTextureColor
        info.ipos = tool.getPosition(parent)
        info.moveSpace = tolua.cast(obj:getChildByName("info"),"Layout")
        info.level = tolua.cast( info.moveSpace:getChildByName("level"), "ImageView")
        info.image = tolua.cast( info.moveSpace:getChildByName("image"), "ImageView")
        info.image_real = tolua.cast(info.moveSpace:getChildByName('image_real'),"ImageView")
        info.nature = tolua.cast( info.moveSpace:getChildByName("nature"), "ImageView")
        info.hpBar =  tolua.cast( obj:getChildByName("hpbg"):getChildByName("bar"), "LoadingBar")
        info.spbg = tolua.cast(  obj:getChildByName("spbg"), "ImageView")
        info.powerBar1 = tolua.cast(info.spbg :getChildByName("bar1"), "LoadingBar")
        info.powerBar2 = tolua.cast( info.spbg :getChildByName("bar2"), "LoadingBar")
        info.powerBar3 = tolua.cast( info.spbg :getChildByName("bar3"), "LoadingBar")

        info.name_0  =  tolua.cast(  info.spbg:getChildByName("name_0"), "ImageView")
        info.name_1  =  tolua.cast(  info.spbg:getChildByName("name_1"), "ImageView")
        info.name_2  =  tolua.cast(  info.spbg:getChildByName("name_2"), "ImageView")
    end  

    --bf = pve.bf
    initIcon()
    initSelfPlayer()
    --startBtnEnable(false)

    lottery.initLottery(pve.lotteryType,nil,true)
    setDoubleStatus(pve.buttonStatus.double.vis,
        pve.buttonStatus.double.touch,
        pve.buttonStatus.double.status)
    startBtnEnable(pve.buttonStatus.start.touch)

    setAutoStatus(pve.buttonStatus.auto.vis,
        pve.buttonStatus.auto.touch,
        pve.buttonStatus.auto.status)
    --top
    effect.setGoldCnt(pve.result.gold+bf.drop.gold)
    effect.setBoxCnt(#pve.result.item+#bf.drop.item)
    effect.setExpCnt(pve.result.exp+bf.drop.exp)
    setJewNum(pve.gold)

    if pve.enterAnim == true then
        onEnter(function ()
            setPvePercent(0,0,pve.processTotal,0)
            local func = function ()
                specialRunToScene(1,1,startPlay)
            end
            if pve.startAnim then
                pointAnim(pve.startAnim,func)
            else
                performWithDelay(func,0.5)
            end
        end)
    else

        -- 开始恢复当前战斗数据
        widget.quest.obj:setVisible(false)
        if pve.inBattle then
            setRefreshNum(bf.lotteryRefCnt*2 )
            initOppoPlayer()
            -- 当前显示的东西为 - - 
            --widget.quest.obj:setVisible(false)
            widget.oppo.obj:setVisible(true)         
        else
            setRefreshNum(pve.lotteryRefCnt*2 )
            --widget.quest.obj:setVisible(true)
            widget.oppo.obj:setVisible(false) 
        end
        for i,role in pairs(Role) do
            if role.roleinfo.hp > 0 then
                role.sprite:setVisible(true)
            else
                role.sprite:setVisible(false)
            end
            if role.roleinfo.pos ~= role.roleinfo.id then
                -- 移动到攻击位置
                local space2 =  playerToPostion[role.roleinfo.pos]
                local atkPos = {x=role.attackOffset,y=0} 
                if role.flip == true then
                    atkPos.x = -atkPos.x
                    atkPos.y = -atkPos.y
                end
                local posinfo = spaceInfo[space2].pos
                local y = math.random(1,10)
                role.sprite:setZOrder(spaceInfo[space2].z+y)
                role.sprite:setPosition(ccp(posinfo.x+atkPos.x+math.random(1,5),posinfo.y+atkPos.y+y*5))
            end
        end
        if pve.lotteryRunning then
            lottery.startPreLottery(pve.preLotteryActionCache)
        else
            if pve.lottery ~= nil  then
                if pve.lottery.superFlag == true then
                    lottery.initLottery(conf.LotteryType.BattleS,nil,true,pve.lottery.five,pve.lottery.super)
                else
                    lottery.initLottery(conf.LotteryType.Battle,nil,true,pve.lottery.five,pve.lottery.normal)
                end
            end
        end
        setDoubleStatus(pve.buttonStatus.double.vis,
            pve.buttonStatus.double.touch,
            pve.buttonStatus.double.status)
        startBtnEnable(pve.buttonStatus.start.touch)

        setAutoStatus(pve.buttonStatus.auto.vis,
            pve.buttonStatus.auto.touch,
            pve.buttonStatus.auto.status)
        widget.quest.percent.obj:setStringValue(pve.processCnt..":"..pve.processTotal)
        widget.quest.loadingbar.obj:setPercent(pve.process)
        if pve.relottery ~= true then
            oldPerformWithDelay(startPlay,0)
        end
    end
end
pointWidget={
    _ignore = true,
    bg = {
        _type="ImageView",
        npc1 = {_type = "ImageView"},
        npc2 = {_type = "ImageView"},
        continue = {_type="Label",_shadow=false},
        skip  = {_type="Label",_shadow=false},
        name1 = {_type="Label",_shadow=true},
        name2 = {_type="Label",_shadow=true},
        desc  = {_type="Label",_shadow=false},
    }    
}
pointList = {}
function setInfo(info)
    pointWidget.bg.name1.obj:setVisible(false)
    pointWidget.bg.name1.shadow:setVisible(false)
    pointWidget.bg.name2.obj:setText(info.name)
    pointWidget.bg.name2.shadow:setText(info.name)
    pointWidget.bg.desc.obj:setText(info.words)

    if info.initiative1 == 1 then
        pointWidget.bg.npc1.obj:setColor(ccc3(255,255,255))
    else
        pointWidget.bg.npc1.obj:setColor(ccc3(128,128,128))
    end
    if info.initiative2 == 1 then
        pointWidget.bg.npc2.obj:setColor(ccc3(255,255,255))
    else
        pointWidget.bg.npc2.obj:setColor(ccc3(128,128,128))
    end

    if info.npcImage1 == 0 or info.npcImage1 == "0"  then
        pointWidget.bg.npc1.obj:setVisible(false)
    else
        pointWidget.bg.npc1.obj:loadTexture("npc/npc_"..info.npcImage1..".png")
        pointWidget.bg.npc1.obj:setVisible(true)
    end
    if info.npcImg2 == 0 or info.npcImg2  == "0" then
        pointWidget.bg.npc2.obj:setVisible(false)
    else
        pointWidget.bg.npc2.obj:loadTexture("npc/npc_"..info.npcImg2..".png")
        pointWidget.bg.npc2.obj:setVisible(true)
    end
end
function pointAnim(anim,func)
    local touch =  tool.loadWidget("nshx/plot",pointWidget)
    pointList = {}
    for i,v in pairs(gamedata['plot']) do
        if v.groupId == anim then
            pointList[v.Content] = v
        end
    end
    local endFunc = function ( )
         touch:setTouchEnabled(false)
        touch:removeFromParentAndCleanup(true)
        tool.cleanWidgetRef(pointWidget)
        if func then
            func()
        end
    end
    local id = 1
    if pointList[1] == nil then
        endFunc()
        return
    end
    this:addChild(touch,10000)
    --widget:setZOrder(10000)
    setInfo(pointList[1])
    pointWidget.bg.obj:registerEventScript(function(event)
        if event ~= "releaseUp" then
            return
        end
        id = id + 1
        if pointList[id] == nil then
            endFunc()
        else
            setInfo(pointList[id])
        end
    end)
    pointWidget.bg.skip.obj:registerEventScript(function(event)
        if event ~= "releaseUp" then
            return
        end
        endFunc()
    end)
    pointWidget.bg.obj:setTouchEnabled(true)
    pointWidget.bg.skip.obj:setTouchEnabled(true)
    if func then
       -- func()
    end
end
function startBtnEnable(flag,refresh)
    widget.control.start_btn.obj:setBright(flag)
    widget.control.start_btn.obj:setTouchEnabled(flag)
    if refresh == true then
        widget.control.start_btn.obj:setBright(flag)
        widget.control.start_btn.obj:setTouchEnabled(false)
        widget.control.start_btn.obj:setVisible(false)
        widget.control.refresh_btn.obj:setVisible(false)
        widget.control.refresh_btn.obj:setTouchEnabled(false)  
        widget.control.pre_refresh_btn.obj:setTouchEnabled(flag)  
        widget.control.pre_refresh_btn.obj:setVisible(flag) 
    else
        widget.control.start_btn.obj:setVisible(true)
        widget.control.start_btn.obj:setBright(flag)
        widget.control.start_btn.obj:setTouchEnabled(flag)
        widget.control.refresh_btn.obj:setVisible(false)
        widget.control.refresh_btn.obj:setTouchEnabled(false)
        widget.control.pre_refresh_btn.obj:setTouchEnabled(false)  
        widget.control.pre_refresh_btn.obj:setVisible(false) 
    end

end

playerToPostion = {
    
}

oldSelectRole = nil
function initOppoPlayer()
    oldSelectRole = nil
    local data = bf.team2
    local target = true
    local roleNum = 0
    local role = nil
    for i,v in pairs(data.roleMap) do
        if type(v) == type({}) then
            roleNum = roleNum + 1
            role = v
        end
    end
    if roleNum == 1 then
        local i = 15 
        local roleinfo = role
         if roleinfo ~= nil then
            playerToPostion[roleinfo.id] =i
            local wid = widget.battle_scene["role_"..spaceInfo[i].name].obj
            local posx =  wid:getPositionX()
            local posy =  wid:getPositionY()
            local pos = tool.getPosition(wid)

            spaceInfo[i].pos = pos
            addRole(i,false,roleinfo,wid)
            Role[i].sprite:setVisible(false)
            Role[i].info = roleinfo
            Role[i].hpMax = mNum.getHpMax(bf,roleinfo)
            Role[i].hp  = mNum.getBattleHp(bf,roleinfo)
            Role[i].space = spaceInfo[i]
            Role[i].roleId = i-10 
            Role[i].roleinfo = roleinfo
            Role[i].power = roleinfo.power
            Role[i].isDead = false
            if target then
                target = false
                local percent = 100
                if roleinfo.notInit == false then
                   percent =  mNum.getHpPercent(bf,roleinfo) *100
                end
                setTargetHp(roleinfo.img,0,percent,roleinfo.factions,roleinfo.name)
            end
        end

    else
        for i=11,14 do 
            local roleinfo = data.roleMap[i-10]
            if roleinfo ~= nil then
                playerToPostion[roleinfo.id ] =i
                local wid = widget.battle_scene["role_"..spaceInfo[i].name].obj
                local posx =  wid:getPositionX()
                local posy =  wid:getPositionY()
                local pos = tool.getPosition(wid)

                spaceInfo[i].pos = pos
                addRole(i,false,roleinfo,wid)
                Role[i].sprite:setVisible(false)
                Role[i].info = roleinfo
                Role[i].hpMax = mNum.getHpMax(bf,roleinfo)
                Role[i].hp  = mNum.getBattleHp(bf,roleinfo)
                Role[i].space = spaceInfo[i]
                Role[i].roleId = i-10 
                Role[i].roleinfo = roleinfo
                Role[i].power = roleinfo.power
                if target then
                    target = false
                    local percent = 100
                    if roleinfo.notInit == false then
                       percent =  mNum.getHpPercent(bf,roleinfo) *100
                    end
                    setTargetHp(roleinfo.img,0,percent,roleinfo.factions,roleinfo.name)
                end
            else

            end
        end
    end
end
function setTargetHp(img,from,to,factions,name)
    local time = (from-to)/200
    from = math.floor(from)
    to = math.floor(to)
    if time < 0 then
        time = -time 
    end
    widget.oppo.loadingbar.obj:stopAllActions()
    local func = nil
    local timeStart = C_CLOCK()
    func = function ()
        local diff = C_CLOCK() -  timeStart
        local percent = diff/time
        if percent >= 1 then
            widget.oppo.loadingbar.obj:setPercent(to)
        else
            widget.oppo.loadingbar.obj:setPercent((to-from)*percent+from)
            tool.createEffect(tool.Effect.delay,{time=1/60},widget.oppo.loadingbar.obj,func)
        end

    end
    func()
    local path = img 
--    widget.oppo.image.obj:loadTexture(path)
   -- widget.oppo.nature.obj:loadTexture(mConf.laohujiIconPvp[factions].image)
    widget.oppo.name.obj:setText(name)
    widget.oppo.loadingbar.obj:setPercent(from) 
end
function twinkle(bar)
    local func = nil
    func = function ()
        createEffect(tool.Effect.blink,{time=1,f=1},bar,func)
    end
    func()
end

function initIcon(pvp)
    local data = bf.team1
     local spriteList = {}
    local charList = {}
     for i=1,4 do
        if pvp == true then
            if i == 4 then
                break
            end
        end
        local roleinfo = data.roleMap[i] 
        
        if  roleinfo~= nil then

            playerToPostion[roleinfo.id] =i
            --初始化下面的icon
            local info =  RoleIcon[i]
             info.iconPos = i
            info.roleinfo = roleinfo
            if roleinfo.owner == 0 then
                table.insert(charList,userdata.UserInfo.id)
            else
                table.insert(charList,roleinfo.owner)
            end
            table.insert(spriteList,{obj=info.image_real,info=info})
           -- info.powerBar:setPercent(roleinfo.power)
            setPowerBar(info,roleinfo.power,mNum.getHpPercent(bf,roleinfo))
            info.hpBar:setPercent(mNum.getHpPercent(bf,roleinfo)*100)
            --if mNum.getHpPercent(bf,roleinfo)<= 0 then
            --end

            local path = roleinfo.img
            info.image:loadTexture(path)
             info.nature:loadTexture(mConf.laohujiIconPvp[roleinfo.factions].image)
             info.level:loadTexture("Image/icon_charm_"..roleinfo.badgeBean.quality..".png")
            if mNum.getHpPercent(bf,roleinfo) <= 0 then
                info.shader = kCCShader_PositionTextureGray
               -- info.image:setShader(kCCShader_PositionTextureGray)
               if info.image_real then
                info.image_real:setShader(kCCShader_PositionTextureGray)
            end
                info.image:setShader(kCCShader_PositionTextureGray)
                info.level:setShader(kCCShader_PositionTextureGray)
            else
                info.shader = kCCShader_PositionTextureColor
               -- info.image:setShader(kCCShader_PositionTextureColor)
                if info.image_real then
                info.image_real:setShader(kCCShader_PositionTextureColor)
            end
                info.image:setShader(kCCShader_PositionTextureColor)
                info.level:setShader(kCCShader_PositionTextureColor)
            end
            
            if pve.newGuide  == true then
                info.image_real:loadTexture("npc/npc_"..(i+1).."A.png")
            end
           
            if info.spbg then
                info.spbg:setTouchEnabled(true)
                info.spbg:registerEventScript(function (event,data)
                    iconTouched(event,roleinfo.id)
                end)
            end
            info.role = roleinfo
            info.parent:setVisible(true)
            if info.moveSpace then
                info.moveSpace:setTouchEnabled(true)
                info.moveSpace:registerEventScript(function (event,data)

                    onIconMove(event,data,info)
                end)
            end
        else
            --RoleIcon[i].sprite:setVisible(false)
             --RoleIcon[i]:sprite
             RoleIcon[i].parent:setVisible(false)
        end
    end
    if pvp == true then
        data = bf.team2
        for i=11,13 do
            local roleinfo = data.roleMap[i-10] 
            
            if  roleinfo~= nil then
                playerToPostion[roleinfo.id] =i
                --初始化下面的icon
                local info =  RoleIcon[i]
               
                info.roleinfo = roleinfo
               -- info.powerBar:setPercent(roleinfo.power)
                setPowerBar(info,roleinfo.power)
                info.hpBar:setPercent(mNum.getHpPercent(bf,roleinfo)*100)
                --if mNum.getHpPercent(bf,roleinfo)<= 0 then
                --end

                local path = roleinfo.img
                info.image:loadTexture(path)
                if mNum.getHpPercent(bf,roleinfo) <= 0 then
                    info.image:setShader(kCCShader_PositionTextureGray)
                else
                    info.image:setShader(kCCShader_PositionTextureColor)
                end
                
                info.nature:loadTexture(mConf.laohujiIconPvp[roleinfo.factions].image)
                info.parent:setTouchEnabled(true)
                info.parent:registerEventScript(function (event,data)
                    iconTouched(event,roleinfo.id)
                end)
                info.role = roleinfo
                 info.parent:setVisible(true)
            else
                --RoleIcon[i].sprite:setVisible(false)
                --RoleIcon[i]:sprite
                 RoleIcon[i].parent:setVisible(false)
            end
        end
    else

      
        call(interface.getImageFileList,charList)
       
       -- widget.pvp_info.image_1.obj:loadTexture()
       -- widget.pvp_info.image_2.obj:loadTexture()
        for i,charId in pairs(charList) do
            local obj = spriteList[i].obj
            local info = spriteList[i].info
           local func1,func2
           func1 = function(fileName)
                  if fileManager.hash[fileName] == true then
                    
                     obj:loadTexture(fileManager.path.."/"..fileName)
                     obj:setShader(info.shader)
                  else
                     func2 = function()
                        obj:loadTexture(fileManager.path.."/"..fileName)
                        obj:setShader(info.shader)
                        event.unListen(fileName,func2)
                     end
                     event.listen(fileName,func2)
                     fileManager.download(downloadURL,splitString(fileName,"")[1],0,0)
                  end
                  event.unListen("getImageFileList"..charId,func1)
           end
           event.listen("getImageFileList"..charId,func1)
        end
    end
end
function getMoveToPos(info,diffx,diffy)
  local p = info.iconPos
    local d = diffx/160
    p = p - d - 0.5
    if p <= 1 then
        p = 1
    end
    if p >= 4 then
        p = 4
    end
    p = math.ceil(p)
    return p
end
function moveIcon(info,diffx,diffy)
    info.moveSpace:setPosition(ccp(info.iconMove.initX-diffx,info.iconMove.initY-diffy))
    local p = getMoveToPos(info,diffx,diffy)
     if info.iconMove.recent ~= nil then
        info.iconMove.recent:setColor(ccc3(255,255,255))
    end
    if p ~= info.iconPos then
        info.iconMove.recent = RoleIcon[p].image_real
        RoleIcon[p].image_real:setColor(ccc3(200,200,200))
    end
end
function swapCurrent(info,diffx,diffy)
    local p = getMoveToPos(info,diffx,diffy)
    if p ~= info.iconPos then
        -- 移动到空位上
        -- ICON 底部
        local moveEffectList = {}
        local newPos = p
        local oldPos = info.iconPos

        local oldInfo = info
        local old = oldInfo.parent
        local posOld = tool.getPosition(old)
        local newInfo = RoleIcon[p]
        local new = newInfo.parent
        
        local posNew = tool.getPosition(new)
        --tool.setPosition(old,posNew)
        --tool.setPosition(new,posOld)
        table.insert(moveEffectList,{obj = old,pos = posNew})
        table.insert(moveEffectList,{obj = new,pos = posOld})
        oldInfo.iconPos = newPos
        newInfo.iconPos = oldPos
        RoleIcon[newPos] = oldInfo
        RoleIcon[oldPos] = newInfo


        -- Role 人物形象
        local oldRole = Role[oldPos]
        local oldinfo = oldRole.space
        local oldSprit = oldRole.sprite
        local oldZ  = oldRole.spriteZ
        local posO = tool.getPosition(oldSprit)

        local newRole = Role[newPos]
        if newRole ~= nil then
            local newinfo = newRole.space
            local newSprit = newRole.sprite
            local newZ = newRole.spriteZ
            local posN = tool.getPosition(newSprit)

            
            newRole.space = oldinfo
            newSprit:setZOrder(oldZ)
            newRole.spriteZ = oldZ
            Role[newPos] = oldRole
            playerToPostion[newInfo.roleinfo.id] = oldPos

            oldRole.space = newinfo
            oldSprit:setZOrder(newZ)
            oldRole.spriteZ = newZ
            Role[oldPos] = newRole
            playerToPostion[newInfo.roleinfo.id] = oldPos
            playerToPostion[oldInfo.roleinfo.id] = newPos

            --tool.setPosition(oldSprit,posN)
            --tool.setPosition(newSprit,posO)
            table.insert(moveEffectList,{obj = oldSprit,pos = posN})
            table.insert(moveEffectList,{obj = newSprit,pos =  posO})
        else
            local newinfo = spaceInfo[newPos]
            
            oldSprit:setZOrder(newinfo.z)
            oldRole.spriteZ = newinfo.z
            oldRole.space = newinfo

            Role[oldPos] = nil
            Role[newPos] = oldRole
            playerToPostion[oldInfo.roleinfo.id] = newPos
            --oldSprit:setPosition(ccp(newinfo.pos.x,newinfo.pos.y))
            table.insert(moveEffectList,{obj = oldSprit,pos = {x=newinfo.pos.x,y=newinfo.pos.y,type = LAYOUT_ABSOLUTE}})
        end
        local time = 0.2
        for i,v in pairs(moveEffectList) do

            if v.pos.type == LAYOUT_ABSOLUTE then
                createEffect(tool.Effect.move,{x=v.pos.x,y=v.pos.y,abs = true,time = time},v.obj)
            else
                local pos = tool.getPosition(v.obj)

                createEffect(tool.Effect.move,{x=v.pos.left-pos.left,y=-(pos.top-v.pos.top),abs = true,time = time},v.obj)
            end
            --tool.setPosition(v.obj,v.pos)
        end

        -- battle  战斗数据交换
        -- bf,pve 
        mPve.recodeUserAction(pve,bf,mConf.ActionType.swapPostion,newPos..":"..oldPos)
        mPve.swapPostion(pve,newPos,oldPos)


        return true
    end
    return false
end
function onIconMove(event,data,info)
    if (not widget.control.start_btn.obj:isTouchEnabled() ) or pve.newGuide == true  then
        return 
    end
    local pos = data:getLocation()
    if event == "releaseUp" or event == "cancelUp" then
        if info.iconMove == nil then
            return
        end
        local diffx =  info.iconMove.x - pos.x
        local diffy =  info.iconMove.y - pos.y
        swapCurrent(info,diffx,diffy) 
        info.moveSpace:setPosition(ccp(info.iconMove.initX,info.iconMove.initY))

        info.parent:setZOrder(info.iconMove.z)
         if info.iconMove.recent ~= nil then
            info.iconMove.recent:setColor(ccc3(255,255,255))
        end
        info.iconMove = nil
    elseif event == "move" then
        if info.iconMove == nil then
            return
        end
        local diffx =  info.iconMove.x - pos.x
        local diffy =  info.iconMove.y - pos.y
         moveIcon(info,diffx,diffy)
    elseif event == "pushDown" then
        info.iconMove = {}
        info.iconMove.x = pos.x
        info.iconMove.y = pos.y
        info.iconMove.initX = info.moveSpace:getPositionX()
        info.iconMove.initY = info.moveSpace:getPositionY()
        info.iconMove.z = info.parent:getZOrder()
        info.parent:setZOrder(100)
    end
end
function refreshSelfPlayer()
   for i=1,4 do
        --初始化人物
        local roleinfo = bf.team1.roleMap[i] 
        if roleinfo ~= nil then
            Role[i].roleinfo = roleinfo
            RoleIcon[i].roleinfo = roleinfo
        end
    end    
end
function initSelfPlayer(pvp)
    local data = bf.team1
    Role = {}
    playerToPostion = {}
    for i=1,4 do
        --初始化人物

        local roleinfo = data.roleMap[i] 
        --local str= "role_"..i
        local wid = widget.battle_scene["role_"..spaceInfo[i].name].obj
        --local posx =  wid:getPositionX()
        local pos = tool.getPosition(wid)
        --pos.y = Screen.height -(Screen.height-1136)/2+ pos.y
        spaceInfo[i].pos = pos
        if roleinfo ~= nil then

            playerToPostion[roleinfo.id] =i
            addRole(i,true,roleinfo,wid)
            Role[i].roleinfo = roleinfo
            Role[i].sprite:setVisible(false)
            Role[i].info = roleinfo
            Role[i].roleinfo = roleinfo
            Role[i].hpMax = mNum.getHpMax(bf,roleinfo)
            Role[i].hp  = mNum.getBattleHp(bf,roleinfo)
            Role[i].power = roleinfo.power
            Role[i].space = spaceInfo[i]
            Role[i].isDead = false
            if Role[i].hp == 0 then
                Role[i].isDead = true
            end
            for _,skill in pairs(roleinfo.skill) do
                local tmp = gamedata['skill'][skill]
                if tmp ~= nil and tmp.sound ~= "" then
                    AudioEngine.preloadEffect(tmp.sound)
                end
            end

        end
    end
    data = bf.team2
    if pvp == true then
        for i=11,14 do
            --初始化人物

            local roleinfo = data.roleMap[i-10] 

            if roleinfo ~= nil then
                playerToPostion[roleinfo.id] =i
                local wid = widget.battle_scene["role_"..spaceInfo[i].name].obj
                local pos = tool.getPosition(wid)
                spaceInfo[i].pos = pos
                addRole(i,true,roleinfo,wid)
                Role[i].roleinfo = roleinfo
                Role[i].sprite:setVisible(false)
                Role[i].info = roleinfo
                Role[i].roleinfo = roleinfo
                Role[i].hpMax = mNum.getHpMax(bf,roleinfo)
                Role[i].hp  = mNum.getBattleHp(bf,roleinfo)
                Role[i].power = roleinfo.power
                Role[i].space = spaceInfo[i]
            end
        end
    end
end
local skill_num = {}
local skill_name = {}
local skill_select = nil
local skill_Vis = 0
local skillOpenConf = {
    left = {
        name = {
            1,3,2,4
        },
        num = {
            1,2,3,4
        }
    },
    right ={ 
        name = {
            1,3,4,2
        },
        num = {
            1,2,4,3
        }
    }
}
local IconTouchEnable = false
skillNum = 3
selectSkill = 0
function iconTouched(event,roleId)
    local conf = nil
    if animStoped  then
        return
    end
    if pve.autoFlag == true then
        return
    end
    if bf.canSkill == false then
        IconTouchEnable = false
        return
    end
    if event == "releaseUp" then
    
        mPve.recodeUserAction(pve,bf,mConf.ActionType.userSkill,roleId)
        local result = battle.skillAction(bf,roleId)
        if  result > 0 then
              stopClick()
            --role.power = result
            if delayPlayHandler  then
                this:stopAction(delayPlayHandler)
                delayPlayHandler= nil
            end
            --battle.onSkillStart(bf)
            startBtnEnable(false)
            startPlay()
        elseif result  == -1 then
            widget.battle_scene.notEng.obj:stopAllActions()
            --local pos = tool.getPosition(notEng)
            widget.battle_scene.notEng.obj:setPosition(CCPoint(333,-425))
            widget.battle_scene.notEng.obj:setVisible(true)
             createEffect(tool.Effect.move,{time=0.5,x=333,y=-425+200},widget.battle_scene.notEng.obj,function()
                widget.battle_scene.notEng.obj:setVisible(false)
             end)
            return 
        end
    end

end

function setRefreshNum(cnt)
    if pve.pvp == true or pve.newGuide == true then
        return
    end
    if cnt <= pve.gold then
        widget.info.refresh_num.obj:setColor(ccc3(255,255,255))
    else
        widget.info.refresh_num.obj:setColor(ccc3(255,0,0))
    end
    widget.info.refresh_num.obj:setText(""..cnt)
end

function onStart(event)

    if event == "pushDown" then
        if not widget.control.start_btn.obj:isTouchEnabled() then
            return 
        end
        widget.control.start_btn.obj:setTouchEnabled(false)
        getLottery(lottery.stopRunning())
    end
end

function onStopSoon(event)
    if not widget.control.start_btn.obj:isTouchEnabled() then
        return 
    end
    nowStoped = true
    getLottery(lottery.stopRunning())
end

function goldEffect(action)
    local callBack = startPlay
    local gold = action.gold
    local path = "nsUI/gold.png"
    local oPoint=ccp(Screen.width/2,
            Screen.height/4*3)
    local list = {}
    local num = 20
    for i=1,num do
        local x,y = math.random(-300,300),math.random(-300,300)
        local size = widget.battle_scene.obj:getSize()
        local pos ={x=  size.width/2,y= size.height/2}
        local sprite  = CCArmature:create("gold")
        local anim = sprite:getAnimation()
        anim:playWithIndex(0)
        sprite:setScale(1)
        sprite:setPosition(oPoint)
        sprite:setZOrder(math.random(-45,45))
        tool.goldAnim(sprite,{x=pos.x,y=pos.y},{x=pos.x+x,y=pos.y+y},0.6)
        -- local action = CCMoveTo:create(0.2,point)
        --sprite:runAction(action)
        widget.battle_scene.obj:addNode(sprite)
        table.insert(list,sprite)
    end
    performWithDelayBattle(function()
        local x,y = widget.info2.obj:getPositionX()+widget.info2.gold.obj:getPositionX(),
            -(1136-Screen.height)/2-25
        for i,v in pairs(list) do
            performWithDelayBattle (function()
                tool.createEffect(tool.Effect.scale,{time = 1,scale=1},v,nil,true,true)
                tool.createEffect(tool.Effect.move,{time = 1,x=x,y=y},v,function()
                    addOneGold(1)
                    v:removeFromParentAndCleanup(true)
                end,true,true)
            end,math.random(1,1000)/1000)
        end
    end,0.6)
    performWithDelayBattle(function()
        GoldAllAdded(num)
        startPlay()
    end,0.6)
    return "stopAction"
end
function drugEffect(action)
    local callBack = startPlay
    local size = widget.battle_scene.obj:getSize()
    local ps = CCParticleSystemQuad:create("effect/medical.plist")
    ps:setPosition(ccp(size.width/4*3,size.height/4*1))
    widget.battle_scene.obj:addNode(ps,999)
    performWithDelayBattle(function()
        --ps:stopSystem()
        ps:stopSystem()
        if callBack then
           callBack()
        end
    end,3)

    performWithDelayBattle(function()
        
        ps:removeFromParentAndCleanup(true)
    end,5)
    return "stopAction"
end

local playerCnt = 0
local actionListId = 1
local maxActionListID = 0
local currectPlayList = nil
local RoundId = 0
function EndOfRound()
    startBtnEnable(true) 
end
local curPlayerListId = 1
local actionStart = 0
local canEndAction = false
function endAction()
    actionStart = actionStart - 1 
    if canEndAction and actionStart == 0 then
        nextRound()
    end
end
local lastActionNum  =1

function clearRoundInfo()
    for i,v in pairs(Role) do
        v.hit = 0
    end
end





local waitFunc = nil
local animPlayList ={
    ["attack"]={index = 0,loop = 0},
    ["skill"]={index = 1,loop = 0,noSpeedAdd=true},
    ["wait"]={index =2,loop = 1},
    ["run"]={index = 3,loop = 1},
    ["hurt"]={index = 4,loop = 0},
}
function playAnim(role,anim,speed2)
    if role.anim ~= nil then

        local speedAdd = 1
        local a = animPlayList[anim]
        role.anim:playWithIndex(a.index,0,-1,a.loop)
        if a.noSpeedAdd then
            speedAdd = 0.7
        end
        if anim == 2 or anim == 2 then

        end
        if speed2 ~= nil then
            role.anim:setSpeedScale(speed2*speedAdd)
        else
            role.anim:setSpeedScale(1*speedAdd)
        end
        --if anim == "wait" then
        if role.isDead ~= true then
           -- role.sprite:setOpacity(255)
           -- role.sprite:setVisible(true)
        end
        --end
        if anim == "attack" or anim == "skill" then
            role.anim:registerEventScript(function(event,data)
                if event == "COMPLETE" then
                    local a= animPlayList['wait']
                    role.anim:playWithIndex(a.index,0,-1,a.loop)
                     role.anim:unregisterEventScript()
                end

            end)
        else
            role.anim:unregisterEventScript()
        end
    else
        local timeScale = 1
        if anim ~= 'wait' then
            role.animSprite:setPosition(ccp(0,0))
            role.animSprite:setScale(1)
            role.waitFunc = nil
        end
        if anim == 'run' then

        elseif anim  == 'attack' or anim  == 'skill' then
            local x,y=0,0
            --local type = role.animType 
            --动画类型1=地面近战 2=地面远程 3=空中近战 4=空中远程

            if anim == 'skill' then
                if role.info.tid == 2002 then
                    --local  id = playerToPostion[role..id]
                    local pos = role.space.pos
                    local armature = CCArmature:create("effects_a998")
                    local anim = armature:getAnimation()
                    anim:playWithIndex(0,0,-1,0)
                    armature:setPosition(ccp(pos.x+50,pos.y-75))
                    armature:setScaleX(-1)
                    widget.battle_scene.obj:addNode(armature,100)
                    anim:registerEventScript(function(event,data)
                        if event == "COMPLETE" then
                            armature:removeFromParentAndCleanup(true)
                        end

                    end)
                end
            end
            local ttt = {1,3,2,3}
            role.atype = ttt[role.animType ]
            if role.atype == 1 then
                createGroupEffect(role.animSprite,{
                    {tool.Effect.move,{time=0.15*timeScale,x=x-40,y=y}},
                    {tool.Effect.move,{time=0.1*timeScale,x=x+40,y=y}},
                    {tool.Effect.move,{time=0.05*timeScale,x=x,y=y}},
                    },role.waitFunc,true)
            elseif role.atype == 2 then

                bezier(role.animSprite,{x=x,y=y},{x=x+50,y=y},0.25*timeScale,function ()
                    createGroupEffect(role.animSprite,{
                        {tool.Effect.move,{time=0.05*timeScale,x=x,y=y}},
                    },role.waitFunc,true)
                end)
            elseif role.atype == 3 then
                createEffect(tool.Effect.scale,{time = 0.1*timeScale,scale=1.1},role.animSprite,function ()
                    createEffect(tool.Effect.scale,{time = 0.1*timeScale,scale=1},role.animSprite)
                    local obj = tolua.cast(role.animSprite:clone(),"Widget")
                    role.animParent:addChild(obj,100)
                    obj:setPosition(ccp(role.animSprite:getPositionX(),role.animSprite:getPositionY()))
                    obj:setOpacity(200)
                    obj:setZOrder(role.animSprite:getZOrder()+100)
                    createEffect(tool.Effect.scale,{time = 0.2*timeScale,scaleX=1.2, scaleY=1.5},obj)
                    createEffect(tool.Effect.fadeOut,{time = 0.2*timeScale,scaleY=1,scaleY=1},obj,function()
                        obj:removeFromParentAndCleanup(true)
                        playAnim(role,"wait")
                    end,true)

                end)
            end
        elseif anim == 'wait' then
            if role.waitFunc == nil then
                role.waitFunc = function ()
                    role.animSprite:setPosition(ccp(0,0))
                    role.animSprite:stopAllActions()
                    createGroupEffect(role.animSprite,{
                        {tool.Effect.scale,{time=0.6*timeScale,scaleY = 1.04,scaleX=1}},
                        {tool.Effect.scale,{time=0.6*timeScale,scale = 1}},
                        },role.waitFunc,true)
                end
                role.waitFunc()
            end
        elseif anim == 'hurt' then
            local offset = 15
            local x,y=0,0
            createEffect(tool.Effect.move,{time=0.05*timeScale,x=x-offset,y=y-offset},role.animSprite,function()
                createEffect(tool.Effect.move,{time=0.05*timeScale,x=x+offset,y=y+offset},role.animSprite,function()
                    createEffect(tool.Effect.move,{time=0.05*timeScale,x=x,y=y},role.animSprite,function()
                      createEffect(tool.Effect.move,{time=0.05*timeScale,x=x+offset,y=y-offset},role.animSprite,function()
                        createEffect(tool.Effect.move,{time=0.05*timeScale,x=x-offset,y=y+offset},role.animSprite,function()
                            createEffect(tool.Effect.move,{time=0.05*timeScale,x=x,y=y},role.animSprite,function ()
                                playAnim(role,"wait",speed)
                            end,false,true)
                         end,false,true) 
                      end,false,true)   
                    end,false,true)
                end,true,true)
            end,true,true)
        end
    end
end
function selectPoint(id)
    mPve.recodeUserAction(pve,bf,mConf.ActionType.selectPoint,id)
    
    if oldSelectRole ~= nil and oldSelectRole ~= id then
        Role[oldSelectRole].selectObj:stopAllActions()
        Role[oldSelectRole].selectObj:removeFromParentAndCleanup(true)
        Role[oldSelectRole].selectObj = nil
    end
    if Role[id].selectObj == nil then
        Role[id].selectObj = tolua.cast(widget._s2.obj:clone(),"ImageView")
        Role[id].sprite:addChild(Role[id].selectObj ,66)
        Role[id].selectObj:setVisible(true)
        Role[id].selectObj:setPosition(ccp(0,0))
        oldSelectRole = id
        local result,action = battle.selectRole(bf,Role[id].roleId)
        if result == true then
            reduceHp(action)
            local func = nil 
            func = function()
                createEffect(tool.Effect.rotate,{time=0.5,rotate = 180},Role[id].selectObj,function()
                    createEffect(tool.Effect.rotate,{time=0.5,rotate = 360},Role[id].selectObj,func)
                end)
            end
            func()
        end
    else
        Role[id].selectObj:stopAllActions()
        Role[id].selectObj:removeFromParentAndCleanup(true)
        Role[id].selectObj = nil
        oldSelectRole = nil
        battle.selectRole(bf)
    end
end
function addShadowSize(roleId)
    local  id = playerToPostion[roleId]
    local role = Role[id] 
    role.shadowImage:setScale(role.shadowImage:getScaleX()*1.1)
end
function reSizeShadow(roleId)
    local  id = playerToPostion[roleId]
    local role = Role[id] 
    role.shadowImage:setScale(role.shadowInitScale)
end
function addShow(info,factions,x,y,scale)
    local shadow  = widget.shadow_small.obj:clone()
    local shadowImage = nil
    if factions == conf.NATURE.fire then
         shadowImage = widget.fire.obj:clone()
    elseif factions == conf.NATURE.wind then
         shadowImage = widget.water.obj:clone()
    elseif factions == conf.NATURE.wood then
         shadowImage = widget.wood.obj:clone()
    end
    shadow:addChild(shadowImage)
    shadowImage:setScale(0.25*scale)
    shadowImage:setPosition(ccp(0,0))
    shadowImage:setOpacity(210)
    shadow:setPosition(ccp(x,y))

    info.sprite:addChild(shadow,1)
    info.shadow = shadow
    info.shadowImage = shadowImage
    info.shadowInitScale = 0.25*scale
    local func = nil
    local spppp = 1.5
    func = function ()
        createGroupEffect(
            shadowImage,{
            {tool.Effect.rotate,{time=0.25*spppp,rotate=90}},
            {tool.Effect.rotate,{time=0.25*spppp,rotate=180}},
            {tool.Effect.rotate,{time=0.25*spppp,rotate=270}},
            {tool.Effect.rotate,{time=0.25*spppp,rotate=360}},},
            function ()
                func()
            end
            )
    end
    func()
end
function addRole(id,noHp,roleinfo,wid)
    local info = spaceInfo[id]
    local scale = 0.9
    if roleinfo.animFlag ~=true then
        scale = 1
        local layout = tolua.cast(Layout:create(),"Layout")
        local layout3 = tolua.cast(Layout:create(),"Layout")
        local layout2 = tolua.cast(Layout:create(),"Layout")
        local touchLayout = tolua.cast(Layout:create(),"Layout")
        --layout:setScale(0.8)
        layout2:setSize(CCSize(1,1))
        layout2:setAnchorPoint(ccp(0,0))
        layout2:setPosition(ccp(0,0))
        --Layout:setColor(ccc3(34,34,34))
        local obj = tolua.cast(widget.battle_scene.role_1.obj:clone(),"ImageView")
        obj:setVisible(true)
        obj:loadTexture(roleinfo.anim)
        obj:setAnchorPoint(ccp(0,0))
        local size = obj:getSize()
        touchLayout:setTouchEnabled(false)
        touchLayout:registerEventScript(function (event)
            if event == "releaseUp" then
               selectPoint(id)
            end
        end)
        touchLayout:setSize(CCSize(size.width*roleinfo.scale,size.height*roleinfo.scale))
        touchLayout:setPosition(ccp(-size.width*roleinfo.scale/2,-size.height*roleinfo.scale/2))
        layout:addChild(touchLayout)
        
      
        layout:setSize(CCSize(size.width*roleinfo.scale,size.height*roleinfo.scale))
        layout:setAnchorPoint(ccp(0,0))
        layout:addChild(layout3,2)
        layout3:addChild(layout2,2)
        layout3:setPosition(ccp(size.width*roleinfo.scale/2,-80))
        layout2:addChild(obj,2)
        widget.battle_scene.obj:addChild(layout,info.z)
        --this:addChild(obj,info.z)
        --local hpBar = tolua.cast(HpBar:clone(),"Widget")
        obj:setPosition(ccp(0,0))
        layout:setPosition(ccp(info.pos.x,info.pos.y))
        obj:setScaleX(roleinfo.scale)
        obj:setScaleY(roleinfo.scale)
        if info.side == true then
            obj:setScaleX(-roleinfo.scale)
        end
        Role[id] = {}
        Role[id].animSprite =layout2
        Role[id].animParent = layout3
        Role[id].sprite = layout
        Role[id].obj = obj
        Role[id].flip = info.side
        Role[id].info = info
        Role[id].offset = {x=0,y=0}
        Role[id].attackOffset = 100
        Role[id].animSpeed = 1
        Role[id].buffList = {}
        Role[id].animType = roleinfo.animType
        Role[id].touchLayout = touchLayout
        --Role[id].animInfo = AnimInfo[animStr]
        playAnim(Role[id],"wait")        
        --local shadow  = widget.shadow_small.obj:clone()
        
        addShow(Role[id],roleinfo.factions,roleinfo.shdow_x,-80,1)
        --shadow:setPosition(ccp(0,-size.height/2))
        --Role[id].sprite:addChild(shadow,1)
        return
    end
    local animStr = roleinfo.selfAnim.name
    
    if true then
       -- return
    end

    local offset = {
        x=roleinfo.selfAnim.offsetx,
        y=roleinfo.selfAnim.offsety,
        --z=24
    }
    scale=roleinfo.selfAnim.scale
    --scale = 12
    if offset == nil then
        offset = {x=0,y=0,z=10}
    end
    offset.x =offset.x *scale
    offset.y =offset.y *scale
    if info.side == false then
        offset.x = -offset.x
    end
    local postion =  CCPoint(info.pos.x+offset.x,info.pos.y+offset.y)
    local sprite = CCSprite:create()
    sprite:setPosition(ccp(info.pos.x,info.pos.y))
    sprite:setZOrder(info.z)
    --widget.battle_scene.obj:addNode(sprite,info.z)
    widget.battle_scene.obj:addNode(sprite,info.z)
    local armature = CCArmature:create(animStr)
    local anim = armature:getAnimation()
    --anim:setSpeedScale(offset.z/24)
    
    --role.anim:registerEventScript(nil)
    armature:setPosition(ccp(offset.x,offset.y))
   
    armature:setScale(scale)
    if info.side == true then
        armature:setScaleX(-scale)
    end

    sprite:addChild(armature,2)

    Role[id] = {}
    Role[id].spriteZ = info.z
    Role[id].sprite =sprite 
    Role[id].obj = armature
    if roleinfo.animFlag == true then
        Role[id].anim = anim
    end

    Role[id].flip = info.side
    Role[id].info = info
    Role[id].spaceInfo = info
    Role[id].offset = offset
    --Role[id].animSpeed = offset.z/24
    Role[id].attackOffset = roleinfo.selfAnim.attackOffset
    Role[id].buffList = {}
    playAnim(Role[id],"wait")
    addShow(Role[id],roleinfo.factions,0,-80,1)
end
function atkCmd(action)
    local  id = playerToPostion[action.roleid]
    local role = Role[id] 
    --role.anim:setSpeedScale(role.animSpeed)
    --role.anim:play("attack")
    playAnim(role,"attack",action.speed)
    role.nowAction = action.action
    if role.curPos == nil then
        role.curPos = id
    end
    --role.sprite:setZOrder(spaceInfo[role.curPos].z+2)
end
function endAttack(action)
    local  id = playerToPostion[action.roleid]
    local role = Role[id] 
    performWithDelayBattle(function()
        if role.nowAction == action.action then
            playAnim(role,"wait")
            if role.curPos == id then
                --role.sprite:setZOrder(spaceInfo[role.curPos].z)
            else
                --role.sprite:setZOrder(spaceInfo[role.curPos].z+1)
            end
        end
    end,action.need)

end

function skillStartEffect(action)
    local  id = playerToPostion[action.roleid]
    local role = Role[id] 
    local armature = CCArmature:create("skillEffect")
    local anim = armature:getAnimation()
    armature:setPosition(ccp(20,20))
    local scale = 2
    armature:setScale(-scale)
    if spaceInfo[id].side == true then
        armature:setScaleX(scale)
    end
    anim:playWithIndex(0)
    anim:setSpeedScale(1)
    role.sprite:addChild(armature,10)
    switchAnim(true)
    widget.battle_scene.bg.obj:setShader(kCCShader_PositionTextureInverse)
    
    oldPerformWithDelay(function()
        armature:removeFromParentAndCleanup(true)
        switchAnim(false)
        startPlay()
    end,0.5/speed)
    return "stopAction"
end
function stopUserSkill(action)
    widget.battle_scene.bg.obj:setShader(kCCShader_PositionTextureColor)
end
--施放动作调用角色动画的序列类型 1=Attack动作  2=skill动作 3=believerSkill动作 以后如果有新增动作名可追加
function preSkill(action)
    local  id = playerToPostion[action.roleid]
    local role = Role[id] 
    local speed = 1 
    if action.speed ~= nil then
        speed = action.speed
    end
    --role.anim:setSpeedScale(role.animSpeed*speed)
    --role.anim:play("skill")
    if action.skillres ==   1 then
        playAnim(role,"attack",speed)
    elseif action.skillres == 2 then
        playAnim(role,"skill",speed)
    elseif action.skillres == 3 then

    end
    if action.sound then
        AudioEngine.playEffect(action.sound)
    end
    role.nowAction = action.action
end
function endSkill(action)
    local  id = playerToPostion[action.roleid]
    local role = Role[id] 
    local speed = 1 
    if action.speed ~= nil then
        speed = action.speed
    end
    reSizeShadow(action.roleid)
    --battleSceneEffect()
    performWithDelayBattle(function()
        if role.nowAction == action.action then
            playAnim(role,"wait")
        end
    end,action.need)

end
function beHurtCmd(action)
    print ("beHurtCmd")
    local  id = playerToPostion[action.roleid]
    local role = Role[id] 
    local posinfo = spaceInfo[id]
    local icon = RoleIcon[id]

    if icon ~= nil and icon.moveSpace~=nil then
        icon.moveSpace:setRotation(0)
        createEffect(tool.Effect.shake,{time=0.2,roate=15},icon.moveSpace)
    end

    --role.anim:setSpeedScale(role.animSpeed)
    --role.anim:play("hurt")
    if action.noAnim ~= true then
        playAnim(role,"hurt",role.animSpeed)
        role.nowAction = action.action
        performWithDelayBattle(function()
            if role.nowAction == action.action and role.anim ~= nil then
                 playAnim(role,"wait")
            end
        end,action.need)
    end
    local hurtAnim = action.hurtAnim
    if hurtAnim == nil then
        print ("noAnim")
        return
    end
    local max = action.hurtCnt
    if max == nil then
        max = 1
    end
    for i=1,max do
        performWithDelay(function ()
            if hurtAnim.Sound ~= "" then
                AudioEngine.playEffect(hurtAnim.Sound)
            end
            local armature = CCArmature:create(hurtAnim.name)
            local anim = armature:getAnimation()
            anim:playWithIndex(0,0,-1,0)
            armature:setPosition(ccp(
                role.sprite:getPositionX()+hurtAnim.offsetx,
                role.sprite:getPositionY()+hurtAnim.offsety))
            widget.battle_scene.obj:addNode(armature,posinfo.z+2)
            anim:registerEventScript(function(event,data)
                if event == "COMPLETE" then
                    armature:removeFromParentAndCleanup(true)
                end
            end) 
        end,0.1*(i-1))
    end 
    
end
function runback(id,space2,offset,time)
    
    local role = Role[id]
    if role.flip == true then
        --atkPos.x = -atkPos.x
    end
    if offset ~= true then
        --atkPos = {x=0,y=0}
    end
    local posinfo = spaceInfo[space2].pos
    if time <= 0 then
        return
    end
    playAnim(role,"wait")
    performWithDelayBattle(function()
      role.sprite:setZOrder(spaceInfo[space2].z)
     end,time/2)
    
    createEffect(tool.Effect.move,{time=time,x=posinfo.x,y=posinfo.y},role.sprite,function()
        
    end,false,true)
    if time ~= 0 then
        createEffect(tool.Effect.fadeOut,{time=time/2},role.sprite,function ()
             performWithDelayBattle(function ()
                createEffect(tool.Effect.fadeIn,{time=time/2},role.sprite,function ()
                    playAnim(role,"wait")
                end,true)
             end,0.1
             )
        end,true,true)
    end

    role.curPos = space2
end
function runCmd(action)
    local  id = playerToPostion[action.roleid]
    local space2 =  playerToPostion[action.targetid]
    if action.back then
        runback(id,space2,false,action.need)
        return 
    end
    local offset = not action.back
    
    local role = Role[id] 

    local atkPos = {}

    atkPos = {x=role.attackOffset,y=0} 
  
    
    if role.flip == true then
        atkPos.x = -atkPos.x
        atkPos.y = -atkPos.y
    end
    if offset ~= true then
        atkPos = {x=0,y=0}
    end
    local posinfo = spaceInfo[space2].pos
    role.nowAction = action.action

    local postion = nil
    local y = math.random(1,10)

    playAnim(role,"run",2)
    performWithDelayBattle(function()

        role.sprite:setZOrder(spaceInfo[space2].z+y)
        --addLog({time=0,log=""})
    end,action.need/2)

    createEffect(tool.Effect.move,
        {time=action.need,x=posinfo.x+atkPos.x+math.random(-5,5),y=posinfo.y+atkPos.y+y*5}
        ,role.sprite,function()
            if role.nowAction == action.action then
                playAnim(role,"wait")
                role.curPos = space2
                role.sprite:setZOrder(spaceInfo[space2].z+y)
            end
         end,false,true) 

end
local hurtPosList = {
    {20,20,0.7},
    {40,40,0.5},
    {0,0,0.5},
    {25,-5,0.6},
    {30,30,0.8}
}

function createHurt(player,hurt,factions,t,combos,superHit)
    if player.sprite == nil then
        return
    end

        if t == nil then
            t = 1
        end
        if combos == nil then
            combos = 0
        end
        combos = combos - t
        local pos = player.info.pos
        local num = nil
        local reduceflag = true
        hurt = hurt/t
        if hurt < 0 then
            num = tolua.cast( widget.hp_num.obj:clone(),"LabelAtlas")
            reduceflag = false
        else
            if factions == 1 then
                num = tolua.cast( widget.water_hurt.obj:clone(),"LabelAtlas")
            elseif factions == 2 then
                num = tolua.cast( widget.fire_hurt.obj:clone(),"LabelAtlas")
            elseif factions == 3 then
                num = tolua.cast( widget.wood_hurt.obj:clone(),"LabelAtlas")
            else
                num = tolua.cast( widget.fire_hurt.obj:clone(),"LabelAtlas")
            end
        end

        --print ("#############reduceHp",hurt)
        --local num = tolua.cast( widget.water_hurt.obj:clone(),"LabelAtlas")
        if hurt > 0 then
            hurt = hurt
            num:setStringValue(""..math.floor(hurt))
        else
            hurt = - hurt
            num:setStringValue(""..math.floor(hurt))
        end
        num:setScale(1)
        local x,y = player.sprite:getPositionX(),player.sprite:getPositionY()+math.random(-7,7)
        --local randomX1,randomY1 = math.random(-25,25),math.random(-10,10)
        --local randomX2,randomY2 = math.random(-randomX1*0.7,randomX1*0.7),randomY1
        --local randomX3,randomY3 = math.random(-randomX2*0.7,randomX2*0.7),randomY1
        if superHit then
            local add = 1
            add = math.ceil(superHit/10)
            local max = 1
            local cnt = 0
            for i=1,superHit,add do
                max = i
                cnt = cnt + 1
                performWithDelayBattle(function ()
                        createhit(player,player.space,i)    
                end,0.15*(cnt-1))          
            end
            if max < superHit then
                performWithDelayBattle(function ()
                        createhit(player,player.space,superHit)    
                end,0.15*cnt) 
            end  
        end
        widget.battle_scene.obj:addChild(num,10000)
        for i=1,t do
            local obj = nil
             if i == 1 then
                obj = num
            else
                obj =num:clone()
                widget.battle_scene.obj:addChild(obj,10000)
            end
            obj:setVisible(false)
            performWithDelayBattle(function ()
                if reduceflag == true and combos+i > 1 then
                    createhit(player,player.space,combos+i)
                end
            end,0.1*(i-1))
            performWithDelayBattle(function ()
                obj:setVisible(true)
                local posx,posy = x,y
                if i%2 == 0 then
                    posx =posx -3*i+math.random(-1,1)
                else
                    posx = posx+3*i+math.random(-1,1)
                end
                posy = posy + 20*i
               local  offset = 5
               local  offsetY = 2
                obj:setPosition(ccp(posx,posy))
                     createEffect(tool.Effect.move,{time=0.05,x=posx-offset,y=posy-offsetY},obj,function()
                        createEffect(tool.Effect.move,{time=0.05,x=posx+offset,y=posy+offsetY},obj,function()
                            createEffect(tool.Effect.move,{time=0.05,x=posx,y=posy},obj,function()
                              createEffect(tool.Effect.move,{time=0.05,x=posx+offset,y=posy-offsetY},obj,function()
                                createEffect(tool.Effect.move,{time=0.05,x=posx-offset,y=posy+offsetY},obj,function()
                                    createEffect(tool.Effect.move,{time=0.05,x=posx,y=posy},obj,function ()
                                         performWithDelayBattle(function ()
                                             createEffect(tool.Effect.fadeOut,{time=0.2},obj,function()
                                                obj:removeFromParentAndCleanup(true)
                                         end)
                                         end,0.1)
                                    end,false,true)
                                 end,false,true) 
                              end,false,true)   
                            end,false,true)
                        end,true,true)
                    end,true,true)
                    --[[
                bezier(obj,{x=x,y=y},{x=x+randomX1,y=y+randomY1},0.3,function()
                    bezier(obj,{x=x+randomX1,y=y+randomY1},{x=x+randomX2,y=y+randomY2},0.2,function()
                        bezier(obj,{x=x+randomX2,y=y+randomY2},{x=x+randomX3,y=y+randomY3},0.2,function()
                            createEffect(tool.Effect.fadeOut,{time=0.2},obj,function()
                                obj:removeFromParentAndCleanup(true)
                            end)
                        end)
                    end)
                end) 
            ]]
            end,(i-1)*0.1)
        end
    end
function changeSp(action)
    local  id = playerToPostion[action.roleid]
    local role = Role[id]
    if RoleIcon[id] then
        setPowerBar(RoleIcon[id],action.sp,action.hp)
    end
end
hitflag = false
hitHandler = nil
function createhit(player,space,hitNum,s)
    if s== nil then
        s = 1
    end
    hitNum = math.floor(hitNum)
    local pos = space.pos
    local   hit = widget.battle_scene.combos.obj
    local num = widget.battle_scene.combos.num.obj
    local img = widget.battle_scene.combos.img.obj
    if hitHandler == nil then
        if hitflag == true then
            hit:stopAllActions()
            
        end
    else
        unSchedule(hitHandler)
        hitHandler= nil
    end
    hit:setVisible(true)
    hit:setOpacity(255)
    num:setStringValue(hitNum)
    if hitflag == false then
        local imgx,imgy = img:getPositionX(),img:getPositionY()
        img:setPosition(ccp(imgx-400,imgy))
        createEffect(tool.Effect.move,{time=0.1,x=imgx,y=imgy},img)
        img:setOpacity(150)
        createEffect(tool.Effect.fadeTo,{time=0.1,opacity=255},img,nil,true)
    end
    num:stopAllActions()
    num:setOpacity(150)
    num:setScale(1.6)
    createEffect(tool.Effect.scale,{time=0.1/s,scale=1},num)
    createEffect(tool.Effect.fadeTo,{time=0.1/s,opacity=255},num,nil,true)
    hitflag = true
    hitHandler = oldPerformWithDelay(function ()    
        hitHandler = nil
        createEffect(tool.Effect.fadeOut,{time = 0.5},hit,function()
            hitflag = false
        end)
    end,2/speed)

    
end
function hit(action)
    local id = playerToPostion[action.roleid]
    local role = Role[id]
    createhit(role,spaceInfo[id],action.hit)
end
function specialPng(action)
    local id = playerToPostion[action.roleId]
    local role = Role[id]
     local info = spaceInfo[id] 
    local png = action.png
    if png == '' then
        return 
    end
    local pos ={x=info.pos.x+math.random(-20,20),y=info.pos.y+math.random(80,100)}
    local obj = ImageView:create()
    obj:loadTexture("skill/"..action.png..".png")
    obj:setPosition(ccp(pos.x,pos.y))
    widget.battle_scene.obj:addChild(obj,10005)
    obj:setScale(1.5)
    tool.createEffect(tool.Effect.scale,{scale = 1,time=0.2},obj,nil,true)
    obj:setOpacity(0)
    tool.createEffect(tool.Effect.fadeIn,{time=0.2},obj,function()
        performWithDelayBattle(function ()
           createEffect(tool.Effect.scale,{scale = 1.5,time=0.1},obj,nil,true)
           createEffect(tool.Effect.fadeOut,{time=0.1},obj,function ()
               obj:removeFromParentAndCleanup(true)
           end,true)
        end,0.3)
    end,true)


end
function reduceHp(action)

    local  id = playerToPostion[action.roleid]
    local role = Role[id]
    local info =  RoleIcon[id] 
    if info then
        info.hpBar:setPercent(action.to*100)
        
    else
        if oldSelectRole == nil or id == oldSelectRole then
            local img = ''
            local factions = -1
            local name = ''
            for i,v in pairs(bf.team2.roleMap) do
                if v.id == action.roleid then
                    img = v.img
                    factions = v.factions
                    name = v.name
                end
            end
            setTargetHp(img,action.from*100,action.to*100,factions,name)
        end
    end

    local factions = action.factions
    if factions == nil then
        factions = role.info.factions
    end
    action.hp = math.floor(action.hp)
    if role and action.notCreateHurt ~= true  then
        createHurt(role,action.hp,factions,action.time,action.hit,action.superHit)
    end
end
function revive(action)
    local  id = playerToPostion[action.roleid]
    local role = Role[id] 
    local info = spaceInfo[id]    
    role.isDead = false
    role.sprite:setVisible(true)
    role.sprite:setPosition(ccp(info.pos.x,info.pos.y))  
    if role.touchLayout then
        role.touchLayout:setTouchEnabled(true)
    end 

    info = RoleIcon[id]
    if info then
        info.shader = kCCShader_PositionTextureColor
        if info.image_real then
        info.image_real:setShader(kCCShader_PositionTextureColor)
    end
        info.image:setShader(kCCShader_PositionTextureColor)
        info.level:setShader(kCCShader_PositionTextureColor)
        --RoleIcon[id].image:setShader(kCCShader_PositionTextureColor)
  end
end
function dieCmd(action)
    local  id = playerToPostion[action.roleid]
    local role = Role[id] 
    local info = spaceInfo[id]
    role.isDead = true
    local notAllDead = false
    local x,y = role.sprite:getPositionX(),role.sprite:getPositionY()
    local scaleX = 0.5
    if info.side then
        scaleX = -scaleX
    end
    --role.sprite:setVisible(false)
    if id == oldSelectRole then
        battle.unSelectRole(bf)
        role.selectObj:stopAllActions()
        role.selectObj:removeFromParentAndCleanup(true)
        role.selectObj = nil
        oldSelectRole = nil
    end
    if RoleIcon[id] then
         if RoleIcon[id].full ~= nil then
            RoleIcon[id].full:removeFromParentAndCleanup(true)
            RoleIcon[id].full  = nil
        end
    end
    if role.touchLayout then
        role.touchLayout:setTouchEnabled(false)
    end
    --role.anim:play("wait")
    playAnim(role,"wait")
    createEffect(tool.Effect.move,{time=0.6,x=x,y=y+20},role.sprite,nil,false,true)
    createEffect(tool.Effect.fadeOut,{time=.6,x=x,y=y},role.sprite,nil,true,true)
    createEffect(tool.Effect.scale,{time=.6,scaleX=scaleX,scaleY=1},role.sprite,function()
            role.sprite:setVisible(false)
            createEffect(tool.Effect.scale,{time=1,scale=1},role.sprite)
    end,true,true)
    info = RoleIcon[id]
    if info then
       
        setPowerBar(RoleIcon[id],0,0)
        info.shader = kCCShader_PositionTextureGray
        if info.image_real then
        info.image_real:setShader(kCCShader_PositionTextureGray)
    end
        info.image:setShader(kCCShader_PositionTextureGray)
        info.level:setShader(kCCShader_PositionTextureGray)
        if info.full ~= nil then
           info.full:removeFromParentAndCleanup(true)
           info.full = nil
        end

    end
end

--[[
BATTLE_ACTION_TYPE={
    run="run",  --跑动
    can_lottery = "can_lottery" , --可以挥动老虎机
    lottery = "lottery",
    revive = "revive",
    dodge = "dodge",
    parry = "parry",
    beHurt = "beHurt",
    preAttack = "preAttack",
    endAttack = "endAttack",
    redeceHp = "redeceHp",
}
--]]
-- 1 quest to oppo
-- 2 oppo to quest
function switchQuestAndOppo(type,func)
    local org,op
    if type == 1 then
        org = nil
        op = widget.oppo.obj
    else
        op = nil
        org = widget.oppo.obj
    end
    if org ~= nil then
        createExitEffect(org,{x=-640,y=0},0.5,true,function()
            org:setVisible(false)
            if func then
                func()
            end
        end)
    end
    if op ~= nil then
        op:setVisible(true)
        createEnterEffect(op,{x=-640,y=0},0.5,function()
            if func then
                func()
            end
        end)
    end
end
function stringEffect(list,center,callBack)
    local maxi = 0
    for i,v in pairs(list) do
        if i > maxi then
            maxi = i
        end
    end
    for i,v in pairs(list) do
        local sprite = CCSprite:create(v.file)
        sprite:setPosition(ccp(center.x,center.y))
        this:addChild(sprite,10000)
        createEffect(tool.Effect.scale,{time=0,scale=0},sprite,function()
            createEffect(tool.Effect.scale,{time=0.3,scale=1},sprite,nil,true,true)
            createEffect(tool.Effect.move,{time=0.3,x=v.pos.x,y=v.pos.y},sprite,nil,true,true)
            performWithDelayBattle(function()
                --local ps = CCParticleSystemQuad:create("effect/ExplodingRing.plist")
                --ps:setPosition(ccp(center.x,center.y)) 
                --this:addChild(ps,999)
                --ps:setScale()
            end,0.55)
            performWithDelayBattle(function()
                local sca = 3
                local func = nil
                if i == maxi then
                    func = callBack
                end
                createEffect(tool.Effect.scale,{time=0.2,scale=sca},sprite,func,true,true)
                createEffect(tool.Effect.move,{time=0.2,x=center.x + sca*(v.pos.x-center.x),y=v.pos.y},sprite,nil,true,true)
                createEffect(tool.Effect.fadeOut,{time=0.2,},sprite,nil,true,true)
               
            end,1.0+i*0.05)     

        end,false,true)
    end
    
    if maxi == 0 and callBack then
        callBack()
    end
    mPve.endTime = os.time() + 0.6+maxi*0.05 + 2
end
function pveFailed()
    local y = 700 + (Screen.height - 960)*2/3
    local dis = 70
   leaveThisScene()
    return "stopAction"
end

function pveOK()
    local y = 700 + (Screen.height - 960)*2/3
    local dis = 100
    local func = function (  )
        leaveThisScene(true)
    end

    stringEffect({
       
        {file = "nsUI/victory_01.png",pos= {x=320-1.5*dis,y=y}},
        {file = "nsUI/victory_02.png",pos= {x=320-0.5*dis,y=y}},
        {file = "nsUI/victory_03.png",pos= {x=320+0.5*dis,y=y}},
        {file = "nsUI/victory_04.png",pos= {x=320+1.5*dis,y=y}},
       
    },{x=320,y=y},
    function ()
         if pve.endAnim then
            pointAnim(pve.endAnim,func)
        else
            func()
        end
    end)
    return  "stopAction"
end
function loseEffect(callBack)
    hideLoseSelectEffect(function()
    -- 播放lose的动画，结束后切换到主界面
     ----print("winEffect")
        local y = 700 + (Screen.height - 960)*2/3
        local dis = 70
        local sprite = CCSprite:create("nsUI/youlose.png")
        sprite:setPosition(ccp(320,1200))
        this:addChild(sprite,10000)
        createEffect(tool.Effect.move,{time=0.5,x=320,y=y},sprite,function ()
            performWithDelayBattle(function()
                if callBack then
                    callBack()
                end
                if pve.pvp ~= true  then

                    mPve.pveEnd(pve,false)
                    mPve.endPveCallBack(pve)
                    leaveThisSceneAndGotoHome()
                else
                    leaveSceneAndGotoPvpList()
                end
            end,2)
            
        end,false,true)

    end)
end
function rebornCurrent()
    mPve.recodeUserAction(pve,bf,mConf.ActionType.reborn)
    battle.reborn(bf)
    switchAnim(false)
    startPlay()
end
function reborn()
    hideLoseSelectEffect(function()
        if mPve.rebornDiamonds(pve) then
            rebornCurrent()
        else
            alert.create("钻石不足，复活失败，是否前往充值？",function ()
                buyDiamond.onExitCallBack = function ()
                    showLoseSelectEffect(0)
                end
                buyDiamond.create()
            end,function ()
                showLoseSelectEffect(0)
            end)
        end
    end)
end
function hideLoseSelect(flag)
    flag = not flag
    widget2.lose_plane.obj:setVisible(flag)
    --widget2.lose_plane.obj:setTouchEnabled(flag)
    widget2.lose_plane.reborn.obj:setTouchEnabled(flag)
    widget2.lose_plane.quit.obj:setTouchEnabled(flag)
end
rebornHanler = nil
quitHanler = nil
function showLoseSelectEffect(time )
    if time == nil then
        time = 0.2
    end
    createEffect(tool.Effect.scale,{time=0,scale = 0},widget2.lose_plane.obj,function()
         widget2.lose_plane.obj:setVisible(true)
            createEffect(tool.Effect.scale,{time=0.2,scale = 1},widget2.lose_plane.obj,function()
                widget2.lose_plane.reborn.obj:setTouchEnabled(true)
                 widget2.lose_plane.quit.obj:setTouchEnabled(true)       
                 if callBack then
                    callBack()
                end
          end)    
    end)
end
function hideLoseSelectEffect(callBack)
    widget2.lose_plane.reborn.obj:setTouchEnabled(false)
    widget2.lose_plane.quit.obj:setTouchEnabled(false)    
    createEffect(tool.Effect.scale,{time=0.2,scale = 0},widget2.lose_plane.obj,function()
        widget2.lose_plane.obj:setVisible(false)
         if callBack then
            callBack()
        end
    end)    
    --end)
end
function loseSelect(bf,callBack)
    -- 选择是否复活，如果选择不复活则 退出战斗
    -- 如果选择复活则 重新复活
    
    performWithDelayBattle(function()
        showLoseSelectEffect()
        switchAnim(true)
    end,1)
    --widget2.lose_plane.reborn_text.obj:setText("原地复活")
   -- widget2.lose_plane.quit.obj:setTitleText("退出战斗")
   -- widget2.lose_plane.tip.obj:setText("你是否花费 10 颗 钻石复活，继续战斗拿回这些报酬")
    local gold = pve.result.gold + bf.drop.gold
    local exp = pve.result.exp + bf.drop.exp
    local box = #pve.result.item + #bf.drop.item
    widget2.lose_plane.gold.obj:setText("x"..gold)
    widget2.lose_plane.exp.obj:setText("x"..exp)
    widget2.lose_plane.box.obj:setText("x"..box)
    widget2.lose_plane.reborn.obj:registerEventScript(onReborn)
    widget2.lose_plane.quit.obj:registerEventScript(onQuit)
    backToSelect()
end
function backToSelect()
    widget2.lose_plane.reborn_text.obj:setText("原地复活")
    widget2.lose_plane.quit.obj:setTitleText("退出战斗")
    widget2.lose_plane.tip.obj:setText("你是否花费 100 颗 钻石复活，继续战斗拿回这些报酬")
    rebornHanler = reborn
    quitHanler = quitOk
end
function notQuit()
    
    hideLoseSelectEffect(function()
       backToSelect()
       showLoseSelectEffect()
    end)  
end
function quitOk()
    --widget2.lose_plane.reborn.obj:setTouchEnabled(false)
    --widget2.lose_plane.quit.obj:setTouchEnabled(false)  
    hideLoseSelectEffect(function()
        widget2.lose_plane.reborn_text.obj:setText("返回")
        widget2.lose_plane.quit.obj:setTitleText("确认")
        widget2.lose_plane.tip.obj:setText("选择确定的话您将失去以上报酬物品")
        rebornHanler = notQuit
        quitHanler = loseEffect
        showLoseSelectEffect()
    end)
end
function onReborn(event)
    if event == "releaseUp" then
        
        rebornHanler()
    end
end
function onQuit(event)
    if event == "releaseUp" then
        quitHanler()
    end
end


PlayCallBack = nil
function battleEnd(bf)
    print ("#########BattleEnd")
    startBtnEnable(false)
    local b = pve.battleEndCallBack
    stopUserSkill()
    --printTable(PlayCallBack)
    if bf.status == "victory" then
        pve.battleEndCallBack = nil
        if pve.pvp then
            b.callBack(b.param)
            leaveSceneAndGotoPvpList()
        elseif pve.newGuide  then

        else
            endBattleScene(bf,function ()
                 b.callBack(b.param)
                startPlay()
                switchScene(1)
            end)
        end
        --winEffect(bf,callBack)
    elseif bf.status == "lose" then
        if pve.pvp then
            loseEffect(function ()
                b.callBack(b.param)
            end)
        else
            loseSelect(bf,nil)
        end
    end
end
function endBattleScene(bf,callBack)
    --print(bf.status)
    switchQuestAndOppo(2)
    print ("endBattleScene")
    if callBack then
        print ("endBattleScene  performWithDelayBattle")
      performWithDelayBattle(function () 
        print ("endBattleCallBack")
            callBack()
      end,1)
    end
end
function checkLottery(bf)
    local lotteryStatus = false
    for i,action in pairs(bf.playList[pve.round]) do
        if action.action  == conf.BATTLE_ACTION_TYPE.can_lottery  then
            lotteryStatus = true
        end
    end
    if lotteryStatus then
        --print ("############lotteryStatus")
        startBtnEnable(true)
        return true
    end
end



function beforePveEvent(callBack)

    leaveScene(3,0.7,function()
    end)
    local obj = widget.zhuanchang.obj
    createExitEffect(obj,{x=246+720,y=0},0.7,false,function()
        performWithDelayBattle(function()
         createExitEffect(obj,{x=-246-720,y=0},0.7,false,function()
             initIcon()
             initSelfPlayer()
             runToScene(0.7,1,callBack)
        end)
         end,1)
    end)
end



actionHandlerList = {}
function registerActionHandler(action,handler)
    actionHandlerList[action]=handler
end

function startMoveEffect(w,l)
    --w.obj:setScale(1)
    local left = w.image1.obj
    local size = left:getSize()
    local width = size.width/2
    local start = 0
    local epos = -width
    if l then
        start = -width
        epos =  0
    end
    left:setPosition(ccp(start,0))
    local func = nil
    func = function ()
        createEffect(tool.Effect.move,{time=5,x=epos,y=0},left,function()
            left:setPosition(ccp(start,0))
            func()
        end)
    end
    func()
end
function showBossComming()
    local old = AudioEngine.getPlayingMusic()
    widget.boss.obj:setVisible(true)
    AudioEngine.playMusic("bgm_04.mp3",false)

    startMoveEffect(widget.boss.bottom,true)
    startMoveEffect(widget.boss.top,false)
    local pos = tool.getPosition(widget.boss.text.obj)
    tool.setPosition(widget.boss.text.obj,{align = pos.align,left = 70,right = 0,top=0,bottom=0,type =LAYOUT_RELATIVE})

    createEnterEffect( widget.boss.top.obj,{x=0,y=-300},0.6,function()
        createGroupEffect(widget.boss.text.obj,{
            {tool.Effect.fadeOut,{time=0.3}},
            {tool.Effect.fadeIn,{time=0.3}},
            {tool.Effect.fadeOut,{time=0.3}},
            {tool.Effect.fadeIn,{time=0.3}},
            {tool.Effect.fadeOut,{time=0.3}},
            {tool.Effect.fadeIn,{time=0.3}},
            },function()

                AudioEngine.stopMusic(true)
                createExitEffect( widget.boss.top.obj,{x=0,y=-300},0.5,true)
                createExitEffect( widget.boss.bottom.obj,{x=0,y=-300},0.5,true)
                createExitEffect( widget.boss.text.obj,{x=600,y=0},0.5,true,function()
                    widget.boss.top.image1.obj:stopAllActions()
                    --widget.boss.top.image2.obj:stopAllActions()
                     widget.boss.bottom.image1.obj:stopAllActions()
                    --widget.boss.bottom.image2.obj:stopAllActions()
                    widget.boss.obj:setVisible(false) 
                    if old ~= nil then
                         AudioEngine.playMusic(old,true)
                    end     
                    startPlay()   
                end)
            end)

    end)
    createEnterEffect( widget.boss.bottom.obj,{x=0,y=-300},0.6)
    createEnterEffect( widget.boss.text.obj,{x=-300,y=0},0.6)

end
function openGuide(action)
    local event = action.event
    switchAnim(true)
    guide.checkAndOpenGuide(event,function ()
        switchAnim(false)
        startPlay()
    end)
    
    return "stopAction"
end
function pointAnimStart(action)
    pointAnim(action.animId,startPlay)
    return "stopAction"
end
preLotteryData = nil
function guideStartTouch(event)
    if event == "pushDown" then
        widget.laohuji.top.obj:setTouchEnabled(false)
        startBtnEnable(false,false)
        lottery.stopLottery(preLotteryData,false)
        stopClick()
    end
end
local sprite = nil
local sprite2 = nil
local hand1 = nil
local hand2 = nil
function stopClick()
    if hand1 then
        hand1:stopAllActions()
        hand1:removeFromParentAndCleanup(true)
        hand2:removeFromParentAndCleanup(true)
        sprite:removeFromParentAndCleanup(true)
        sprite2:removeFromParentAndCleanup(true)
    end
    hand1 = nil
    hand2 = nil 
    sprite = nil
    sprite2 = nil
end
function addClick(obj,fx,fy)
    if fx == nil then
        fx = 0
    end
    if fy == nil then
        fy = 0
    end
    sprite = CCSprite:create("Image/quan01.png")
    local rect = sprite:getTextureRect()
    sprite2 = CCSprite:create("Image/quan02.png")
    hand1 = CCSprite:create("Image/shouzhi01.png")
    hand2 = CCSprite:create("Image/shouzhi02.png")
    sprite:setAnchorPoint(ccp(0.5,0.5))
    sprite2:setAnchorPoint(ccp(0.5,0.5))
    hand1:setAnchorPoint(ccp(0.5,0.5))
    hand2:setAnchorPoint(ccp(0.5,0.5))
    sprite:setPosition(ccp(fx,fy))
    sprite2:setPosition(ccp(fx,fy))
    hand1:setPosition(ccp(20+fx,-70+fy))
    hand2:setPosition(ccp(20+fx,-30+fy))
    sprite:setOpacity(0)
    sprite2:setOpacity(0)
    hand1:setOpacity(0)
    hand2:setOpacity(0)
    obj:addNode(sprite,20)
    obj:addNode(sprite2,20)
    obj:addNode(hand2,20)
    obj:addNode(hand1,20)
    obj.hasHandEffect = true
    local func 
    func = function()
       tool.createEffect(tool.Effect.move,{time=0.5,x=20+fx,y=-30+fy},hand1,
             function()
                hand1:setOpacity(0)
                hand2:setOpacity(255)
                hand1:setPosition(ccp(20+fx,-70+fy))
                tool.createEffect(tool.Effect.fadeIn,{time=0.3},sprite,
                          function()
                         tool.createEffect(tool.Effect.fadeOut,{time=0.5},sprite,nil,true)
                         tool.createEffect(tool.Effect.fadeIn,{time=0.5},sprite2,
                                   function()
                                      sprite2:setOpacity(0)
                                      hand2:setOpacity(0)
                                      func()
                                   end,true
                         )
                          end,true
                )
             end,true
       )
       tool.createEffect(tool.Effect.fadeIn,{time=0.3},hand1,nil,true)
    end
    func()

end
function checkAndStopLottery(action)
    startBtnEnable(true,false)
    widget.laohuji.top.obj:setTouchEnabled(true)
    addClick(widget.laohuji.obj,200,100)
    local lottery = action.lottery
    preLotteryData = lottery
    
    return "stopAction"
end
function spMaxManual(action)
    local roleId = action.roleId
    local id = playerToPostion[roleId]
    local lottery = action.lottery
    preLotteryData = lottery

    addClick(RoleIcon[id].spbg,0,0)
    return "stopAction"
end
function leaveSceneWithEvent(action)
    local  id = action.id
    if id == 1 then
        -- leaveThisSceneAndGotoHome()
		leaveThisSceneAndGotoCreate()
    end
    return "stopAction"
end
function monsterSkillAnimCmd(action)

end
function registerAll()
    registerActionHandler(conf.BATTLE_ACTION_TYPE.monsterSkillAnimCmd,monsterSkillAnimCmd)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.specialPng,specialPng)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.runToScene,startRunToSceeneForAll)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.leaveScene,leaveSceneWithEvent)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.spMaxManual,spMaxManual)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.pointAnim,pointAnimStart)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.checkAndStopLottery,checkAndStopLottery)

    registerActionHandler(conf.BATTLE_ACTION_TYPE.openGuide,openGuide)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.userTalk,userTalk)

    registerActionHandler(conf.BATTLE_ACTION_TYPE.lastKillEffect,function()
        CCDirector:sharedDirector():getScheduler():setTimeScale(0.25);--实现减速效果 
        oldPerformWithDelay(function ()
             CCDirector:sharedDirector():getScheduler():setTimeScale(1);
        end,0.4) 
    end)

    -- 关键性操作切换事件
    registerActionHandler(conf.BATTLE_ACTION_TYPE.bossComming,function ()
        showBossComming()
        return "stopAction"
        
    end)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.playEffect,function (action)
        AudioEngine.playEffect(action.effect)
    end)
    -- 1.战斗报错
    registerActionHandler(conf.BATTLE_ACTION_TYPE.notSync ,function()
        alert.create("系统错误，与服务器不同步")
        return
    end)

    -- 2. pve发起新战斗需要替换原来的bf  并且做一些必要的初始化工作
    registerActionHandler(conf.BATTLE_ACTION_TYPE.startNewBattle,function(action)
        bf = action.newbf
        pve.round = 1
        pve.playedAction = 1
        initOppoPlayer()
        refreshSelfPlayer()
        startBtnEnable(false)
        setDoubleTouchEnable(true)
         if action.isBattle then 
            startPVEBattle(function()
                startPlay()
                bf.canSkill = true
            end)
            return "stopAction"
         end
         return ""
    end)
    -- 3.老虎机的发起者
    registerActionHandler(conf.BATTLE_ACTION_TYPE.startUserPveLottery,function(action)
        pve.lotteryType = conf.LotteryType.PVE
        startBtnEnable(true)
        if pve.autoFlag then
            getLottery()
            --performWithDelay(getLottery,0)
            return "stopAction"
        end
    end)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.startUserBattleLottery,function(action)
        pve.lotteryType = conf.LotteryType.Battle
        startBtnEnable(true)
        if pve.autoFlag then
            getLottery()
            --performWithDelay(getLottery,0)
            return "stopAction"
        end
    end)
    -- double 是否亮起
    registerActionHandler(conf.BATTLE_ACTION_TYPE.canDouble ,function(action)
        doubleFlag =false
        setDoubleTouchEnable(true)
    end)
    --老虎机摇好了 获取接下去的战报
    registerActionHandler(conf.BATTLE_ACTION_TYPE.pve_result,function(action)
        --beforePveEvent(function()
            mPve.eventResult(pve)
            startPlay()
        --end)
        return "stopAction"
    end)
    --动画延迟
    registerActionHandler(conf.BATTLE_ACTION_TYPE.nextActionDelay,function (action)
        --print ("delay",action.delay)
       delayPlayHandler =  performWithDelayBattle(function ()
            delayPlayHandler = nil
            startPlay()
       end,action.delay/speed)
       return "stopAction"
    end)
    --获取下一个战斗信息
    registerActionHandler(conf.BATTLE_ACTION_TYPE.getNextAction,function ()
        battle.onActionEndCallBack(bf)
    end)
    --战斗结束的回调 （pve和战斗衔接）
    registerActionHandler(conf.BATTLE_ACTION_TYPE.battleEndCallBack,function (action) 
        pve.battleEndCallBack = action
    end )
    --战斗结束  回调？
    registerActionHandler(conf.BATTLE_ACTION_TYPE.battleEnd,function (action)
        pve.playedAction = #bf.playList[pve.round] + 1
        switchAnim(false)
        battleEnd(bf)
        return "stopAction"
    end)
    -- 设置老虎机按钮
    registerActionHandler(conf.BATTLE_ACTION_TYPE.no_Lottery,function() 
        startBtnEnable(false) 
    end)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.endRound,function()
        pve.round = pve.round + 1
        pve.playedAction = 1
    end)
    --老虎机结果展示
    registerActionHandler(conf.BATTLE_ACTION_TYPE.lottery,function(action)
        lottery.stopLottery(action.lottery,false,nowStoped)
        --if nowStoped == true then
            nowStoped = false
        --end
    end)
    -- 结束原来的double事件
    registerActionHandler(conf.BATTLE_ACTION_TYPE.removeDouble,function (action)
         endDouble()
    end)
    -- 改变老虎机的状态
    registerActionHandler(conf.BATTLE_ACTION_TYPE.changeLottery,function (action)
        lottery.initLottery(action.type,startPlay)
        return "stopAction"
    end)
    -- 等待老虎机运行完毕
    registerActionHandler(conf.BATTLE_ACTION_TYPE.waitForPressStop,function ()
        return "stopAction"
    end)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.waitForLottery,function ()
        return "stopAction"
    end)

    -- PVE特有事件
    registerActionHandler(conf.BATTLE_ACTION_TYPE.startEvent,startEvent)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.pveOK,pveOK)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.pveFailed,pveFailed)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.updatePvePrecent,function (action)
        performWithDelay(
            function ()
        updatePvePrecent(action.from,action.to,action.total)
    end
        ,1)
        return "stopAction"
    end)
    --开始滚动老虎机
    registerActionHandler(conf.BATTLE_ACTION_TYPE.startPreLottery,lottery.startPreLottery)
    --registerActionHandler(conf.BATTLE_ACTION_TYPE.startLotteryForVictory,startLotteryForVictory)
    -- 角色动画/行为
    registerActionHandler(conf.BATTLE_ACTION_TYPE.run,runCmd)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.preAttack,atkCmd)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.beHurt,beHurtCmd)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.redeceHp,reduceHp)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.hit,hit)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.die,dieCmd)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.preSkill,preSkill)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.changeSp,changeSp)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.revive,revive)
    -- 道具等特效
    registerActionHandler(conf.BATTLE_ACTION_TYPE.drug,drugEffect)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.bomb,effect.bombEffect)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.addGold,effect.goldEffect)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.addGoldNoMove,effect.addGoldNoMove)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.collectGold,effect.collectGold)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.goldChangeEffect,effect.goldChangeEffect)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.VictoryEffect,effect.VictoryEffect)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.dropExp,effect.dropExp)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.collectExp,effect.collectExp)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.dropItem,effect.dropItem)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.collectItem,effect.collectItem)    

    registerActionHandler(conf.BATTLE_ACTION_TYPE.resultGoldShow,resultGoldShow)  
    registerActionHandler(conf.BATTLE_ACTION_TYPE.resultGoldOver,resultGoldOver)  
 



    registerActionHandler(conf.BATTLE_ACTION_TYPE.addBuff,addBuff)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.buffEffect,buffEffect)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.removeBuff,removeBuff)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.endAttack,endAttack)

    registerActionHandler(conf.BATTLE_ACTION_TYPE.endSkill,endSkill)
    -- 技能特效
    registerActionHandler(conf.BATTLE_ACTION_TYPE.skillStartEffect,skillStartEffect)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.stopUserSkill,stopUserSkill)

    registerActionHandler(conf.BATTLE_ACTION_TYPE.LotteryEndEffect,lottery.LotteryEndEffect)
    --大招
    registerActionHandler(conf.BATTLE_ACTION_TYPE.preSuperAttack,preSuperAttack)
    registerActionHandler(conf.BATTLE_ACTION_TYPE.endSuperAttack,endSuperAttack)

    registerActionHandler(conf.BATTLE_ACTION_TYPE.roundChange,roundChange)

    registerActionHandler(conf.BATTLE_ACTION_TYPE.answerView,answerView)

    registerActionHandler(conf.BATTLE_ACTION_TYPE.onSelectEnd,onSelectEnd)

    registerActionHandler(conf.BATTLE_ACTION_TYPE.needMoreGold,needMoreGold)

    registerActionHandler(conf.BATTLE_ACTION_TYPE.needMoreDiamonds,needMoreDiamonds)

    registerActionHandler(conf.BATTLE_ACTION_TYPE.skillNameEffect,skillNameEffect)

    registerActionHandler(conf.BATTLE_ACTION_TYPE.log,addLog)
end
function skillNameEffect(action)
    switchAnim(true)
    TextEffect(action.name,function ()
        startPlay()
        switchAnim(false)
    end)
    --switchAnim(false)
    return "stopAction"
end
function needMoreGold()
    alert.create("金币不足，是否前往充值？",function()

    end)
end
function needMoreDiamonds()
    alert.create("钻石不足，是否前往充值",function()

    end)
end
local bg = nil
local image = nil
local filp = false
local superAnim = nil
function preSuperAttack(action)
    flip = false
    local size = widget.battle_scene.obj:getSize()
     for ii,roleid in pairs(action.hideList) do
        -- 确定人物的位置
        local id = playerToPostion[roleid]
        local role = Role[id] 
        local info = spaceInfo[id]

        --createEffect(tool.Effect.scale,{time=1,scaleX = 0.5,scaleY=0.5},role.sprite)
        if id > 10 then
            flip = true
            createEffect(tool.Effect.move,{time=1,x=info.pos.x-500,y=info.pos.y},role.sprite,nil,true,true)
        else
            flip = false
            createEffect(tool.Effect.move,{time=1,x=info.pos.x+500,y=info.pos.y},role.sprite,nil,true,true)
        end
        playAnim(role,"run")
    end
    image = tolua.cast(Layout:create(),"Layout")

    local ns  = CCSprite:create()
    local armature = CCArmature:create("summon_anim_001")
    superAnim = armature:getAnimation()
    
    armature:setPosition(ccp(100,-100))
   
    armature:setScale(1)
    ns:addChild(armature,2)
    ns:setScale(1)
    --bg = CCParticleSystemQuad:create("effect/bg.plist")
    --image:addNode(bg,0)
    local x,y 
    x=size.width/16*10
    y=size.height/2 - 50
    if flip then
        x = size.width/16*6
    end
    image:addNode(ns,1)
    widget.battle_scene.obj:addChild(image,100)
    if flip then
        image:setScaleX(-1)
       -- image:setPosition(ccp(-400,size.height/2))
    else
      --  image:setPosition(ccp(size.width+400,size.height/2))
    end
    image:setPosition(ccp(x,y+300))
    
    local step = nil
    step = function()
        createEffect(tool.Effect.move,{time=0.5,x=0,y=90},ns,function ()
            createEffect(tool.Effect.move,{time=0.5,x=0,y=70},ns,step)
        end)
    end
    step()
    local disX = 3
    local distime = 0.1
    local group = {}
    for i=1,30 do
        table.insert(group,{tool.Effect.move,{time=0.07,x=math.random(0,1000)/1000*20-10,y=0}})
    end
    table.insert(group,{tool.Effect.move,{time=0.1,x=0,y=0}})
     --createGroupEffect(this,group,nil,true,true)
     performWithDelayBattle(function ()
        createEffect(tool.Effect.move,{time=2,x=x,y=y-100},image,function()
            performWithDelayBattle(function ()
                createEffect(tool.Effect.move,{time=0.2,x=0,y=(1136-Screen.height)/2,abs = true},widget.battle_scene.obj)
                createEffect(tool.Effect.move,{time=0.2,x=x,y=y},image,function()
                   --performWithDelayBattle(function()
                       superAnim:playWithIndex(0,0,-1,0)
                       superAnim :registerEventScript(function(event,data)
                            if event == "COMPLETE" then
                               
                                superAnim:playWithIndex(0,0,-1,0)
                                superAnim:pause()
                                superAnim:unregisterEventScript()
                            end

                        end)
                        performWithDelayBattle(function ()
                            -- body
                            startPlay()
                        end,2)
                   -- end,1)
                end,true)
                end,1)
        end,true )
    end,0.5)


    return "stopAction"
end
function endSuperAttack(action)
    createGroupEffect(this,{
        {tool.Effect.move,{time=0.05,x=0,y=20}},
        {tool.Effect.move,{time=0.05,x=0,y=-20}},
        {tool.Effect.move,{time=0.05,x=20,y=20}},
        {tool.Effect.move,{time=0.05,x=-20,y=20}},
        {tool.Effect.move,{time=0.05,x=0,y=10}},
        {tool.Effect.move,{time=0.05,x=0,y=-10}},
        {tool.Effect.move,{time=0.05,x=10,y=10}},
        {tool.Effect.move,{time=0.05,x=-10,y=10}},
        {tool.Effect.move,{time=0.05,x=0,y=0}},
        },nil,true,true)
   local size = widget.battle_scene.obj:getSize()
    performWithDelayBattle(function()
        local x,y
        x=size.width+200
        y=size.height -50
        if not flip then
            x = -200
        end
        --createEffect(tool.Effect.move,{time=0.5,x=0+image:getPositionX(),y=-100+image:getPositionY(),abs=true},image,function()
            if flip then
                createEffect(tool.Effect.scale,{time=1,scaleX=-1.5,scaleY=1.5},image,nil,true)
            else
                 createEffect(tool.Effect.scale,{time=1,scaleX=1.5,scaleY=1.5},image,nil,true)
            end
                bezier(image,{x=image:getPositionX(),y=image:getPositionY()},{x=x,y=y},1,
                function()
                    --bg:stopSystem()
                    --bg:removeFromParentAndCleanup(true)
                    image:stopAllActions()
                    image:removeFromParentAndCleanup(true)
                    --bg = nil
                    image =nil
                    for ii,roleid in pairs(action.hideList) do
                        -- 确定人物的位置
                        local id = playerToPostion[roleid]
                        local role = Role[id] 
                        local info = spaceInfo[id]
                        --createEffect(tool.Effect.scale,{time=1,scaleX = 1,scaleY=1},role.sprite)
                        createEffect(tool.Effect.move,{time=1,x=info.pos.x,y=info.pos.y},role.sprite,nil,true,true)
                        playAnim(role,"wait")
                    end
                end,{x=0,y=-200})
            performWithDelayBattle(function()
                startPlay()
            end,1.5)

       -- end)
        createEffect(tool.Effect.move,{time=0.5,x=0,y=-(1136-Screen.height)/2,abs = true},widget.battle_scene.obj)
        
    end,3)   
    return "stopAction"
end
function reSetAllBuffPostion(role)
    local num = #role.buffList 
    if num == 0 then
        return
    end
    num = 0.5+0.5*num
    for i,v in pairs(role.buffList) do
        --print ("###############################",i,num)
        v.image:setPosition(ccp((i-num)*30,130))
    end
end
function addBuff(action)
    local id = playerToPostion[action.roleid]
    local role = Role[id] 
    local info = spaceInfo[id]
    local tpl = action.buff
    local image = tolua.cast(widget._s2.obj:clone(),"ImageView")
    local path = "buff_icon/iocn_buff_"..tpl.icon..".png"
    image:loadTexture(path)
    role.sprite:addChild(image,999)
    table.insert(role.buffList,{image=image,tpl = tpl})
    reSetAllBuffPostion(role)
end
function removeBuff(action)
    local id = playerToPostion[action.roleid]
    local role = Role[id] 
    local info = spaceInfo[id]
    local tpl = action.buff
    for i,v in pairs(role.buffList) do
        if v.tpl.id == tpl.id then
            v.image:removeFromParentAndCleanup(true)
            table.remove(role.buffList,i)
            break
        end
    end
    reSetAllBuffPostion(role)
end
function buffEffect(action)
    local id = playerToPostion[action.roleid]
    local role = Role[id] 
    local info = spaceInfo[id]  

end
goldObj = nil
function resultGoldShow(action)
    performWithDelayBattle (function ()
        local x,y = widget.info2.obj:getPositionX()+widget.info2.gold.obj:getPositionX(),
            widget.info2.obj:getPositionY()+widget.info2.gold.obj:getPositionY()
        local gold = action.gold 
        goldObj =tolua.cast( widget.info2.gold_num.obj:clone() ,"Label")
        local goldImage = tolua.cast( widget.info2.gold.obj:clone() ,"ImageView")
        effect.goldCnt = effect.goldCnt - gold
        effect.setGoldCnt(effect.goldCnt )
        goldObj:setText(gold)
        goldObj:setFontSize(60)
        this:addChild(goldObj,9999)
        goldObj:addChild(goldImage)
        goldImage:setPosition(ccp(-70,0))
        goldImage:setScale(2)
        goldObj:setPosition(ccp(x,y))
        local pos  =ccp(320,Screen.height/8*6)
        goldObj:setScale(0.2)
        createEffect(tool.Effect.scale ,{scale=1,time=0.5},goldObj)
        createEffect(tool.Effect.move,{x=320,y=Screen.height/8*6,time=0.5},goldObj,nil,true)
        end,2)
end
function resultGoldOver(action)
    local x,y = widget.info2.obj:getPositionX()+widget.info2.gold.obj:getPositionX(),
        widget.info2.obj:getPositionY()+widget.info2.gold.obj:getPositionY()
 
    local from = action.from
    local to = action.to
    --print ("################",from,to)
    local func = nil
    goldObj:setText(from)
    local timediff = 0.0001
    func = function()
        goldObj:setText(from)
        if from ~= to then
            createEffect(tool.Effect.delay,{time=timediff},goldObj,func)
        else
            createEffect(tool.Effect.blink,{time=0.5,f=3},goldObj,function ()
                createEffect(tool.Effect.scale ,{scale=0.2,time=0.5},goldObj)
                createEffect(tool.Effect.move,{x=x,y=y,time=0.5},goldObj,function()
                    goldObj:removeFromParentAndCleanup(true)
                    goldObj = nil
                    effect.goldCnt = effect.goldCnt + to
                    effect.setGoldCnt(effect.goldCnt )
                end,true)
            end)           
        end
        if from < to then
             from  = from + 1
        else 
            from = from - 1
        end
        

    end
    func()
    
end

function startPlay()
    xpcall(function()
        local cnt = 0
        while true do
            local action = bf.playList[pve.round][pve.playedAction]
            mPve.recodeUserAction(pve,bf,mConf.ActionType.checkPoint)
            local lotteryStatus = false
            if action == nil then
                return
            else
                if action.roleid then
                   print ("******",pve.playedAction,action.action,action.roleid,action.need,C_CLOCK())
                elseif action.action == "nextActionDelay" then

                else
                   print ("******",pve.playedAction,action.action)
                end
                cnt = 0 
                pve.playedAction = pve.playedAction + 1
                local func = actionHandlerList[action.action]
                if func and func(action) == "stopAction" then
                    return
                end
            end
        end
    end)
end

function showFirendPlane()

end
function startFriend()
    --print ("startFriend!!!!")
    local flag = mPve.findFriend()
    if flag == false then
        startPlay()
    else
        --打开好友面板
        showFirendPlane()
    end
end

function updatePvePrecent(from,to,total)
   lottery.closeDoor()
  leaveScene(3,0.7,function()
    end)
    local obj = widget.zhuanchang.obj
    createExitEffect(obj,{x=246+720,y=0},0.7,false,function()
        local op = widget.quest.obj
        op:setVisible(true)
        createEnterEffect(op,{x=-640,y=0},0.5,function()
            setPvePercent(from,to,total,1)
        end)
        performWithDelayBattle(function()
            createExitEffect(op,{x=640,y=0},0.5,true,function()
                op:setVisible(false)
            end)
             createExitEffect(obj,{x=-246-720,y=0},0.7,false,function()
                 initIcon()
                 initSelfPlayer()
                 runToScene(0.7,1,startPlay)
            end)
         end,3)
    end)
end
function setPvePercent(f,t,total,time)
    print ("!!!!!!!!!!!!!!!!!!!!!!!!!setPvePercent")
    --local perc = widget.oppo.loadingbar.obj:getPercent()
    f  = f +1
    t = t + 1
    if widget.quest.loadingbar.hanler ~= nil then
       unSchedule(widget.quest.loadingbar.hanler)
       widget.quest.loadingbar.hanler = nil
    end
    local width = widget.quest.loadingbar.obj:getSize().width
    widget.quest.loadingbar.obj:stopAllActions()
    local func = nil
    local timeStart = C_CLOCK()
    local from = f/total*100
    local to = t/total*100
    func = function ()
        local diff = C_CLOCK() -  timeStart
        local percent = diff/time
        if percent >= 1 then
            widget.quest.percent.obj:setStringValue(t..":"..total)
            widget.quest.loadingbar.obj:setPercent(math.floor(to))
            widget.quest.loadingbar.special.obj:setPositionX(width*(1-to/100-0.5))
        else
            --widget.quest.percent.obj:setStringValue(math.floor((to-from)*percent+from))
            widget.quest.loadingbar.obj:setPercent((to-from)*percent+from)
            widget.quest.loadingbar.special.obj:setPositionX(width*(1-((to-from)*percent+from)/100-0.5))
            tool.createEffect(tool.Effect.delay,{time=1/60},widget.quest.loadingbar.obj,func)
        end

    end
    func()

    widget.quest.percent.obj:setStringValue(f..":"..total)
    widget.quest.loadingbar.obj:setPercent(math.floor(from))

end
local ps2 = nil
local animNode = nil
function startEvent(action)
    print("##########startEvent")
    local event  = action.event
    bf = pve.bf
    pve.round = 1
    pve.playedAction =3
    --print ("###############")
    startBtnEnable(false)
    createExitEffect(widget.quest.obj,{x=-640,y=0},0.5,true,function()
        widget.quest.obj:setVisible(false)
    end)
    --[[
    createExitEffect(widget.role_icon_1.obj,{x=1000,y=0},0.5,true,function()
        for i=1,4 do
            widget['role_icon_'..i].obj:setVisible(false)
        end 
    end)
    ]]
    performWithDelayBattle(function()
        print ("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
        initOppoPlayer()
        runToScene(2,1)
        local func = nil
        local size = widget.battle_scene.obj:getSize()
        ps2 = tolua.cast(CCParticleSystemQuad:create("effect/time.plist"),"CCParticleSystemQuad")
       -- animNode = CCArmature:create("eventCnter")
        --local anim = animNode:getAnimation()
        ps2:setPosition(ccp(size.width/2,size.height/2)) 
        --widget.battle_scene.obj:addNode(animNode,4)
       -- anim:play("play")
       -- animNode:setPosition(ccp(size.width/2,size.height/2)) 
        widget.battle_scene.obj:addNode(ps2,3)
        widget.battle_scene.bg.obj:setColor(ccc3(0,0,0))
        pve.glassStatus = "select"
        widget.text_bg.event_name.obj:setText(pve.GlassEvent.name)
        widget.text_bg.event_des.obj:setText(pve.GlassEvent.description)
        widget.a_btn.obj:setTitleText("A. "..pve.GlassEvent.optionsA)
        widget.b_btn.obj:setTitleText("B. "..pve.GlassEvent.optionsB)
        widget.a_btn.obj:setVisible(true)
        widget.b_btn.obj:setVisible(true)
        widget.text_bg.obj:setVisible(true)
        createEnterEffect(widget.a_btn.obj,{x=-640,y=0},0.5)
        createEnterEffect(widget.b_btn.obj,{x=-640,y=0},0.5) 
        createEffect(tool.Effect.fadeIn,{time=1},widget.text_bg.obj,function()
            widget.a_btn.obj:setTouchEnabled(true)
            widget.b_btn.obj:setTouchEnabled(true)
        end)
        --widget.text_bg.obj
    end,0.5)
    lottery.closeDoor()
    startBtnEnable(false)
    return "stopAction"
end
function userTalk(action)
    local id = playerToPostion[action.roleId]
    local role = Role[id] 
    local info = spaceInfo[id]
    --switchAnim(true)
    widget.user_talk.obj:stopAllActions()
    widget.user_talk.obj:setOpacity(255)
    widget.user_talk.obj:setVisible(true)
    widget.user_talk.obj:setOpacity(255)
    widget.user_talk.des.obj:setText(action.context)
    widget.user_talk.name.obj:setText(action.name)
    local x ,y ,scaleX
    if info.side then
        x = role.sprite:getPositionX()-100 
        y = role.sprite:getPositionY()+100 
        scaleX = 1
    else
        x = role.sprite:getPositionX()-300
        y = role.sprite:getPositionY()+100
        scaleX = -1
    end

    if x < 0 then
        x = 0
    end
    if x > 640-365 then
        x = 640-365 
    end
    --131
    local maxY = 720 -131 - (1136-Screen.height)/2- 25
    if y > maxY then
        y = maxY
    end 
    x = x + widget.battle_scene.obj:getPositionX()
    y =y  +  widget.battle_scene.obj:getPositionY()
    widget.user_talk.bg.obj:setScaleX(scaleX)

    widget.user_talk.obj:setPosition(ccp(x,y))
  --  widget.oppo.obj:setVisible(false)

    performWithDelay(function ()
       -- switchAnim(false)

        startPlay()
        --performWithDelay(function function_name( ... )
           tool.createGroupEffect(widget.user_talk.obj,{{tool.Effect.delay,{time=0.5}},{tool.Effect.fadeOut,{time=0.5}}},function()
               -- widget.oppo.obj:setVisible(true)
            end)
       -- end,0.7)
    end,2)
    return "stopAction"


end
function answerView(action)
    createExitEffect(widget.a_btn.obj,{x=640,y=0},1,true,function()
        widget.a_btn.obj:setVisible(false)
    end)
    createExitEffect(widget.b_btn.obj,{x=640,y=0},1,true,function()
        widget.b_btn.obj:setVisible(false)
    end)
    createEffect(tool.Effect.fadeOut,{time=1},widget.text_bg.event_des.obj,function()
         widget.text_bg.event_des.obj:setText(action.text)
        createEffect(tool.Effect.fadeIn,{time=1},widget.text_bg.event_des.obj)
    end)

    performWithDelayBattle(startPlay,5)
    return "stopAction"
end
function endEvent(hasBattle,fragmentDrop,callBack)
    widget.a_btn.obj:setTouchEnabled(false)
    widget.b_btn.obj:setTouchEnabled(false)
    widget.battle_scene.bg.obj:setColor(ccc3(255,255,255))
    createEffect(tool.Effect.fadeOut,{time=1}, widget.text_bg.obj,function()
        ps2:stopSystem()
        performWithDelayBattle(function()
            ps2:removeFromParentAndCleanup(true)
        end,2)
       -- animNode:removeFromParentAndCleanup(true)
        for i=1,4 do
            if Role[i] and Role[i].sprite then
                RoleIcon[i].parent:setVisible(true)
               -- widget['role_icon_'..i].obj:setVisible(true)
            end
        end 
        if hasBattle then
            widget.oppo.obj:setVisible(true)
            createEnterEffect(widget.oppo.obj,{x=-640,y=0},1,function ()
                      if callBack then
                    callBack()
                end
            end)
            --[[
            createEnterEffect(widget.role_icon_1.obj,{x=1000,y=0},1)]]
        else
            leaveScene(2,1)
            --widget.quest.obj:setVisible(true)

            createEnterEffect(widget.quest.obj,{x=-640,y=0},1,function ()
                      if callBack then
                    callBack()
                end
            end)
            --[[
            createEnterEffect(widget.role_icon_1.obj,{x=1000,y=0},1)]]
        end
    end)
   

  
end

function onSelectEnd(action)
    local hasBattle = action.hasBattle
    local fragmentDrop = action.fragmentDrop
    setJewNum(pve.gold)
    endEvent(hasBattle,fragmentDrop,function()
        pve.glassStatus = "end"
        startPlay()
    end)
    return "stopAction"
end
function onA(event)
    if event == "releaseUp" and pve and pve.curEvent == mConf.PVE_RES.GLASS then
        mPve.recodeUserAction(pve,bf,mConf.ActionType.selectA)         
        mPve.select(pve,1)
        startPlay()
    end
end
function onB(event)
    if event == "releaseUp" and pve and pve.curEvent == mConf.PVE_RES.GLASS then
        mPve.recodeUserAction(pve,bf,mConf.ActionType.selectB)
        mPve.select(pve,2)
        startPlay()
    end
end
-- 1 pve 2 battle ,3 class
function switchScene(stype)
    

end
-- 1 self, 2 oppo , 3 all
function leaveScene(type,time,callBack)
    for i,v in pairs(Role) do
       -- if Role.info.status ~= mConf.ROLE_STATUS.DEAD then
            local flag = true
            if type == 1 then
                if i >= 10 then
                    flag = false
                end
            elseif type == 2 then
                if i < 10 then
                    flag = false
                end
            end
            if flag then
                if v.sprite then
                    --v.anim:play("run")
                    local call = callBack
                    callBack = nil
                    playAnim(v,"run")
                    createEffect(tool.Effect.move,{x=v.sprite:getPositionX()-640,y=v.sprite:getPositionY(),time= time},v.sprite,function (  )
                        if call then
                            call()
                        end
                        v.sprite:stopAllActions()
                        v.sprite:removeFromParentAndCleanup(true)
                        v.sprite = nil
                        v.anim = nil
                        
                    end,false,true)
                end
            end
        --end
    end
    if callBack then
        callBack()
    end
end
function isDead(id)
    if pve == nil or pve.pvp == true or pve.newGuide == true then
        return false
    end
    for i,v in pairs(pve.selfTeam) do
        if v.id == id then
            return v.status == mConf.ROLE_STATUS.DEAD
        end
    end
    return true
end
function specialRunToScene(type,time,callBack)
    for i,v in pairs(Role) do
       if not isDead(v.info.id) or v.info.teamId == 2 then
            local flag = true
            if type == 1 then
                if i >= 10 then
                    flag = false
                end
            elseif type == 2 then
                if i < 10 then
                    flag = false
                end
            end
            if flag then
                local card = Layout:create()

                local clo = widget.char.obj:clone()
                local char_icon_layout = tool.findChild(clo,"char_icon_layout")
                local member_icon = tool.findChild(char_icon_layout,"member_icon","ImageView")
                local charm = tool.findChild(clo,"charm","LabelAtlas")
                local lv = tool.findChild(clo,"lv","LabelAtlas")
               -- print ("###############################################xxxxxxx",v.info.owner,userdata.CharIdToPhotoFile[v.info.owner])
                --errorFunc()
                if v.info.owner and userdata.CharIdToPhotoFile[v.info.owner] then
                    member_icon:loadTexture(fileManager.path.."/"..userdata.CharIdToPhotoFile[v.info.owner])
                end
                lv:setStringValue(v.info.lv)
                charm:setStringValue(v.info.charmLv-1)
                card:addChild(clo)
                clo:setAnchorPoint(ccp(0.5 , 0.5))
                clo:setPosition(ccp(0,0))
                local info  = spaceInfo[i]
                widget.battle_scene.obj:addChild(card)
                card:setScale(1)
                
                card:setPosition(ccp(info.pos.x,info.pos.y))
                card:setZOrder(info.z)
                local call = callBack
                callBack = nil
                local func = nil
                func = function ()
                    createGroupEffect(clo,{
                        {tool.Effect.move,{x=0,y=15,time=0.4}},
                        {tool.Effect.move,{x=0,y=-15,time=0.4}},
                    },func)
                end
                func()

                local sp = 0.7
                local groupAction = {}
                table.insert(groupAction,{tool.Effect.delay,{time=2}})
                local scaleX = 1
                local diff = 0.02
                local flag = 1 
                while true do
                    if scaleX  <= 0.05 then
                        break
                    end
                    scaleX = scaleX - diff
                    diff = diff + 0.001
                    flag = -flag 
                    table.insert(groupAction,{tool.Effect.scale,{time=(0.5-diff*10)*(0.5-diff*10),scaleX= flag * scaleX,scaleY=1}})
                end
                local armature = CCArmature:create("runtoscene01")
                local anim = armature:getAnimation()
                armature:setPosition(ccp(info.pos.x,info.pos.y))
               -- sprite:addNode(armature,2)
                anim:playWithIndex(0,0,-1,1)
                anim:setSpeedScale(1)
                armature:setScale(1.2)
                widget.battle_scene.obj:addNode(armature,info.z+2)

               
                createGroupEffect(card,groupAction,function ()
                       armature:removeFromParentAndCleanup(true)
                       v.sprite:setVisible(true)
                       v.obj:setVisible(false)
                       v.shadow:setVisible(true)
                       local sx = v.shadow:getScaleX()
                       local sy = v.shadow:getScaleY()
                       v.shadow:setScale(0)
                       createExitEffect(card,{x=0,y=1000},0.5,false,function()
                           v.obj:setVisible(true)
                            createGroupEffect(v.shadow,{
                            {tool.Effect.scale,{time=0.5,scaleX = sx,scaleY = sy}},
                            })
                            v.obj:setOpacity(0)
                            createEffect(tool.Effect.fadeIn,{time=0.5},v.obj,call,true)
                            card:removeFromParentAndCleanup(true)
                       end)       
                end)


                --[[
                local pos = {x=300,y=0}
                if v.flip == true then
                    pos.x = -pos.x
                end
                v.sprite:setVisible(true)
                playAnim(v,"wait")
                ]]
                --local call = callBack
                --callBack = nil
                --[[
                createEnterEffect(v.sprite,pos,time,function()
                    playAnim(v,"wait")
                    if call then
                        call()
                    end
                end,true)]]
            end
        end
    end
    if callBack then
        callBack()
    end   

end
-- 1 self, 2 oppo , 3 all
function runToScene(type,time,callBack)
    for i,v in pairs(Role) do
       if v.isDead ~= true then
            local flag = true
            if type == 1 then
                if i >= 10 then
                    flag = false
                end
            elseif type == 2 then
                if i < 10 then
                    flag = false
                end
            end
            if flag then
                local pos = {x=300,y=0}
                if v.flip == true then
                    pos.x = -pos.x
                end
                v.sprite:setVisible(true)
                playAnim(v,"run")
                local call = callBack
                callBack = nil
                createEnterEffect(v.sprite,pos,time,function()
                    playAnim(v,"wait")
                    if call then
                        call()
                    end
                end,true)
            end
        end
    end
    if callBack then
        callBack()
    end
end
function startPVEBattle(back)
     switchQuestAndOppo(1,function()
        runToScene(2,1,back)
    end) 
end

function getLottery(current)
    print ("############################## getLottery",pve.playedAction)
    if pve.lotteryType == mConf.LotteryType.Battle then
        mPve.recodeUserAction(pve,bf,mConf.ActionType.BattleLottery,current)
    else
        mPve.recodeUserAction(pve,bf,mConf.ActionType.PveLottery,current)
    end
    pve.playedAction = #bf.playList[pve.round] + 1
    if pve.lotteryType == mConf.LotteryType.Battle then
        if battle.getLotteryRandom(bf,current)~= nil then
            startPlay()
        end
    else
        if mPve.getNextPveLottory(pve,current) then
            startPlay()
        end
    end
end

function onPreRefresh(event)
    --print("#onPreRefresh",event)
    if event == "releaseUp" then
        if not widget.control.pre_refresh_btn.obj:isTouchEnabled()  then
            return 
        end
        local res = nil
        if pve.lotteryType == mConf.LotteryType.Battle then
            res =  mPve.changeGoldForBattleRestart(pve)
        else
            res =  mPve.changeGoldForReStart(pve)
        end
        if res then
            mPve.recodeUserAction(pve,bf,mConf.ActionType.reLottery)
            setJewNum(pve.gold)
            setRefreshNum(lottery.allLotteryData.lotteryRefCnt *2)
            startBtnEnable(false)
            lottery.reStartLottery()
        else
            switchAnim(true)
            local func = function ()
                switchAnim(false)
            end
            alert.create("金币不足",func,func,"确定")
        end        
    end
end
local lastMainTime = 0
function onMain(event)
    if event == "releaseUp" then
       --leaveThisSceneAndGotoHome()
       local this2 = tool.loadWidget("nshx/battle_setting",widgetSetting)
        this:addChild(this2,19)
		
		widgetSetting.panel.obj:setOpacity(0)
		tool.createEffect(tool.Effect.fadeIn,{time=0.4},widgetSetting.panel.obj)
		
        local music,effect = AudioEngine.getSwitch()
        if music  then
            widgetSetting.panel.music_check.obj:setSelectedState(true)
        end
        if effect then
            widgetSetting.panel.effect_check.obj:setSelectedState(true)
        end
        widgetSetting.panel.music_check.obj:registerEventScript(function(event )
            print("#########",event)
            if event == "releaseUp" then
                music = not music 
                AudioEngine.switchMusic(music)
            end
        end)
        widgetSetting.panel.effect_check.obj:registerEventScript(function(event )
            if event == "releaseUp" then
                effect = not effect 
                AudioEngine.switchEffect(effect)
            end
         end)
        widgetSetting.panel.back_button.obj:registerEventScript(function(event )
            if event == "releaseUp" then
                this2:removeFromParentAndCleanup(true)
                switchAnim(false)
            end
         end)
         widgetSetting.panel.end_button.obj:registerEventScript(function(event )
            if event == "releaseUp" then
                alert.create("如果结束战斗，将丢失所有产出？是否确定",function()
                    this2:removeFromParentAndCleanup(true)
                    switchAnim(false)
                    loseEffect()
               end)
            end
         end)  
        switchAnim(true)
        
    end
end
widgetSetting = {
    _ignore = true,
    panel={
        end_button={_type="Button"},
        back_button={_type="Button",},
        music_check={_type="CheckBox"},
        music_label={_type="Label"},
        effect_check={_type="CheckBox"},
        effect_label={_type="Label"},
    },
}

function setJewNum(cnt)
    widget.info.jewel_num.obj:setText(cnt)
end

function endDouble ()

   doubleFlag = false

end
function setDoubleTouchEnable(flag)
    if flag == true then


    end
end
function switchAnim(stoped)
    animStoped = stoped
   -- print ("####################switchAnim",stoped)
    if stoped ==true then
       for i,v in pairs(Role) do
          v.sprite:getActionManager():pauseTarget(v.sprite)
          if v.animSprite then
            v.animSprite:getActionManager():pauseTarget(v.animSprite)
          end
          if v.anim then
            v.anim:pause()
          end
       end

       this:getActionManager():pauseTarget(this)
    else
       for i,v in pairs(Role) do
          v.sprite:getActionManager():resumeTarget(v.sprite)
          if v.animSprite then
              v.animSprite:getActionManager():resumeTarget(v.animSprite)
          end 
          if v.anim then
            v.anim:resume()
          end
       end
    
       this:getActionManager():resumeTarget(this)

    end
    --lottery.switchAnim(stoped)

end
function setDoubleStatus(vis,touch,status)
    if status == false then

    end


end
function onDouble(event)
    --print ("onDouble")

    if event == "releaseUp" then
         if not widget.control.double_btn.obj:isTouchEnabled()  then
            return 
        end
        
        mPve.recodeUserAction(pve,bf,mConf.ActionType.double)
        
        if pve.lotteryType == mConf.LotteryType.Battle then
            res =  mPve.pveBattleDouble(pve)
        else
            res =  mPve.pveDouble(pve)
        end
        if res then
           widget.control.double_btn.obj:setVisible(false)
           widget.control.double_btn_down.obj:setVisible(true)
           widget.control.double_btn.obj:setTouchEnabled(false)
           widget.control.double_btn_down.obj:setTouchEnabled(true)
           doubleFlag = true
        else
            switchAnim(true)
            local func = function ()
                switchAnim(false)
            end
            alert.create("钻石不足，是否前往充值？",func,func,"充值")
        end           
    end
end
function setAutoStatus(vis,touch,status)
    if status == true then
        widget.not_auto_btn.obj:setVisible(vis)
        widget.not_auto_btn.obj:setTouchEnabled(touch)
        widget.auto_btn.obj:setVisible(false)
        widget.auto_btn.obj:setTouchEnabled(false)        
    else
        widget.not_auto_btn.obj:setVisible(false)
        widget.not_auto_btn.obj:setTouchEnabled(false)
        widget.auto_btn.obj:setVisible(vis)
        widget.auto_btn.obj:setTouchEnabled(touch)
    end
end
function onNotAuto(event)
    if event == "releaseUp" then
        if not widget.not_auto_btn.obj:isTouchEnabled()  then
            return 
        end
        mPve.recodeUserAction(pve,bf,mConf.ActionType.unAuto)
        widget.not_auto_btn.obj:setVisible(false)
        widget.not_auto_btn.obj:setTouchEnabled(false)
        widget.auto_btn.obj:setVisible(true)
        widget.auto_btn.obj:setTouchEnabled(true)
      
        bf.autoFlag = false
        pve.autoFlag = bf.autoFlag

    end
end
function onAuto(event1)
   if event1 == "releaseUp" then
      --event.pushEvent("CLICK_OPEN_FUNCTION_"..openFunction.EVENT.AUTO_FIGHT)
     -- if widget.auto_btn.obj.clickEnabled == true then
	 if not widget.auto_btn.obj:isTouchEnabled()  then
	    return 
	 end
	 mPve.recodeUserAction(pve,bf,mConf.ActionType.auto)   
	 
	 widget.not_auto_btn.obj:setVisible(true)
	 widget.not_auto_btn.obj:setTouchEnabled(true)
	 widget.auto_btn.obj:setVisible(false)
	 widget.auto_btn.obj:setTouchEnabled(false)
	 
	 bf.autoFlag = true
	 pve.autoFlag = bf.autoFlag
	 if  widget.control.start_btn.obj:isTouchEnabled() then
	    getLottery()
	 end
    --  end
   end
end
widget = {
    _ignore = true,
    mian_btn = {_type="Button",_func=onMain},
    pvp = {
        _type = "Layout",
        role_icon_1 = {},
        role_icon_2 = {},
        role_icon_3 = {},
        role_icon_11 = {},
        role_icon_12 = {},
        role_icon_13 = {},
    },
    role_icon_1 = {},
    role_icon_2 = {},
    role_icon_3 = {},
    role_icon_4 = {},
    role_icon_11 = {},
    role_icon_12 = {},
    role_icon_13 = {},
    role_icon_14 = {},
    a_btn =  {_type = "Button",_func=onA,_noStroke = true},
    b_btn =  {_type = "Button",_func=onB,_noStroke = true},
    control = {
        auto_btn = {_type = "Button",_func =onAuto,_effect="system_02"},
        start_btn = {_type = "Button",_func= onStart,_effect="system_02"},
        --double_btn = {_type = "Button",_func= onDouble,_effect="system_02"},
        refresh_btn= {_type = "Button",_func= onRefresh,_effect="system_02"},
        pre_refresh_btn = {_type="Button",_func=onPreRefresh,_effect="system_02"},
        --double_btn_down = {_type = "Button",},
        not_auto_btn= {_type = "Button",_func =onNotAuto,_effect="system_02"},
    },
    role_tmp = {
        hp_bar ={
            bar = {_type = "LoadingBar"},
        },
    },
    zhuanchang = {_type = "ImageView",},
    battle_scene = {

        _type = "ImageView",  
        bg=   {_type = "ImageView"},
        role_11 = {_type = "ImageView"},
        role_12 = {_type = "ImageView"},
        role_13 = {_type = "ImageView"},
        role_14 = {_type = "ImageView"},
        role_15 = {_type = "ImageView"},
        role_1 = {_type = "ImageView"},
        role_2 = {_type = "ImageView"},
        role_3 = {_type = "ImageView"},
        role_4 = {_type = "ImageView"},
        role_5 = {_type = "ImageView"},
        notEng={},
         combos = {_type="Layout",
            num = {_type="LabelAtlas"},
            img = {_type = "ImageView"}, 

        },
        
    },
    user_talk={
        des = {_type="Label"},
        name= {_type="Label"},
        bg = {_type="ImageView"},
    },
    hit_tmp = {
        num = {_type = "LabelAtlas"},
    },
    hurt_tmp = {_type = "LabelAtlas"},
    info ={
        jewel_num = {_type= "Label"},
        jewel = {_type = "ImageView"},
        refresh_lab  = {_type= "Label"},
        refresh_num  = {_type= "Label"},
    },
    info2 = {
        box_num = {_type= "Label"},
        gold_num = {_type= "Label"},
        gold = {_type = "ImageView"},
        box = {_type = "ImageView"},
        exp = {_type = "ImageView"},
        exp_num = {_type= "Label"},
    },
   
    text_bg = {
        _type = "Layout",
        event_name= {_type= "Label"},
        event_des =  {_type= "Label"},
    },

    quest = {
        loadingbar = {_type = "LoadingBar",special={_type="ImageView"}},
        --name = {_type= "Label"},
        percent = {_type = "LabelAtlas"},
        --percent_img =  {_type = "LabelAtlas"},
    },
    oppo={
        loadingbar = {_type = "LoadingBar"},
        name = {_type= "Label"},
        level = {_type = "ImageView"},
        image =  {_type = "ImageView"},
        nature =  {_type = "ImageView"},  
    },
    role_icon_tmp = {
         level = {_type = "ImageView"},
        image =  {_type = "ImageView"},
        hpbg={
         bar = {_type = "LoadingBar"},
         }  ,
               spbg={
         bar1= {_type = "LoadingBar"},
          bar2= {_type = "LoadingBar"}, 
          bar3 = {_type = "LoadingBar"},

         }  ,
         nature =  {_type = "ImageView"}, 

    },
    role_icon_tmp_1 = {
         level = {_type = "ImageView"},
        image =  {_type = "ImageView"},
        hpbg={
         bar = {_type = "LoadingBar"},
         }  ,
               spbg={
         bar1= {_type = "LoadingBar"},
          bar2= {_type = "LoadingBar"}, 
          bar3 = {_type = "LoadingBar"},
         }  ,
         nature =  {_type = "ImageView"}, 

    },
    _1={_type = "ImageView"},
    _2={_type = "ImageView"},
    _3={_type = "ImageView"},
    _4={_type = "ImageView"},
    _5={_type = "ImageView"},
    _s1={_type = "ImageView"},
    _s2={_type = "ImageView"},
        sp1={_type = "ImageView"},
    sp2={_type = "ImageView"},
    sp3={_type = "ImageView"},
    laohuji={
        bg={
            left = {_type = "ImageView"},
            right = {_type = "ImageView"},
            panel_1 ={_type="Layout"},
            panel_2 ={_type="Layout"},
            panel_3 ={_type="Layout"},
            panel_4 ={_type="Layout"},
            panel_5 ={_type="Layout"},
        },
        top={},
        face = {
            top = {
                move = {}
            },
            bottom = {
                move = {}
            },
        }
    },
    
    skill_open = {

    },
    water_hurt = {_type="LabelAtlas"},
    wood_hurt = {_type="LabelAtlas"},
    fire_hurt = {_type="LabelAtlas"},
    hp_num = {_type="LabelAtlas"},
    shadow_small = {_type = "ImageView"},
    shadow_big = {_type = "ImageView"},
    water = {_type = "ImageView"},
    fire = {_type = "ImageView"},
    wood = {_type = "ImageView"},
    pvp_info = {
        name_1={_type="Label"},
        name_2={_type="Label"},
        lv_1={_type="Label"},
        lv_2={_type="Label"},
        exp_1={_type="Label"},
        exp_2={_type="Label"},
        image_1 = {_type = "ImageView"},
        image_2 = {_type = "ImageView"},
        round = {_type="Label",_shadow=true},
    },
    boss={

       top = {_type = "Layout",
         image1 = {_type = "ImageView",}, 
       },
       bottom = {_type = "Layout",
         image1 = {_type = "ImageView",},
           
       },
        text = {_type = "ImageView"},
    },
    char = {
        charm={_type="LabelAtlas"},
        lv = {_type="LabelAtlas",_stroke=true},
        char_icon_layout = {
             _type="Layout",
            member_icon = {_type="Image",},
        },
    },
    clickImage={_type="ImageView"},

    role_icon_tmp_super = {
    info = {
         level = {_type = "ImageView"},
        image =  {_type = "ImageView"},
        image_real =  {_type = "ImageView"},
         nature =  {_type = "ImageView",}, 
        },
        hp = {_type="ImageView",_stroke=true},
        hpbg={
         bar = {_type = "LoadingBar"},
         }  ,
               spbg={
             bar1= {_type = "LoadingBar", },
              bar2= {_type = "LoadingBar",}, 
              bar3 = {_type = "LoadingBar", },
              --name={_type="Label",_stroke=true},
         }  ,
        


    },
    auto_btn = {_type = "Button",_func =onAuto,_effect="system_02"},
    not_auto_btn= {_type = "Button",_func =onNotAuto,_effect="system_02"},
    showLog = {_type="Button",_func=showLog},
    log_view = {
        list = {_type="ScrollView"},
        log_tmp = {
            _type ="Layout",
            time  = {_type="Label"},
            log   = {_type="Label"},
        },
        loading_bg = {
            loading={},
        },
        close = {_type="Button",_func=hideLog},
    },
}
widget2 = {
    _ignore = true,
    lose_plane={
        gold_text = {_type= "Label"},
        exp_text = {_type= "Label"},
        box_text = {_type= "Label"},
        gold = {_type= "Label"},
        exp = {_type= "Label"},
        box = {_type= "Label"},
        tip = {_type= "Label"},
        quit ={_type="Button",_func = onQuit},
        reborn ={_type="Button",_func = onReborn},
        reborn_text= {_type= "Label",},
    },
}
