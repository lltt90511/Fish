fDB = fDB
scriptsVersion =scriptsVersion
local userdata = require "logic.userdata"
module("battle.data",package.seeall)
local createBattleAction = "CREATE TABLE if not exists BattleAction(id integer primary key autoincrement,type,process,round,playedAction,param);"
local createRunningInfo = [[
	CREATE TABLE if not exists BattleRunningStatus(key integer primary key,value);
]]
function battleDbInit()
	local initQuery = createBattleAction .. createRunningInfo
    fDB.exec(initQuery)
    getRunningInfo()
end
-- 文件。
jsonFileName = CCFileUtils:sharedFileUtils():getWritablePath().."/pveTmp.obj"

function clearBattleJson()
	local file = io.open(jsonFileName,"wb")
	file:close()
end
function writeBattleJson(info,startAnim,endAnim,gold)
	local file = io.open(jsonFileName,"wb")
	-- 不记录钻石数量，因为可以充值
	file:write(C_encryptString(cjson.encode({scriptsVersion = scriptsVersion,charId=userdata.UserInfo.charId, info=info,startAnim=startAnim,endAnim=endAnim,gold=gold})))
	file:close()
end
function readBattleJson()
	local file = io.open(jsonFileName,"rb")
	  if file == nil then
        file = io.open(path,"wb")
        file:close()
        file = io.open(path,"rb")
    end
    local line = ""
    local first = true
    while true do
       local l = file:read()
        --print ("#################",line)
        if l == nil  then
            --line = line .. "\n"
            break
        end
        line = line .. l
    end
    file:close()
    if line == nil or line == "" then
        return 
    end
    line = C_unEncryptString(line)
    local parm = cjson.decode(line)
    if parm.charId ~=userdata.UserInfo.charId then
        file = io.open(path,"wb")
        file:close()
        return 
    end
     if parm.scriptsVersion ~= scriptsVersion then
        -- 脚本版本不对
        file = io.open(path,"wb")
        file:close()
        return 
    end
    return parm
end
--[[
	hasBattle    bool
	battleEnd    bool
	processCnt   int
	round        int
	playedAction int
]]
runningInfo = {}
runningInfoKey = {
	hasBattle = 1,
	battleEnd = 2,
	battleId = 3,
	round = 4,
	playedAction = 5,
}
sqlHandler = nil
local sqlSet = ""
function execNow()
	if sqlHandler ~= nil then
		unSchedule(sqlHandler)
		sqlHandler = nil
		execAllSql()
	end
end
function execAllSql()
	sqlHandler = nil
	local sql = sqlSet 
	sqlSet = ""
	if sql ~= "" then
		--fDB.beginT()
		fDB.exec("begin transaction;"..sql.."commit transaction;")
		--fDB.endT()
	end
end
function startDelay()
	if sqlHandler ~= nil then
		return
	end
	sqlHandler = performWithDelay(execAllSql,1)
end
function exec(sql)
	sqlSet = sqlSet ..sql
	startDelay()
end
function setRunningInfo(key,value)
	if runningInfo[key] == value then
		return 
	end
	runningInfo[key] = value
	--print ("setRunningInfo",key,value)
	key = runningInfoKey[key]
	exec("REPLACE INTO  BattleRunningStatus(key,value)  values ("..key..", \'"..tostring(value).."\');")
end

function getRunningInfo()
	local sql = "select * from BattleRunningStatus";
	local res = fDB.query(sql)
	local info = {}
	for _,v in pairs(res) do
		info[v.key] = v.value
	end
	for i,v in pairs(runningInfoKey) do
		info[i] = info[tostring(v)]
	end
	--printTable(info)
	runningInfo = info
	return info
end

function clearRunningInfo()
	execNow()
	local dropQuery = "DROP TABLE if exists BattleRunningStatus;"..createRunningInfo
	runningInfo = {}
	fDB.exec(dropQuery)	
end
function addUserAction(pve,bf,type,param)
	print ("addUserAction",type)
	local insert = "INSERT INTO BattleAction (type,process,round,playedAction,param) \
	values("..type..","..bf.id..","..pve.round..","..pve.playedAction..",\""..param.."\");"
	exec(insert)
end
function clearUserAction()
	execNow()
	local dropQuery = "DROP TABLE if exists BattleAction;"..createBattleAction
	fDB.exec(dropQuery)
end
function readAllUserAction()
	local query = "select * from BattleAction order by  id asc"
	local res = fDB.query(query)
	for i,v in pairs(res) do
		v.battleId = tonumber(v.process)
		v.round = tonumber(v.round)
		v.playedAction = tonumber(v.playedAction)
		v.type = tonumber(v.type)
	end
	return res
end