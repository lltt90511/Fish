local math,table,tonumber,pairs,splitWithTrim,string=math,table,tonumber,pairs,splitWithTrim,string
local mGameData = require ("template.gamedata")
local mConf = require ("battle.conf")
local mSelect=require("battle.select")
local mView=require("battle.view")
local countLv = require("logic.countLv")
module("battle.numerial",package.seeall)
function getBattleAtk(bf,role,atkRate)
	if atkRate == nil then
		atkRate = 0
	end
	local badgeAtk=role.badgeBean.satk *(1+atkRate/100)
	local pre = 100
	for k,v in pairs(role.buff) do
		local tpl = v.buff
		if tpl.propName=="atk_up" then
			badgeAtk=badgeAtk+tpl.propNum
		end
		if tpl.propName=="atk_down" then
			badgeAtk=badgeAtk-tpl.propNum
		end
		if tpl.propName=="atk_upR" then
			pre = pre + tpl.propNum
		end
		if tpl.propName=="atk_downR" then
			pre = pre - tpl.propNum
		end
	end
	for i,v in pairs(role.passive) do
		local tpl = v.passive
		if tpl.propName=="atk_up" then
			badgeAtk=badgeAtk+tpl.propNum
		end
		if tpl.propName=="atk_down" then
			badgeAtk=badgeAtk-tpl.propNum
		end
		if tpl.propName=="atk_upR" then
			pre = pre + tpl.propNum
		end
		if tpl.propName=="atk_downR" then
			pre = pre - tpl.propNum
		end			
	end
	local selfTeam = mSelect.selfTeam(bf,role)
	for i,v in pairs(selfTeam.passive) do
		if v.factions == nil or v.factions == role.factions then
			local tpl = v.passive
			if tpl.propName=="atk_up" then
				badgeAtk=badgeAtk+tpl.propNum
			end
			if tpl.propName=="atk_down" then
				badgeAtk=badgeAtk-tpl.propNum
			end
			if tpl.propName=="atk_upR" then
				pre = pre + tpl.propNum
			end
			if tpl.propName=="atk_downR" then
				pre = pre - tpl.propNum
			end		
		end			
	end
	return (badgeAtk)*(pre/100)*(1+role.atk/10000)
end

	
function getBattleDef(bf,role)
	local badgeDef=role.badgeBean.sdef
	local pre = 100
	for k,v in pairs(role.buff) do
		local tpl = v.buff
		if tpl.propName=="def_up" then
			badgeDef=badgeDef+tpl.propNum
		end
		if tpl.propName=="def_down" then
			badgeDef=badgeDef-tpl.propNum
		end
		if tpl.propName=="def_upR" then
			pre = pre + tpl.propNum
		end
		if tpl.propName=="def_downR" then
			pre = pre - tpl.propNum
		end
	end
	for i,v in pairs(role.passive) do
		local tpl = v.passive
		if tpl.propName=="def_up" then
			badgeDef=badgeDef+tpl.propNum
		end
		if tpl.propName=="def_down" then
			badgeDef=badgeDef-tpl.propNum
		end
		if tpl.propName=="def_upR" then
			pre = pre + tpl.propNum
		end
		if tpl.propName=="def_downR" then
			pre = pre - tpl.propNum
		end		
	end
	local selfTeam = mSelect.selfTeam(bf,role)
	for i,v in pairs(selfTeam.passive) do
		if v.factions == nil or v.factions == role.factions then
			local tpl = v.passive
			if tpl.propName=="def_up" then
				badgeDef=badgeDef+tpl.propNum
			end
			if tpl.propName=="def_down" then
				badgeDef=badgeDef-tpl.propNum
			end
			if tpl.propName=="def_upR" then
				pre = pre + tpl.propNum
			end
			if tpl.propName=="def_downR" then
				pre = pre - tpl.propNum
			end	
		end			
	end
	return badgeDef*(pre/100)*(1+role.def/10000)
end
function getHpMax(bf,role)
	local badgeHp=role.badgeBean.shp
	local pre = 100
	for k,v in pairs(role.buff) do
		local tpl = v.buff
		if tpl.propName=="hp_up" then
			badgeHp=badgeHp+tpl.propNum
		end
		if tpl.propName=="hp_down" then
			badgeHp=badgeHp-tpl.propNum
		end
		if tpl.propName=="hp_upR" then
			pre = pre + tpl.propNum
		end
		if tpl.propName=="hp_downR" then
			pre = pre - tpl.propNum
		end
	end
	for i,v in pairs(role.passive) do

		local tpl = v.passive
		if tpl.propName=="hp_up" then
			badgeHp=badgeHp+tpl.propNum
		end
		if tpl.propName=="hp_down" then
			badgeHp=badgeHp-tpl.propNum
		end
		if tpl.propName=="hp_upR" then
			pre = pre + tpl.propNum
		end
		if tpl.propName=="hp_downR" then
			pre = pre - tpl.propNum
		end			
	end
	local selfTeam = mSelect.selfTeam(bf,role)
	for i,v in pairs(selfTeam.passive) do
		if v.factions == nil or v.factions == role.factions then
			local tpl = v.passive
			if tpl.propName=="hp_up" then
				badgeHp=badgeHp+tpl.propNum
			end
			if tpl.propName=="hp_down" then
				badgeHp=badgeHp-tpl.propNum
			end
			if tpl.propName=="hp_upR" then
				pre = pre + tpl.propNum
			end
			if tpl.propName=="hp_downR" then
				pre = pre - tpl.propNum
			end		
		end	
	end
	return badgeHp*(pre/100)*(1+role.hpMax/10000)

end
function getBattleHp(bf,role)
	return role.hp
end	
function getHpPercent(bf,role)
	print (getBattleHp(bf,role),getHpMax(bf,role))
	return  getBattleHp(bf,role)/getHpMax(bf,role)
end
function reduceHp(bf,role,hp)
	--print ("##################",role.id,role.name,role.hp,hp,role.hp-hp)
	role.hp = role.hp - hp
	local hpMax = getHpMax(bf,role)
	if role.hp  < 0  then
		role.hp = 0
	end
	if role.hp > hpMax then
		role.hp = hpMax
	end
end





function getHurtAfterParry(bf,type,hurter,attacker,hp)
	local mSkill = package.loaded['battle.skill']
	local hasAttributeParryRSkill=mSkill.checkHasPassSkill(bf,hurter,"attribute_parryR")	
	if hasAttributeParryRSkill>0  and hurter.factions==attacker.factions then
		local propNum=mSkill.getPassivePropNumInt(hasAttributeParryRSkill)
		mView.parryCmd(bf,hurter.id,hp*propNum/100,bf.time,0)
		hp=hp*(1-propNum/100)

	end	
	
	local hasAllParryRSkill=mSkill.checkHasPassSkill(bf,hurter,"all_parryR")	
	if hasAllParryRSkill>0   then
		local propNum=mSkill.getPassivePropNumInt(hasAllParryRSkill)
		mView.parryCmd(bf,hurter.id,hp*propNum/100,bf.time,0)
		--print (hp,propNum,hp*(1-propNum/100),"all_parryR")
		hp=hp*(1-propNum/100)

	end
	local hasLimitSkill=mSkill.checkHasPassSkill(bf,hurter,"limit")
	if hasLimitSkill >0 then
		local propNum=mSkill.getPassivePropNumInt(hasLimitSkill)
		if hp > propNum then
			hp = propNum
		end
	end
	if hp < 1 then
		hp = 1
	end
	return hp
end

-- 攻击成功后恢复血量
function Vampire(bf,type,attcker,hp)
	local mSkill = package.loaded['battle.skill']
	local hasVampireSkill=mSkill.checkHasPassSkill(bf,attcker,"Vampire")
	if hasVampireSkill>0 then
		local mAction = package.loaded["battle.action"]
		local propNum=mSkill.getPassivePropNumInt(hasVampireSkill);
		mAction.reduceHpCmd(bf,attcker,nil,-hp*(propNum/100))
	end		
end